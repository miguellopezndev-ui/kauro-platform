/**
 * Parser and Proposal Compiler, canon §30–§35.
 *
 * The parser proves shape: closed schema, exact enums, bounded sizes, no
 * normalisation of an authoritative id to make an invalid output fit. The
 * compiler proves truth, in the mandatory order — schema → task/run/envelope
 * identity and refs → TargetContract → primitives and parameters →
 * support envelope → authority → cross-item consistency — and hands what
 * survives to the host's full-dataset validation port. The evidence class is
 * derived from the evidence refs, never read from the model. Every refusal
 * is one of the explicit outcomes; there is no best-effort plan.
 */
import type { AdaptedContracts } from '../adapter/contract-adapter.js';
import { digestOf } from '../contracts/canonical.js';
import type { DeterministicCandidate, IntelligenceEnvelopeV1, ProposalType, SourceFieldFact } from '../contracts/envelope.js';
import type { TaskOutcome } from '../contracts/errors.js';
import { PRIMITIVES, PRIMITIVE_PARAM_DOMAINS, proposalShapeProblems } from '../contracts/proposal.js';
import type { EvidenceClass, IntelligenceProposalV1, ProposalItem, RationaleCode } from '../contracts/proposal.js';
import { parseJsonBounded } from '../contracts/schema.js';
import type { SchemaProblem } from '../contracts/schema.js';
import { MODEL_POLICY_VERSION, PROMPT_BUNDLE_VERSION } from '../contracts/versions.js';
import type { ResolvedDecision } from '../resolver/deterministic-resolver.js';

// ------------------------------------------------------------------- parser

export type ParseResult = { readonly ok: true; readonly proposal: IntelligenceProposalV1 } | { readonly ok: false; readonly outcome: 'INVALID_SCHEMA'; readonly problems: readonly SchemaProblem[] };

export function parseProposal(content: string): ParseResult {
  const parsed = parseJsonBounded(content);
  if (parsed.problems.length > 0) return { ok: false, outcome: 'INVALID_SCHEMA', problems: parsed.problems };
  const problems = proposalShapeProblems(parsed.value);
  if (problems.length > 0) return { ok: false, outcome: 'INVALID_SCHEMA', problems };
  return { ok: true, proposal: parsed.value as IntelligenceProposalV1 };
}

// ----------------------------------------------------------------- compiler

export interface CompiledItem {
  readonly candidateRef: string;
  readonly proposalType: ProposalType;
  readonly outcome: TaskOutcome;
  readonly codes: readonly string[];
  readonly targetRef: string | null;
  readonly destinationField: string | null;
  readonly sourceFieldRef: string | null;
  readonly semanticType: string | null;
  readonly transformPrimitive: string | null;
  readonly typedTransformParams: Readonly<Record<string, string>> | null;
  readonly evidenceClass: EvidenceClass;
  /** The evidence refs the proposal cited and the envelope knows; an oracle checks them, not a class alone. */
  readonly evidenceRefs: readonly string[];
  readonly requiresAgencyDecision: boolean;
  readonly rationaleCode: string;
  readonly impactRows: number;
}

export interface CompiledTask {
  readonly taskId: string;
  readonly envelopeHash: string;
  readonly proposalDigest: string;
  readonly outcome: TaskOutcome;
  readonly codes: readonly string[];
  readonly items: readonly CompiledItem[];
  /** Codes the model may repair once: schema and reference problems, not authority problems. */
  readonly repairable: boolean;
}

export interface CompileInput {
  readonly envelope: IntelligenceEnvelopeV1;
  readonly envelopeHash: string;
  readonly proposal: IntelligenceProposalV1;
  readonly runId: string;
  readonly contracts: AdaptedContracts;
  readonly decisions: readonly ResolvedDecision[];
}

const SEMANTIC_OF_TARGET_TYPE = (type: string, options: readonly string[]): string => {
  const token = type.toLowerCase();
  if (options.length > 0) return 'ENUM';
  if (token.includes('email')) return 'EMAIL';
  if (token.includes('phone')) return 'PHONE';
  if (token === 'date') return 'DATE';
  if (token.includes('datetime') || token === 'timestamp') return 'DATETIME';
  if (token.includes('bool') || token === 'checkbox') return 'BOOLEAN';
  if (token.includes('number') || token.includes('double') || token.includes('int') || token.includes('currency') || token.includes('percent')) return 'NUMBER';
  if (token.includes('url')) return 'URL';
  return 'TEXT';
};

const SHAPE_SEMANTIC: Readonly<Record<string, string>> = { emailLike: 'EMAIL', phoneInternational: 'PHONE', phoneLocalDigits: 'PHONE', isoDate: 'DATE', slashDateAmbiguous: 'DATE', booleanLike: 'BOOLEAN', integer: 'NUMBER', decimalPoint: 'NUMBER', decimalComma: 'NUMBER', groupedNumber: 'NUMBER', urlLike: 'URL' };

const normaliseText = (text: string): string => text.normalize('NFKC').toLowerCase().replace(/[^a-z0-9]+/gu, '');
const tokensOf = (text: string): string[] => text.normalize('NFKC').toLowerCase().split(/[^a-z0-9]+/u).filter((token) => token.length >= 3);
/** A header names a target when it equals one of the target's names or shares a token of three or more characters with one. */
const namesMatch = (header: string, names: readonly (string | undefined)[]): boolean => {
  if (header === '') return false;
  const headerTokens = tokensOf(header);
  // A CLEAN_ONLY ref carries no vendor label or api name; only real strings take part in the match.
  return names.some((name) => typeof name === 'string' && name !== '' && (normaliseText(name) === normaliseText(header) || tokensOf(name).some((token) => headerTokens.includes(token))));
};

/** The canonical object a header token names, for the foreign-key fact: a column that names another object refers to it. */
const OBJECT_OF_TOKEN: Readonly<Record<string, string>> = Object.freeze({ contact: 'CONTACT', contacts: 'CONTACT', contacto: 'CONTACT', person: 'CONTACT', company: 'COMPANY', companies: 'COMPANY', account: 'COMPANY', accounts: 'COMPANY', organisation: 'COMPANY', organization: 'COMPANY', empresa: 'COMPANY', cuenta: 'COMPANY', deal: 'DEAL', deals: 'DEAL', opportunity: 'DEAL', opportunities: 'DEAL', negocio: 'DEAL', lead: 'LEAD', leads: 'LEAD' });

/**
 * What each rationale code is: a claim that supports authority — a fact
 * that, holding, lets a proposal stand as PROPOSED — or a claim that defers
 * it — a limit the model reports, which holding or not never makes a
 * mapping true. Every code of the closed vocabulary is here; a code that is
 * missing does not compile.
 */
const RATIONALE_KIND: Readonly<Record<RationaleCode, 'SUPPORTS' | 'DEFERS'>> = Object.freeze({
  HEADER_MATCHES_TARGET_LABEL: 'SUPPORTS',
  HEADER_MATCHES_TARGET_API_NAME: 'SUPPORTS',
  SHAPE_MATCHES_TARGET_TYPE: 'SUPPORTS',
  MEMORY_CONVENTION_APPLIES: 'SUPPORTS',
  VALUES_ARE_TARGET_OPTIONS: 'SUPPORTS',
  UNIQUE_AND_WELL_FORMED_IDENTIFIER: 'SUPPORTS',
  FOREIGN_KEY_COLUMN: 'DEFERS',
  NO_TARGET_IN_ENVELOPE: 'DEFERS',
  AMBIGUOUS_BETWEEN_TARGETS: 'DEFERS',
  VALUE_NOT_IN_TARGET_OPTIONS: 'DEFERS',
  REQUIRED_TARGET_UNSATISFIED: 'DEFERS',
  DESTRUCTIVE_NEEDS_AGENCY: 'DEFERS',
  IDENTITY_NEEDS_PROOF: 'DEFERS',
  INSUFFICIENT_EVIDENCE: 'DEFERS',
  OUT_OF_SUPPORT_ENVELOPE: 'DEFERS',
});

/**
 * The facts the envelope, the contracts and the deterministic decisions hold
 * about one item's source field and chosen target, canon §28, §30–§31. A
 * rationale code is a claim the model makes; each of these is what would
 * make one of the fifteen claims true, computed here from the profile, the
 * target, the exemplars and the resolver's decisions — never read back from
 * the proposal.
 */
interface ItemFacts {
  /** The source header and the target's label (or the canonical name it is delivered as) share a normalised token, or are one name. */
  readonly headerMatchesLabel: boolean;
  /** The source header and the target's api name (or the canonical name it is delivered as) share a normalised token, or are one name. */
  readonly headerMatchesApiName: boolean;
  /** Either of the two name facts. */
  readonly headerMatchesTarget: boolean;
  /** One of the field's shape candidates maps to the target's semantic type. */
  readonly shapeMatchesTarget: boolean;
  /** The field has classified values in the envelope and every one is a target option. */
  readonly valuesAreTargetOptions: boolean;
  /** The field has classified values in the envelope and at least one is outside the options of the target named, or of an allowed target when none is named. */
  readonly valuesOutsideTargetOptions: boolean;
  /** The profile says unique among non-empty and populated on every row. */
  readonly uniqueAndPopulated: boolean;
  /** A verified memory rule names this header pattern and this target. */
  readonly memoryApplies: boolean;
  /** The header names a canonical object other than the one the field's file holds. */
  readonly headerNamesAnotherObject: boolean;
  /** The item names no target and no target the envelope let the candidate name is evidenced for the field by name, shape or values. */
  readonly noTargetEvidenced: boolean;
  /** The envelope let the candidate name more than one target, and every alternative the item lists is one of them. */
  readonly severalTargetsOffered: boolean;
  /** A required, writable target of the object is neither decided deterministically nor named by an item of this proposal. */
  readonly requiredTargetUnsatisfied: boolean;
  /** The item names a primitive the catalogue marks destructive. */
  readonly destructivePrimitive: boolean;
  /** The resolver classified the field as a unique column without authority: an identity signal or unique but unproven. */
  readonly identityUnproven: boolean;
  /** The target named, or a contract field the header names, is outside the support envelope: no destination field delivers it. */
  readonly outsideSupportEnvelope: boolean;
}

interface FactContext {
  readonly envelope: IntelligenceEnvelopeV1;
  readonly contracts: AdaptedContracts;
  readonly candidate: DeterministicCandidate | undefined;
  readonly field: SourceFieldFact | undefined;
  readonly decisions: readonly ResolvedDecision[];
  /** Every target the other items of the proposal name, for the required-target fact. */
  readonly targetsNamedByProposal: ReadonlySet<string>;
}

function itemFacts(item: ProposalItem, context: FactContext): ItemFacts {
  const { envelope, contracts, candidate, field, decisions } = context;
  const vendorFields = envelope.targetContract.mode === 'CLEAN_ONLY' ? null : envelope.targetContract.fields;
  const targetInfo = item.targetRef === null ? undefined : contracts.refs.targetByRef.get(item.targetRef);
  const targetField = item.targetRef === null || vendorFields === null ? undefined : vendorFields.find((entry) => entry.targetRef === item.targetRef);
  const header = field?.header ?? '';
  const canonicalName = targetInfo === undefined ? '' : (targetInfo.destinationField.split('.')[1] ?? '');
  const labelNames = targetInfo === undefined ? [] : [targetInfo.label, canonicalName];
  const apiNames = targetInfo === undefined ? [] : [targetInfo.apiName, canonicalName];
  const headerMatchesLabel = namesMatch(header, labelNames);
  const headerMatchesApiName = namesMatch(header, apiNames);
  const headerMatchesTarget = headerMatchesLabel || headerMatchesApiName;
  const semanticOfRef = (targetRef: string): string | null => {
    const info = contracts.refs.targetByRef.get(targetRef);
    const view = vendorFields?.find((entry) => entry.targetRef === targetRef);
    if (view !== undefined) return SEMANTIC_OF_TARGET_TYPE(view.type, view.options);
    if (info === undefined) return null;
    return SEMANTIC_OF_TARGET_TYPE(info.destinationField.endsWith('email') ? 'email' : info.destinationField.endsWith('phone') ? 'phone' : info.destinationField.endsWith('website') || info.destinationField.endsWith('domain') ? 'url' : 'text', []);
  };
  const shapeMatches = (targetRef: string): boolean => {
    const semantic = semanticOfRef(targetRef);
    return field !== undefined && semantic !== null && semantic !== 'TEXT' && semantic !== 'ENUM' && field.shapeCandidates.some((shape) => SHAPE_SEMANTIC[shape] === semantic);
  };
  const shapeMatchesTarget = item.targetRef !== null && shapeMatches(item.targetRef);
  const values = field === undefined ? [] : envelope.exemplars.filter((exemplar) => exemplar.fieldRef === field.fieldRef && exemplar.dataLevel === 'L1').map((exemplar) => exemplar.minimizedValueOrClass);
  const optionsOf = (targetRef: string): readonly string[] => vendorFields?.find((entry) => entry.targetRef === targetRef)?.options ?? [];
  const valuesInOptions = (targetRef: string): boolean => optionsOf(targetRef).length > 0 && values.length > 0 && values.every((value) => optionsOf(targetRef).includes(value));
  const valuesAreTargetOptions = targetField !== undefined && valuesInOptions(targetField.targetRef);
  const consideredTargets = item.targetRef !== null ? [item.targetRef] : [...(candidate?.allowedTargetRefs ?? [])];
  const valuesOutsideTargetOptions = values.length > 0 && consideredTargets.some((targetRef) => optionsOf(targetRef).length > 0 && values.some((value) => !optionsOf(targetRef).includes(value)));
  const uniqueAndPopulated = field !== undefined && field.uniqueAmongNonEmpty === true && field.nonEmptyCount > 0 && field.nonEmptyCount === field.rowCount;
  const memoryApplies = envelope.memoryEvidence.some((entry) => entry.rule.targetRef !== null && entry.rule.targetRef === item.targetRef && field !== undefined && field.header.toLowerCase().includes(entry.rule.sourceHeaderPattern.toLowerCase()));
  // The object the field's file holds, as the resolver recorded it on the field's decisions (`${fileId}-${object}`).
  const recordId = field === undefined ? null : (decisions.find((decision) => decision.fieldRef === field.fieldRef && decision.recordId !== null)?.recordId ?? null);
  const fileObject = recordId === null ? null : recordId.slice(recordId.lastIndexOf('-') + 1).toUpperCase();
  const headerNamesAnotherObject = tokensOf(header).some((token) => {
    const object = OBJECT_OF_TOKEN[token];
    return object !== undefined && object !== fileObject;
  });
  const namesOfRef = (targetRef: string): string[] => {
    const info = contracts.refs.targetByRef.get(targetRef);
    return info === undefined ? [] : [info.label, info.apiName, info.destinationField.split('.')[1] ?? ''];
  };
  const evidencedFor = (targetRef: string): boolean => namesMatch(header, namesOfRef(targetRef)) || shapeMatches(targetRef) || valuesInOptions(targetRef);
  const allowed = candidate?.allowedTargetRefs ?? [];
  const noTargetEvidenced = item.targetRef === null && !allowed.some(evidencedFor);
  const severalTargetsOffered = allowed.length >= 2 && item.alternatives.every((alternative) => allowed.includes(alternative.targetRef));
  const objectOfTarget = (targetRef: string): string | null => contracts.refs.targetByRef.get(targetRef)?.objectApiName ?? null;
  const objectsInPlay = new Set([...consideredTargets.map(objectOfTarget)].filter((object): object is string => object !== null));
  const decidedTargets = new Set(decisions.filter((decision) => decision.kind === 'FIELD_MAPPING' && decision.targetRef !== null).map((decision) => decision.targetRef));
  const requiredTargetUnsatisfied = vendorFields !== null && vendorFields.some((entry) => entry.required && (entry.createable || entry.updateable) && objectsInPlay.has(entry.objectApiName) && (contracts.refs.targetByRef.get(entry.targetRef)?.destinationField ?? '') !== '' && !decidedTargets.has(entry.targetRef) && !context.targetsNamedByProposal.has(entry.targetRef));
  const destructivePrimitive = item.transformPrimitive !== null && (PRIMITIVES[item.transformPrimitive]?.destructive ?? false);
  const proof = field === undefined ? null : (decisions.find((decision) => decision.kind === 'IDENTITY_PROOF' && decision.fieldRef === field.fieldRef)?.identityProof ?? null);
  const identityUnproven = proof === 'IDENTITY_SIGNAL' || proof === 'UNIQUE_BUT_UNPROVEN';
  const outsideSupportEnvelope = item.targetRef !== null ? targetInfo !== undefined && targetInfo.destinationField === '' : [...contracts.refs.targetByRef.values()].some((info) => info.destinationField === '' && namesMatch(header, [info.label, info.apiName]));
  return { headerMatchesLabel, headerMatchesApiName, headerMatchesTarget, shapeMatchesTarget, valuesAreTargetOptions, valuesOutsideTargetOptions, uniqueAndPopulated, memoryApplies, headerNamesAnotherObject, noTargetEvidenced, severalTargetsOffered, requiredTargetUnsatisfied, destructivePrimitive, identityUnproven, outsideSupportEnvelope };
}

/** The fact each rationale code claims. Every code of the closed vocabulary has one; there is no code this compiler cannot check. */
function claimHolds(item: ProposalItem, facts: ItemFacts): boolean {
  switch (item.rationaleCode) {
    case 'HEADER_MATCHES_TARGET_LABEL':
      return facts.headerMatchesLabel;
    case 'HEADER_MATCHES_TARGET_API_NAME':
      return facts.headerMatchesApiName;
    case 'SHAPE_MATCHES_TARGET_TYPE':
      return facts.shapeMatchesTarget;
    case 'VALUES_ARE_TARGET_OPTIONS':
      return facts.valuesAreTargetOptions;
    case 'UNIQUE_AND_WELL_FORMED_IDENTIFIER':
      return facts.uniqueAndPopulated;
    case 'MEMORY_CONVENTION_APPLIES':
      return facts.memoryApplies;
    case 'FOREIGN_KEY_COLUMN':
      return facts.headerNamesAnotherObject;
    case 'NO_TARGET_IN_ENVELOPE':
      return facts.noTargetEvidenced;
    case 'AMBIGUOUS_BETWEEN_TARGETS':
      return facts.severalTargetsOffered;
    case 'VALUE_NOT_IN_TARGET_OPTIONS':
      return facts.valuesOutsideTargetOptions;
    case 'REQUIRED_TARGET_UNSATISFIED':
      return facts.requiredTargetUnsatisfied;
    case 'DESTRUCTIVE_NEEDS_AGENCY':
      return facts.destructivePrimitive;
    case 'IDENTITY_NEEDS_PROOF':
      return facts.identityUnproven;
    case 'INSUFFICIENT_EVIDENCE':
      // The claim of having nothing is true when this compiler finds nothing either.
      return !(facts.headerMatchesTarget || facts.shapeMatchesTarget || facts.valuesAreTargetOptions || facts.memoryApplies || facts.uniqueAndPopulated);
    case 'OUT_OF_SUPPORT_ENVELOPE':
      return facts.outsideSupportEnvelope;
  }
}

/**
 * The evidence class from accepted refs and computed facts — auditable rules,
 * no self-declaration: the rationale code selects which fact is claimed, the
 * facts decide whether it holds. A claim the facts contradict is INSUFFICIENT
 * and the item is refused as RATIONALE_NOT_SUPPORTED_BY_FACTS. A claim that
 * holds but defers — a limit the model reports, not a fact that makes the
 * mapping true — is AMBIGUOUS, and an AMBIGUOUS item is never PROPOSED
 * (canon §28: no authority without evidence).
 */
function evidenceClassOf(item: ProposalItem, knownEvidence: ReadonlySet<string>, facts: ItemFacts): { readonly evidenceClass: EvidenceClass; readonly unsupportedClaim: boolean } {
  const accepted = item.evidenceRefs.filter((ref) => knownEvidence.has(ref));
  if (accepted.length === 0) return { evidenceClass: 'INSUFFICIENT', unsupportedClaim: false };
  const holds = claimHolds(item, facts);
  if (holds === false) return { evidenceClass: 'INSUFFICIENT', unsupportedClaim: true };
  if (RATIONALE_KIND[item.rationaleCode] === 'DEFERS') return { evidenceClass: 'AMBIGUOUS', unsupportedClaim: false };
  if (facts.headerMatchesTarget && (facts.memoryApplies || facts.shapeMatchesTarget)) return { evidenceClass: 'STRONG', unsupportedClaim: false };
  return { evidenceClass: 'SUPPORTED', unsupportedClaim: false };
}

export function compileProposal(input: CompileInput): CompiledTask {
  const { envelope, proposal, contracts } = input;
  const codes: string[] = [];
  const digest = digestOf(proposal);
  const refuse = (outcome: TaskOutcome, reason: string, repairable = false): CompiledTask => ({ taskId: envelope.taskId, envelopeHash: input.envelopeHash, proposalDigest: digest, outcome, codes: [...codes, reason], items: [], repairable });

  // 1. Identity: this task, this run, this envelope, this policy and bundle.
  if (proposal.taskId !== envelope.taskId) return refuse('STALE_INPUT', 'TASK_ID_MISMATCH');
  if (proposal.runId !== input.runId) return refuse('STALE_INPUT', 'RUN_ID_MISMATCH');
  if (proposal.envelopeHash !== input.envelopeHash) return refuse('STALE_INPUT', 'ENVELOPE_HASH_MISMATCH');
  if (proposal.modelPolicyVersion !== MODEL_POLICY_VERSION || proposal.promptBundleVersion !== PROMPT_BUNDLE_VERSION) return refuse('INCOMPATIBLE_CONTRACT_VERSION', 'POLICY_OR_BUNDLE_VERSION_MISMATCH');
  if (proposal.items.length > envelope.constraints.maxItems) return refuse('INVALID_SEMANTICS', 'TOO_MANY_ITEMS', true);

  const candidatesByRef = new Map(envelope.deterministicCandidates.map((candidate) => [candidate.candidateRef, candidate]));
  const knownEvidence = new Set([...envelope.deterministicCandidates.flatMap((candidate) => candidate.evidenceRefs), ...envelope.sourceProfile.fields.flatMap((field) => field.evidenceRefs)]);
  const targetFields = envelope.targetContract.mode === 'CLEAN_ONLY' ? null : new Map(envelope.targetContract.fields.map((field) => [field.targetRef, field]));
  const fieldsByRef = new Map(envelope.sourceProfile.fields.map((field) => [field.fieldRef, field]));
  const items: CompiledItem[] = [];
  const targetsNamedByProposal = new Set(proposal.items.map((item) => item.targetRef).filter((ref): ref is string => ref !== null));
  const claimedTargets = new Map<string, string>();
  const seenCandidates = new Set<string>();
  let anyRepairable = false;

  for (const item of proposal.items) {
    const itemCodes: string[] = [];
    let outcome: TaskOutcome = 'PROPOSED';
    let repairable = false;
    const fail = (code: string, kind: TaskOutcome, canRepair = false): void => {
      itemCodes.push(code);
      if (outcome === 'PROPOSED' || kind === 'FORBIDDEN_PROPOSAL') outcome = kind;
      if (canRepair) repairable = true;
    };
    const candidate = candidatesByRef.get(item.candidateRef);
    // 2. References: the candidate, the target, the evidence — all from the envelope.
    if (candidate === undefined) fail('UNKNOWN_CANDIDATE_REF', 'INVALID_SEMANTICS', true);
    if (seenCandidates.has(item.candidateRef)) fail('DUPLICATE_CANDIDATE_ITEM', 'INVALID_SEMANTICS', true);
    seenCandidates.add(item.candidateRef);
    if (!envelope.constraints.allowedProposalTypes.includes(item.proposalType)) fail('PROPOSAL_TYPE_NOT_ALLOWED_FOR_TASK', 'FORBIDDEN_PROPOSAL');
    for (const evidenceRef of item.evidenceRefs) if (!knownEvidence.has(evidenceRef)) fail('INVENTED_EVIDENCE_REF', 'INVALID_SEMANTICS', true);
    const sourceFieldRef = candidate?.sourceRefs[0] ?? null;
    const field = sourceFieldRef === null ? undefined : fieldsByRef.get(sourceFieldRef);
    const needsTarget = item.proposalType === 'MAP_FIELD' || item.proposalType === 'MAP_ENUM_VALUE' || item.proposalType === 'MAP_ASSOCIATION' || item.proposalType === 'MAP_OBJECT';
    let destinationField: string | null = null;
    let semanticType: string | null = null;
    if (needsTarget) {
      if (item.targetRef === null) fail('TARGET_REQUIRED_FOR_MAPPING', 'INVALID_SEMANTICS', true);
      else {
        // 3. TargetContract: the target exists in the exact contract, the candidate may name it, it is writable, the type is compatible.
        if (!envelope.constraints.allowedTargetIds.includes(item.targetRef)) fail('TARGET_OUTSIDE_ENVELOPE', 'FORBIDDEN_PROPOSAL');
        else if (candidate !== undefined && !candidate.allowedTargetRefs.includes(item.targetRef)) fail('TARGET_NOT_ALLOWED_FOR_CANDIDATE', 'INVALID_SEMANTICS', true);
        const targetInfo = contracts.refs.targetByRef.get(item.targetRef);
        destinationField = targetInfo?.destinationField ?? null;
        if (targetInfo === undefined) fail('TARGET_NOT_IN_CONTRACT', 'FORBIDDEN_PROPOSAL');
        // 5. Support envelope: a vendor field Migration Core cannot deliver has no destination field.
        else if (destinationField === '') fail('TARGET_OUTSIDE_SUPPORT_ENVELOPE', 'FORBIDDEN_PROPOSAL');
        if (targetFields !== null) {
          const targetField = targetFields.get(item.targetRef);
          if (targetField === undefined) fail('TARGET_NOT_IN_CONTRACT_VIEW', 'INVALID_SEMANTICS', true);
          else {
            if (!targetField.createable && !targetField.updateable) fail('TARGET_NOT_WRITABLE', 'FORBIDDEN_PROPOSAL');
            const targetSemantic = SEMANTIC_OF_TARGET_TYPE(targetField.type, targetField.options);
            const shape = field?.shapeCandidates[0];
            const sourceSemantic = shape === undefined ? null : (SHAPE_SEMANTIC[shape] ?? null);
            if (sourceSemantic !== null && targetSemantic !== 'TEXT' && targetSemantic !== 'ENUM' && sourceSemantic !== targetSemantic) fail('TYPE_INCOMPATIBLE', 'INVALID_SEMANTICS', true);
            semanticType = targetSemantic === 'ENUM' ? 'ENUM' : (sourceSemantic ?? targetSemantic);
            if (item.proposalType === 'MAP_ENUM_VALUE') {
              const to = item.typedTransformParams?.['to'];
              if (to === undefined || !targetField.options.includes(to)) fail('ENUM_VALUE_NOT_IN_TARGET_OPTIONS', 'INVALID_SEMANTICS', true);
            }
          }
        } else if (item.proposalType === 'MAP_ENUM_VALUE') fail('CLEAN_ONLY_HAS_NO_ENUM_AUTHORITY', 'FORBIDDEN_PROPOSAL');
        // 7. Consistency within the task: one target, one source, or an explicit decision.
        const previous = item.targetRef === null ? undefined : claimedTargets.get(item.targetRef);
        if (previous !== undefined && previous !== item.candidateRef && !item.requiresAgencyDecision) fail('DUPLICATE_TARGET_WITHOUT_RESOLUTION', 'INVALID_SEMANTICS', true);
        if (item.targetRef !== null) claimedTargets.set(item.targetRef, item.candidateRef);
      }
    } else if (item.targetRef !== null && item.proposalType !== 'SELECT_SEMANTIC_TYPE') fail('TARGET_ON_NON_MAPPING_ITEM', 'INVALID_SEMANTICS', true);
    if (item.proposalType === 'SELECT_SEMANTIC_TYPE') {
      const chosen = item.typedTransformParams?.['semanticType'];
      if (chosen === undefined || !['TEXT', 'EMAIL', 'PHONE', 'DATE', 'DATETIME', 'NUMBER', 'IDENTIFIER', 'BOOLEAN', 'ENUM', 'URL'].includes(chosen)) fail('SEMANTIC_TYPE_NOT_IN_VOCABULARY', 'INVALID_SEMANTICS', true);
      else semanticType = chosen;
    }
    // 4. Primitives and parameters: closed catalogue, closed domains, the semantic type it applies to.
    if (item.transformPrimitive !== null) {
      const primitive = PRIMITIVES[item.transformPrimitive];
      if (!envelope.constraints.supportedTransformPrimitives.includes(item.transformPrimitive)) fail('PRIMITIVE_NOT_SUPPORTED', 'FORBIDDEN_PROPOSAL');
      // The candidate's own allowlist is a second, narrower catalogue: a primitive the envelope supports but this candidate does not carry is outside what the task offered.
      if (candidate !== undefined && !candidate.allowedPrimitiveRefs.includes(item.transformPrimitive)) fail('PRIMITIVE_NOT_ALLOWED_FOR_CANDIDATE', 'FORBIDDEN_PROPOSAL');
      if (primitive.destructive) fail('DESTRUCTIVE_PRIMITIVE_BY_MODEL', 'FORBIDDEN_PROPOSAL');
      const params = item.typedTransformParams ?? {};
      for (const name of Object.keys(params)) {
        if (!(primitive.params as readonly string[]).includes(name) && !(item.proposalType === 'SELECT_SEMANTIC_TYPE' && name === 'semanticType')) fail(`UNKNOWN_PARAM_${name.toUpperCase()}`, 'INVALID_SEMANTICS', true);
        const domain = PRIMITIVE_PARAM_DOMAINS[name];
        const value = params[name] ?? '';
        if (domain !== undefined && !domain.test(value)) fail(`PARAM_OUT_OF_DOMAIN_${name.toUpperCase()}`, 'INVALID_SEMANTICS', true);
      }
      if (item.transformPrimitive === 'PARSE_PHONE_E164' && params['defaultRegion'] !== undefined) {
        // A region is evidence, not geography: it must appear in the envelope's memory or field facts, which V1 cannot yet carry, so it is refused.
        fail('PHONE_REGION_NOT_EVIDENCED', 'INVALID_SEMANTICS', true);
      }
      if (semanticType !== null && !(primitive.semanticTypes as readonly string[]).includes(semanticType)) fail('PRIMITIVE_DOES_NOT_APPLY_TO_TYPE', 'INVALID_SEMANTICS', true);
    } else if (item.typedTransformParams !== null && item.proposalType !== 'SELECT_SEMANTIC_TYPE' && item.proposalType !== 'MAP_ENUM_VALUE') fail('PARAMS_WITHOUT_PRIMITIVE', 'INVALID_SEMANTICS', true);
    // 6. Authority: identity is never proven by the model; destructive and merge-like proposals need the agency.
    if (item.proposalType === 'PROPOSE_IDENTITY_STRATEGY' || item.proposalType === 'PROPOSE_DUPLICATE_SIGNAL') {
      if (!item.requiresAgencyDecision) {
        const proof = input.decisions.find((decision) => decision.kind === 'IDENTITY_PROOF' && decision.fieldRef === sourceFieldRef)?.identityProof ?? 'NO_EVIDENCE';
        if (proof !== 'PROVEN_UNIQUE_IDENTIFIER') fail('IDENTITY_WITHOUT_PROOF_NEEDS_AGENCY', 'FORBIDDEN_PROPOSAL');
      }
    }
    if (item.proposalType === 'NEEDS_AGENCY_DECISION' && !item.requiresAgencyDecision) fail('AGENCY_ITEM_MUST_REQUIRE_AGENCY', 'INVALID_SEMANTICS', true);
    if (item.shortRationale !== null && item.shortRationale.length > envelope.constraints.maxRationaleLength) fail('RATIONALE_TOO_LONG', 'INVALID_SEMANTICS', true);
    if (item.shortRationale !== null && /[{}<>;`]|=>|\bfunction\b|\bselect\b.*\bfrom\b/iu.test(item.shortRationale)) fail('RATIONALE_LOOKS_LIKE_CODE', 'FORBIDDEN_PROPOSAL');
    if (item.proposalType === 'ABSTAIN' && item.abstainReason === null) fail('ABSTAIN_WITHOUT_REASON', 'INVALID_SEMANTICS', true);
    if ((item.proposalType === 'NEEDS_AGENCY_DECISION' || item.requiresAgencyDecision) && outcome === 'PROPOSED') outcome = 'REQUIRES_AGENCY_DECISION';
    if ((item.proposalType === 'ABSTAIN' || item.proposalType === 'UNMAPPED_PRESERVE') && outcome === 'PROPOSED') outcome = 'ABSTAINED';
    if (item.proposalType === 'BLOCKING_TARGET_REQUIREMENT' && outcome === 'PROPOSED') outcome = 'REQUIRES_AGENCY_DECISION';
    const { evidenceClass, unsupportedClaim } = evidenceClassOf(item, knownEvidence, itemFacts(item, { envelope, contracts, candidate, field, decisions: input.decisions, targetsNamedByProposal }));
    if (outcome === 'PROPOSED' && evidenceClass === 'INSUFFICIENT') {
      // A proposal standing on its own needs a fact behind its claim; a claim the facts contradict is refused by name.
      fail(unsupportedClaim ? 'RATIONALE_NOT_SUPPORTED_BY_FACTS' : 'INSUFFICIENT_EVIDENCE_FOR_PROPOSAL', 'INVALID_SEMANTICS', true);
    }
    if (outcome === 'PROPOSED' && evidenceClass === 'AMBIGUOUS') {
      // The claim holds but decides nothing — a foreign key, an ambiguity, a missing proof, insufficient evidence: the agency decides, the model does not (canon §28).
      fail('AMBIGUOUS_EVIDENCE_NEEDS_AGENCY', 'REQUIRES_AGENCY_DECISION');
    }
    if (repairable) anyRepairable = true;
    items.push({ candidateRef: item.candidateRef, proposalType: item.proposalType, outcome, codes: itemCodes, targetRef: item.targetRef, destinationField: destinationField === '' ? null : destinationField, sourceFieldRef, semanticType, transformPrimitive: item.transformPrimitive, typedTransformParams: item.typedTransformParams, evidenceClass, evidenceRefs: item.evidenceRefs.filter((ref) => knownEvidence.has(ref)), requiresAgencyDecision: item.requiresAgencyDecision, rationaleCode: item.rationaleCode, impactRows: candidate?.impactCounts.rows ?? 0 });
  }
  // Every candidate of the task is answered; a candidate left out is not mapped anywhere, so it is preserved and reported.
  for (const candidate of envelope.deterministicCandidates) {
    if (!seenCandidates.has(candidate.candidateRef)) {
      items.push({ candidateRef: candidate.candidateRef, proposalType: 'UNMAPPED_PRESERVE', outcome: 'ABSTAINED', codes: ['CANDIDATE_NOT_ANSWERED_PRESERVED'], targetRef: null, destinationField: null, sourceFieldRef: candidate.sourceRefs[0] ?? null, semanticType: null, transformPrimitive: null, typedTransformParams: null, evidenceClass: 'INSUFFICIENT', evidenceRefs: [], requiresAgencyDecision: false, rationaleCode: 'INSUFFICIENT_EVIDENCE', impactRows: candidate.impactCounts.rows });
    }
  }
  const forbidden = items.some((item) => item.outcome === 'FORBIDDEN_PROPOSAL');
  const invalid = items.some((item) => item.outcome === 'INVALID_SEMANTICS');
  const outcome: TaskOutcome = forbidden ? 'FORBIDDEN_PROPOSAL' : invalid ? 'INVALID_SEMANTICS' : items.every((item) => item.outcome === 'ABSTAINED') ? 'ABSTAINED' : items.some((item) => item.outcome === 'REQUIRES_AGENCY_DECISION') ? 'REQUIRES_AGENCY_DECISION' : 'PROPOSED';
  return { taskId: envelope.taskId, envelopeHash: input.envelopeHash, proposalDigest: digest, outcome, codes: [...codes, ...items.flatMap((item) => item.codes)], items, repairable: !forbidden && invalid && anyRepairable };
}
