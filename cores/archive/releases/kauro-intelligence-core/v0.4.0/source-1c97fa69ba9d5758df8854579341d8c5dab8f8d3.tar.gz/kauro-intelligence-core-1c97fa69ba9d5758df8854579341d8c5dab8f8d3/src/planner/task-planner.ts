/**
 * The Task Planner, canon §62–§63: open questions are partitioned by semantic
 * complexity into at most MAX_SEMANTIC_TASKS_PER_AUDIT tasks with stable ids
 * and a stable order — object interpretation, field mapping per batch, value
 * maps, identity and association strategy, consistency review. There is no
 * task per row or per cell; a question the resolver already answered never
 * becomes a task; and when the cap is reached the questions left out are
 * visible as abstentions, never silently dropped.
 */
import { digestOf } from '../contracts/canonical.js';
import type { TaskType } from '../contracts/envelope.js';
import { BUDGET_LIMITS } from '../contracts/run.js';
import type { TaskRecord } from '../contracts/run.js';
import type { OpenQuestion } from '../resolver/deterministic-resolver.js';

export interface Plan {
  readonly tasks: readonly TaskRecord[];
  /** Questions no task carries because the cap was reached; each is an ABSTAINED item in the result. */
  readonly leftOut: readonly OpenQuestion[];
  readonly partitions: number;
}

const ORDER: readonly TaskType[] = ['OBJECT_MAPPING', 'FIELD_MAPPING', 'SEMANTIC_TYPE', 'TRANSFORMATION_SELECTION', 'VALUE_MAP', 'IDENTITY_STRATEGY', 'DUPLICATE_SIGNAL_STRATEGY', 'ASSOCIATION_MAPPING', 'UNMAPPED_HANDLING', 'TARGET_REQUIREMENT', 'CONSISTENCY_REVIEW', 'SEMANTIC_REPAIR'];

/** Complexity a batch may carry before it is split: plausible answers across its questions. */
export const MAX_COMPLEXITY_PER_TASK = 48;
export const MAX_QUESTIONS_PER_TASK = 12;

export function plan(projectRevisionHash: string, questions: readonly OpenQuestion[], maxTasks = BUDGET_LIMITS.MAX_SEMANTIC_TASKS_PER_AUDIT): Plan {
  const sorted = [...questions].sort((a, b) => ORDER.indexOf(a.taskType) - ORDER.indexOf(b.taskType) || (a.questionRef < b.questionRef ? -1 : 1));
  const batches: { taskType: TaskType; questions: OpenQuestion[]; complexity: number }[] = [];
  for (const question of sorted) {
    const last = batches[batches.length - 1];
    if (last !== undefined && last.taskType === question.taskType && last.questions.length < MAX_QUESTIONS_PER_TASK && last.complexity + question.complexity <= MAX_COMPLEXITY_PER_TASK) {
      last.questions.push(question);
      last.complexity += question.complexity;
    } else {
      batches.push({ taskType: question.taskType, questions: [question], complexity: question.complexity });
    }
  }
  const tasks: TaskRecord[] = [];
  const leftOut: OpenQuestion[] = [];
  batches.forEach((batch, index) => {
    if (tasks.length >= maxTasks) {
      leftOut.push(...batch.questions);
      return;
    }
    const partitionKey = `${batch.taskType}:${String(index)}`;
    tasks.push({
      taskId: `task_${digestOf([projectRevisionHash, partitionKey, batch.questions.map((question) => question.questionRef)]).slice(0, 16)}`,
      taskType: batch.taskType,
      partitionKey,
      candidateRefs: batch.questions.flatMap((question) => question.candidateRefs),
      order: tasks.length,
    });
  });
  return { tasks, leftOut, partitions: batches.length };
}
