/**
 * The host boundary, canon §100: what the host supplies and what it is
 * handed back. The core receives DTOs and handles, never storage, queues,
 * credentials or a path to open a file. The validation port is the seam
 * through which a candidate configuration is applied to the whole dataset
 * with Migration Core's semantics — by the host, never by this core.
 */
import type { HashedCandidateSet, HashedSourceProfile, HashedTargetContract, TargetMode } from 'kavo-migration-core';

import type { CategoricalSummaries } from '../envelope/envelope-builder.js';
import type { ModelGateway } from '../gateway/model-gateway.js';
import type { Clock, LedgerStore } from '../kernel/ledger.js';
import type { MemoryEntry } from '../contracts/run.js';
import { CONTRACT_HASH_PATTERN, HEX64_PATTERN, INSTANT_PATTERN, VERSION_PATTERN, s } from '../contracts/schema.js';
import type { Schema } from '../contracts/schema.js';

export interface HostContext {
  /** Authenticated by the host; an id in a payload grants nothing. */
  readonly tenant: { readonly agencyId: string; readonly clientId: string };
  readonly actor: string;
  /**
   * The logical identity of this AuditAttempt, minted by the host once per
   * attempt the agency asked for. A redelivery of the same attempt carries the
   * same id and finds its run; a new attempt the agency authorised carries a
   * new one. Time is never part of a run's identity. The id names one content
   * — revision, hashes, versions — for good: the same id with other content
   * is refused as IDENTITY_CONFLICT before anything is spent.
   */
  readonly auditAttemptId: string;
}

export interface ProjectRevision {
  readonly projectRevisionId: string;
  readonly projectRevisionHash: string;
  readonly mode: TargetMode;
  readonly supportEnvelopeVersion: string;
  /**
   * The canonical object each source file is declared to hold, by the path the
   * profile recorded — an authorised fact of the project, set up by the
   * agency, never inferred by the model. A file with no declaration gets its
   * object resolved deterministically when the headers make it unambiguous,
   * and an OBJECT_MAPPING question otherwise.
   */
  readonly declaredObjects?: Readonly<Record<string, 'CONTACT' | 'COMPANY' | 'DEAL' | 'LEAD'>>;
  /**
   * The source record id column each file is declared to carry, by the path
   * the profile recorded — the identity Migration Core itself runs the file
   * on, declared by the project and never inferred. It is the only authority
   * that makes a source column a PROVEN_UNIQUE_IDENTIFIER in CLEAN_ONLY; a
   * unique email, phone or name declared here is still a signal, not a proof.
   */
  readonly recordIdColumns?: Readonly<Record<string, string>>;
}

export interface ResourceProfile {
  readonly wallClockMs?: number;
}

export interface IntelligenceInput {
  readonly projectRevision: ProjectRevision;
  readonly sourceProfile: HashedSourceProfile;
  readonly candidateSet: HashedCandidateSet;
  readonly targetContract: HashedTargetContract | null;
  readonly scopedMemorySnapshot: readonly MemoryEntry[];
  /** Low-cardinality values the host extracted per column locator; the only path a value has into this core. */
  readonly categoricalSummaries?: CategoricalSummaries;
  readonly policyBundle: { readonly modelPolicyVersion: string; readonly promptBundleVersion: string };
  readonly resourceProfile: ResourceProfile;
}

/**
 * One field mapping the compiler emits: a MigrationConfig fragment the host
 * applies. Every member is authorised content the host must carry into
 * Migration Core's configuration — the column by its locator (the physical
 * index the profile recorded, not only the header, which may repeat), the
 * destination, the semantic type, and the primitive with its parameters. A
 * primitive the frozen configuration schema cannot express is reported by
 * the host as a problem, never dropped on the way.
 */
export interface ConfigFragmentField {
  readonly recordId: string;
  /** The profile's file id and the path it profiled, so the host can name the file in its own configuration. */
  readonly fileId: string;
  readonly filePath: string;
  readonly object: string;
  readonly columnHeader: string;
  readonly columnLocator: string;
  readonly destinationField: string;
  readonly semanticType: string;
  readonly transformPrimitive: string | null;
  readonly typedTransformParams: Readonly<Record<string, string>> | null;
  /**
   * For an ENUM destination, the options of the target field as the attested
   * contract lists them — what Migration Core's configuration needs as
   * `allowedValues` so a value outside the set is reported, never accepted
   * silently. Present exactly when the semantic type is ENUM; copied from the
   * contract, never from the source values or the proposal.
   */
  readonly allowedValues?: readonly string[];
}

export interface CandidateConfiguration {
  readonly configurationRef: string;
  readonly mode: TargetMode;
  readonly profileHash: string;
  readonly candidateSetHash: string;
  readonly targetContractHash: string | null;
  readonly fields: readonly ConfigFragmentField[];
}

/**
 * What the host's validation port answers. Typed and bound: the hashes it
 * validated against, the exact bytes of the configuration it applied, the
 * rows it covered, every problem, and references to what Migration Core
 * produced. The core validates this receipt against a closed schema and
 * against what it knows — the configuration it handed over, the profile's
 * row count, the run's start, the supported core version — and a receipt
 * that fails any of it blocks the draft. A port returning `ok: true` with no
 * rows validated is a stub and is refused.
 *
 * The port is a trust boundary of the host (threat T21). A host that forges
 * every fact — hashes, counts, digests and evidence alike — cannot be
 * caught by any check on the receipt's shape or consistency; what these
 * checks catch is a defective, stale or partial adapter, which is the
 * realistic failure. The evidence references exist for the other case: an
 * auditor with access to the host's package store can check that the
 * package and report the receipt names were really produced from the
 * configuration the run compiled.
 */
export interface FullDatasetValidationResult {
  readonly ok: boolean;
  readonly configurationRef: string;
  /** digestOf(configuration) as the port received it: the receipt names the exact configuration bytes, not only a ref. */
  readonly configurationDigest: string;
  readonly profileHash: string;
  readonly candidateSetHash: string;
  readonly targetContractHash: string | null;
  readonly rowsValidated: number;
  readonly rowsInProfile: number;
  readonly reconciliationHolds: boolean;
  readonly packageVerified: boolean;
  readonly problems: readonly string[];
  /**
   * When the host validated, by the clock it hands this core: not before the
   * run was created and not after that clock's now, with no tolerance. The
   * host and the core share one clock discipline across this boundary; a
   * receipt dated by another clock is refused (VALIDATION_AFTER_NOW).
   */
  readonly validatedAt: string;
  readonly coreVersion: string;
  /**
   * What Migration Core produced, by digest, so what really ran can be
   * checked outside this core. Null where nothing was produced — which a
   * verified verdict cannot claim: ok or packageVerified with no package
   * digest or no report digest is VALIDATION_RECEIPT_INCONSISTENT.
   */
  readonly evidence: {
    /** The package manifest's sha256 as Migration Core wrote it. */
    readonly packageDigest: string | null;
    /** digestOf the verifier's report, path excluded. */
    readonly reportDigest: string | null;
    /** Migration Core's own hash of the configuration the host loaded. */
    readonly coreConfigHash: string | null;
  };
}

const hex64 = s.string({ pattern: HEX64_PATTERN });
const contractHash = s.string({ pattern: CONTRACT_HASH_PATTERN });
const counter = s.integer({ min: 0, max: Number.MAX_SAFE_INTEGER });

/** The receipt's closed shape: every member present and typed, counts finite integers, instants and versions well-formed. */
export const FULL_DATASET_VALIDATION_RESULT_SCHEMA: Schema = s.object({
  ok: s.boolean(),
  configurationRef: s.string({ nonBlank: true, maxLength: 128 }),
  configurationDigest: hex64,
  profileHash: contractHash,
  candidateSetHash: contractHash,
  targetContractHash: s.nullable(contractHash),
  rowsValidated: counter,
  rowsInProfile: counter,
  reconciliationHolds: s.boolean(),
  packageVerified: s.boolean(),
  problems: s.array(s.string({ maxLength: 512 }), { maxItems: 4096 }),
  validatedAt: s.string({ pattern: INSTANT_PATTERN }),
  coreVersion: s.string({ pattern: VERSION_PATTERN }),
  evidence: s.object({ packageDigest: s.nullable(hex64), reportDigest: s.nullable(hex64), coreConfigHash: s.nullable(contractHash) }),
});

export interface FullDatasetValidationPort {
  validate(configuration: CandidateConfiguration): Promise<FullDatasetValidationResult>;
}

export interface CoreDependencies {
  readonly gateway: ModelGateway;
  readonly validationPort: FullDatasetValidationPort;
  readonly ledgerStore: LedgerStore;
  readonly clock: Clock;
  /** Payload-free telemetry: counters and codes only. */
  readonly telemetry?: (event: { readonly runId: string; readonly kind: string; readonly counters: Readonly<Record<string, number>>; readonly codes: readonly string[] }) => void;
  /** Bytes for the egress token; generated per core instance when absent. */
  readonly egressSecret?: Buffer;
  /** Waits between transport retries; a test injects one that moves the virtual clock instead of sleeping. */
  readonly sleep?: (ms: number) => Promise<void>;
  /** Names this process in the ledger's lease, for the record; generated per core instance when absent. It is not the owner: the owner of an attempt is one run() invocation, by a token the ledger mints for it, so two cores — or two run() calls on one core — never share ownership by sharing a name. */
  readonly workerId?: string;
  /**
   * A repeating timer of the host's: `ticker(intervalMs, onTick)` starts it and
   * returns what stops it. The core renews its lease on it while it waits on
   * the provider or on the host's validation, so a call longer than the lease
   * does not lose the attempt to a takeover. setInterval when absent; a test
   * injects one it fires by hand on the virtual clock.
   */
  readonly ticker?: (intervalMs: number, onTick: () => void) => () => void;
}
