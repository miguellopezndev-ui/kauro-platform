/**
 * The public host API and the orchestration of one IntelligenceRun.
 *
 * validate versions → adapt contracts → resolve deterministically → plan →
 * for each task: memory → minimize → envelope → egress → reserve → gateway
 * (bounded transport retries) → parse → compile → one repair at most →
 * assemble → cross-task consistency → full-dataset validation through the
 * host port → draft or abstain; every step in the ledger, every failure an
 * explicit outcome and a terminal state, no loop without a bound.
 */
import { randomBytes } from 'node:crypto';

import { adaptContracts } from '../adapter/contract-adapter.js';
import type { AdaptedContracts } from '../adapter/contract-adapter.js';
import { digestOf } from '../contracts/canonical.js';
import type { BudgetSnapshot, DeterministicCandidate, IntelligenceEnvelopeV1, RepairContext } from '../contracts/envelope.js';
import { IntelligenceError, isIntelligenceError } from '../contracts/errors.js';
import type { TaskOutcome } from '../contracts/errors.js';
import { BUDGET_LIMITS, TERMINAL_RUN_STATES, WORKER_LEASE_MS, WORKER_LEASE_RENEWAL_MS } from '../contracts/run.js';
import type { MemoryCandidate, RunState, TaskRecord, TaskResult } from '../contracts/run.js';
import type { EvidenceClass } from '../contracts/proposal.js';
import { validate } from '../contracts/schema.js';
import { COMPILER_CONTRACT_VERSION, ENVELOPE_SCHEMA_VERSION, INTELLIGENCE_CORE_VERSION, MEMORY_CONTRACT_VERSION, MODEL_POLICY_VERSION, PROMPT_BUNDLE_VERSION, PROPOSAL_SCHEMA_VERSION, SUPPORTED_MIGRATION_CORE, compatibilityProblems } from '../contracts/versions.js';
import { compileProposal, parseProposal } from '../compiler/compiler.js';
import type { CompiledItem, CompiledTask } from '../compiler/compiler.js';
import { DATA_POLICY_VERSION, MASKING_POLICY_VERSION, assertEgressBinds, buildEnvelope } from '../envelope/envelope-builder.js';
import type { EgressDecision } from '../envelope/envelope-builder.js';
import { MODEL_POLICY_V1, PROMPT_BUNDLE_HASH, PROMPT_BUNDLE_V1 } from '../gateway/model-gateway.js';
import type { GatewayResult, GatewayUsage } from '../gateway/model-gateway.js';
import { RunLedger, usageIsValid } from '../kernel/ledger.js';
import type { LedgerEvent } from '../kernel/ledger.js';
import { memoryCandidateFrom, resolveMemory } from '../memory/memory-resolver.js';
import { plan } from '../planner/task-planner.js';
import { FULL_DATASET_VALIDATION_RESULT_SCHEMA } from '../ports/ports.js';
import type { CandidateConfiguration, ConfigFragmentField, CoreDependencies, FullDatasetValidationResult, HostContext, IntelligenceInput } from '../ports/ports.js';
import { resolve } from '../resolver/deterministic-resolver.js';
import type { ResolvedDecision } from '../resolver/deterministic-resolver.js';

export interface DraftMigrationPlan {
  readonly planVersion: string;
  readonly status: 'SYSTEM_DRAFT' | 'NOT_DRAFTABLE';
  readonly configuration: CandidateConfiguration | null;
  readonly impact: { readonly fieldsMapped: number; readonly rowsCovered: number; readonly fieldsPreserved: number };
  /** One entry per configuration field and per accepted proposal: what decided it (a deterministic rule or the model's proposal, by `origin`), on what class of evidence, and which refs. */
  readonly evidence: readonly DraftEvidence[];
  readonly unresolved: readonly { readonly candidateRef: string; readonly outcome: TaskOutcome; readonly codes: readonly string[] }[];
  readonly unsupportedPreserved: readonly string[];
  readonly decisionsRequired: readonly { readonly candidateRef: string; readonly reason: string }[];
  readonly fullValidation: FullDatasetValidationResult | null;
  readonly note: 'A SYSTEM_DRAFT is not an approval, a quote or an authorisation to execute.';
}

/**
 * Where a drafted field came from. DETERMINISTIC: the resolver decided it
 * on facts (the `rationaleCode` is the resolver's rule, the `candidateRef`
 * the decision's stable ref); PROPOSED: the model proposed it and the
 * compiler accepted it. Every configuration field has an entry of one origin
 * or the other (IC-09): a draft never carries a field nothing accounts for.
 */
export type DraftEvidenceOrigin = 'DETERMINISTIC' | 'PROPOSED';

export interface DraftEvidence {
  readonly origin: DraftEvidenceOrigin;
  readonly candidateRef: string;
  readonly evidenceClass: EvidenceClass;
  readonly rationaleCode: string;
  readonly evidenceRefs: readonly string[];
  readonly sourceFieldRef: string | null;
  readonly targetRef: string | null;
  readonly destinationField: string | null;
  readonly semanticType: string | null;
  readonly transformPrimitive: string | null;
  readonly typedTransformParams: Readonly<Record<string, string>> | null;
}

/** The evidence class a deterministic rule stands on: an exact header match with a compatible shape is what the compiler calls STRONG for a proposal; any other rule that maps a field is SUPPORTED by its facts. */
const DETERMINISTIC_EVIDENCE_CLASS: Readonly<Record<string, EvidenceClass>> = Object.freeze({ EXACT_HEADER_MATCH_AND_COMPATIBLE_SHAPE: 'STRONG' });

export interface IntelligenceResult {
  readonly proposalRef: string;
  readonly proposalDigest: string;
  readonly runLedger: readonly LedgerEvent[];
  readonly runId: string;
  readonly state: string;
  readonly tasks: readonly TaskResult[];
  readonly draft: DraftMigrationPlan;
  readonly unresolvedItems: readonly { readonly candidateRef: string; readonly outcome: TaskOutcome; readonly codes: readonly string[] }[];
  readonly memoryCandidates: readonly MemoryCandidate[];
  /**
   * What the run cost, read off the ledger: every invocation that reached a
   * reservation, those that came back with a response, and the tokens —
   * everything the provider reported plus the full size of every reservation
   * whose fate is unknown, which is reported separately as well.
   */
  readonly resourceEvidence: { readonly providerInvocations: number; readonly modelCalls: number; readonly ambiguousReservations: number; readonly billedInputTokens: number; readonly billedOutputTokens: number; readonly ambiguousInputTokens: number; readonly ambiguousOutputTokens: number; readonly tasksPlanned: number; readonly tasksLeftOut: number; readonly deterministicDecisions: number; readonly wallClockMs: number };
  readonly provenance: { readonly intelligenceCoreVersion: string; readonly envelopeSchemaVersion: string; readonly proposalSchemaVersion: string; readonly promptBundleVersion: string; readonly promptBundleHash: string; readonly modelPolicyVersion: string; readonly modelPolicyHash: string; readonly dataPolicyVersion: string; readonly maskingPolicyVersion: string; readonly memoryContractVersion: string; readonly compilerContractVersion: string; readonly profileHash: string; readonly candidateSetHash: string; readonly targetContractHash: string | null; readonly projectRevisionHash: string };
}

export interface IntelligenceCore {
  run(input: IntelligenceInput, context: HostContext): Promise<IntelligenceResult>;
  cancel(runId: string, reason: string): void;
  readRun(runId: string): readonly LedgerEvent[];
}

const RETRY_BACKOFF_MS = [50, 200] as const;
/** A Retry-After beyond this is a provider asking the run to wait out its own deadline; the run fails the task instead. */
const MAX_RETRY_WAIT_MS = 60_000;

const realSleep = (ms: number): Promise<void> => new Promise((resolveWait) => setTimeout(resolveWait, ms));
const realTicker = (intervalMs: number, onTick: () => void): (() => void) => {
  const handle = setInterval(onTick, intervalMs);
  handle.unref();
  return () => clearInterval(handle);
};

/** The figure as the ledger counts it: the cache categories folded into the input and kept beside it, so the drift they show can be read back off the stored response. */
interface CountedUsage extends GatewayUsage {
  readonly cacheCreationInputTokens: number;
  readonly cacheReadInputTokens: number;
}

/** A cache category as the provider reported it: absent or null is none, a count is a count, anything else makes the whole figure unknown. */
function cacheCountOf(value: number | null | undefined): number | null {
  if (value === undefined || value === null) return 0;
  return typeof value === 'number' && Number.isFinite(value) && Number.isInteger(value) && value >= 0 ? value : null;
}

/**
 * What the provider consumed for one invocation, or null when it reported
 * nothing the ledger can count. The cache categories are billable input and
 * are counted into it whenever they are reported; one reported malformed
 * makes the whole figure unknown. A response that carries content and
 * reports zero tokens in and out is a placeholder, not a measurement: unknown
 * as well, and billed at the reservation like any unknown.
 */
function reportedUsage(result: GatewayResult): CountedUsage | null {
  if (result.kind === 'AMBIGUOUS' || !usageIsValid(result.usage)) return null;
  const cacheRead = cacheCountOf(result.usage.cacheReadInputTokens);
  const cacheCreation = cacheCountOf(result.usage.cacheCreationInputTokens);
  if (cacheRead === null || cacheCreation === null) return null;
  const inputTokens = result.usage.inputTokens + cacheRead + cacheCreation;
  if (result.kind === 'RESPONSE' && result.content !== '' && inputTokens === 0 && result.usage.outputTokens === 0) return null;
  return { inputTokens, outputTokens: result.usage.outputTokens, cacheReadInputTokens: cacheRead, cacheCreationInputTokens: cacheCreation };
}

/** Cache tokens reported under a policy that has the cache off: billed all the same, and named as drift on the task. */
function cacheDriftOf(result: GatewayResult): { readonly cacheReadInputTokens: number; readonly cacheCreationInputTokens: number } | null {
  if (result.kind === 'AMBIGUOUS' || result.usage === null || MODEL_POLICY_V1.promptCache !== 'OFF') return null;
  const drift = { cacheReadInputTokens: cacheCountOf(result.usage.cacheReadInputTokens) ?? 0, cacheCreationInputTokens: cacheCountOf(result.usage.cacheCreationInputTokens) ?? 0 };
  return drift.cacheReadInputTokens + drift.cacheCreationInputTokens > 0 ? drift : null;
}

const CACHE_DRIFT_CODE = 'CACHE_USAGE_UNDER_CACHE_OFF';

/** What the record says when the gateway threw: that it threw. The error's own text stays out of it, as a provider's does (R2-028). */
const GATEWAY_THREW = 'the gateway threw; its text is withheld';

/** The gateway's own fixed reasons: a status, a timeout, a missing or forbidden member, a paused turn. Nothing in them is anybody's data. */
const OWN_REASON = /^(?:provider status \d{3}|the provider timed out after the request was sent; billing is unknown|the provider answered 200 with no object body|the provider answered with no stop_reason|the provider answered with no content list|the provider answered with a tool call to a request that offered no tools|the provider paused the turn; a continuation would need provider conversation state, which no request carries|the provider answered with no text content|the gateway threw; its text is withheld)$/u;
/** The stage prefix the transport gateway puts before a transport's own message. */
const STAGED_REASON = /^(BEFORE_SEND|AFTER_SEND|UNKNOWN): /u;

/**
 * What the ledger and the result keep of a gateway's reason (R2-028). A
 * reason is either the gateway's own fixed words, kept as they are, or a
 * provider's or a transport's text — an error that echoes the submitted
 * body, a credential in a message or an error code, customer text, a model
 * name the provider wrote — which is withheld: the record keeps its kind,
 * the stage it failed at and, for a wrong model, the model that was pinned,
 * and nothing the core did not write. The bytes the provider answered with
 * stay in the response store under its own retention class; nothing here
 * reaches telemetry, which carries counters and states only.
 */
function recordedReason(reason: string): string {
  if (OWN_REASON.test(reason)) return reason;
  const stage = STAGED_REASON.exec(reason)?.[1];
  if (stage !== undefined) return `${stage}: transport failure; its text is withheld`;
  if (reason.startsWith('the provider answered with model ')) return `the provider answered with another model than the pinned ${MODEL_POLICY_V1.primaryModel}; its name is withheld`;
  return 'the gateway gave a reason in words that are not its own; the text is withheld';
}

/** One request answered: the result, whether the ledger already held it, the hash of the envelope it answers, and what the invocations showed about the policy. */
interface GatewayCall {
  readonly result: GatewayResult;
  readonly fromStore: boolean;
  readonly envelopeHash: string;
  readonly codes: readonly string[];
}

export function createIntelligenceCore(deps: CoreDependencies): IntelligenceCore {
  const egressSecret = deps.egressSecret ?? randomBytes(32);
  const telemetry = deps.telemetry ?? ((): void => undefined);
  const sleep = deps.sleep ?? realSleep;
  const ticker = deps.ticker ?? realTicker;
  // The process name in the lease, for the record. Not the owner: each run() opens its own ledger handle, whose token is what the lease binds and every write is checked against.
  const workerId = deps.workerId ?? `worker_${randomBytes(8).toString('hex')}`;

  /**
   * One long await — the provider call, the host's validation — with the
   * lease renewed every WORKER_LEASE_RENEWAL_MS on the host's timer while it
   * lasts, so a call longer than the lease does not hand the attempt to a
   * takeover that would buy the same request again. A renewal that loses
   * its append to a writer that did not take the run — the host's cancel, a
   * note — is tried again on the next tick, on the re-read log; the lease
   * survives three missed renewals, so one lost tick lapses nothing. Only a
   * lease now held by another owner ends the renewals: the run was taken
   * over, and the owner learns at its next write, which the fence refuses.
   */
  async function keepingLease<T>(ledger: RunLedger, work: () => Promise<T>): Promise<T> {
    let renewing = true;
    const stop = ticker(WORKER_LEASE_RENEWAL_MS, () => {
      if (!renewing) return;
      try {
        ledger.acquireLease(workerId, WORKER_LEASE_MS);
      } catch {
        const holder = ledger.view().lease;
        if (holder !== null && holder.ownerId !== ledger.ownerId) {
          renewing = false;
          stop();
        }
      }
    });
    try {
      return await work();
    } finally {
      renewing = false;
      stop();
    }
  }

  /**
   * One request to the provider: at most the initial send plus the bounded
   * transport retries, and every one of them its own reservation, reconciled
   * against what actually came back before the next is made. A response of
   * any kind commits the usage it reports; a failure that reports usage
   * commits it as billed and unusable; a failure that reports none is
   * ambiguous — kept at full size — unless it carries the transport's proof
   * that the request never left, which is the only thing that releases a
   * reservation. A response already in the ledger — under the request's
   * semantic key, whatever budget snapshot this build of the envelope
   * carries — is returned without any of this, together with the hash of
   * the envelope it answered, which is the one the proposal names.
   */
  async function callGateway(ledger: RunLedger, envelope: IntelligenceEnvelopeV1, envelopeHash: string, egress: EgressDecision, attempt: number): Promise<GatewayCall> {
    const idempotencyKey = RunLedger.idempotencyKey({ taskId: envelope.taskId, attempt, modelPolicyVersion: MODEL_POLICY_VERSION, promptBundleVersion: PROMPT_BUNDLE_VERSION, promptBundleHash: PROMPT_BUNDLE_HASH, envelope });
    const stored = ledger.storedResponse(idempotencyKey);
    if (stored !== undefined) return { result: stored.response as GatewayResult, fromStore: true, envelopeHash: stored.envelopeHash, codes: cacheDriftOf(stored.response as GatewayResult) === null ? [] : [CACHE_DRIFT_CODE] };
    // The estimate is what is reserved; one above the ceiling is refused by the ledger, never trimmed to fit.
    const estimatedInput = Math.ceil(JSON.stringify(envelope).length / 3) + 2_000;
    // The gateway path verifies the egress binding itself; a caller cannot hand it a boolean.
    assertEgressBinds(egress, envelope, egressSecret);
    const request = { modelPolicy: MODEL_POLICY_V1, promptBundleRef: { promptBundleVersion: PROMPT_BUNDLE_V1.promptBundleVersion, promptBundleHash: PROMPT_BUNDLE_HASH }, envelope, envelopeHash, runId: ledger.runId, outputSchema: PROMPT_BUNDLE_V1.outputSchema, deadlineAt: ledger.view().deadlineAt, idempotencyRef: idempotencyKey, maxOutputTokens: BUDGET_LIMITS.MAX_OUTPUT_TOKENS_PER_REQUEST };
    const codes = new Set<string>();
    const answered = (result: GatewayResult): GatewayCall => ({ result, fromStore: false, envelopeHash, codes: [...codes] });
    // After a usage is committed: a single response above a per-request ceiling is implausible — recorded and counted all the same — and a total past the audit ceiling is exhaustion. Either ends the run; neither is promoted into a draft (IC-12).
    const assertWithinCeiling = (usage: CountedUsage | null): void => {
      const implausible = usage !== null && (usage.inputTokens > BUDGET_LIMITS.MAX_INPUT_TOKENS_PER_REQUEST || usage.outputTokens > BUDGET_LIMITS.MAX_OUTPUT_TOKENS_PER_REQUEST);
      const over = ledger.overCeiling();
      if (!implausible && over === null) return;
      const reason = implausible ? `the provider reported ${String(usage.inputTokens)}/${String(usage.outputTokens)} tokens on one response against per-request ceilings of ${String(BUDGET_LIMITS.MAX_INPUT_TOKENS_PER_REQUEST)}/${String(BUDGET_LIMITS.MAX_OUTPUT_TOKENS_PER_REQUEST)}: implausible` : over;
      ledger.note('usage over the ceiling; the run is exhausted', { implausible: implausible ? 1 : 0, overTotal: over === null ? 0 : 1 });
      throw new IntelligenceError('BUDGET_EXHAUSTED', reason ?? 'over the ceiling');
    };
    let transportAttempt = 0;
    for (;;) {
      ledger.assertOpen();
      // Invocations already in the ledger — an earlier process that died mid-request — count towards the bound.
      const invocation = ledger.invocationsOf(idempotencyKey) + 1;
      // The lease is renewed before every reservation: a worker that lost it — or never held it — reserves nothing and sends nothing.
      ledger.acquireLease(workerId, WORKER_LEASE_MS);
      const reservation = ledger.reserve({ taskId: envelope.taskId, attempt, invocation, inputTokens: estimatedInput, outputTokens: BUDGET_LIMITS.MAX_OUTPUT_TOKENS_PER_REQUEST, idempotencyKey });
      let result: GatewayResult;
      try {
        // Renewed while the provider takes its time: a generation longer than the lease is still this owner's request, not a dead worker's.
        result = await keepingLease(ledger, () => deps.gateway.analyze(request));
      } catch (error) {
        // A gateway that throws proves nothing about whether the bytes left.
        result = { kind: 'AMBIGUOUS', reason: GATEWAY_THREW };
      }
      const usage = reportedUsage(result);
      const drift = cacheDriftOf(result);
      if (drift !== null) {
        // The policy has the cache off and the provider billed cache tokens: counted like any input, and named so the drift is on the record.
        ledger.note('policy drift: cache tokens reported', drift);
        codes.add(CACHE_DRIFT_CODE);
      }
      if (result.kind === 'RESPONSE') {
        if (usage === null) ledger.note('usage unknown; reservation billed at full size', { inputTokens: reservation.inputTokens, outputTokens: reservation.outputTokens });
        // The stored copy carries the usage as counted, so a malformed figure from the provider is never written into the ledger.
        ledger.commit(reservation.reservationId, usage === null ? null : { inputTokens: usage.inputTokens, outputTokens: usage.outputTokens, billedButUnusable: result.stopReason !== 'end_turn' }, { idempotencyKey, envelopeHash, body: { ...result, usage } });
        assertWithinCeiling(usage);
        return answered(result);
      }
      if (result.kind === 'AMBIGUOUS') {
        ledger.markAmbiguous(reservation.reservationId, recordedReason(result.reason));
        return answered(result);
      }
      if (usage !== null) {
        ledger.commit(reservation.reservationId, { inputTokens: usage.inputTokens, outputTokens: usage.outputTokens, billedButUnusable: true }, null);
        assertWithinCeiling(usage);
      } else if (result.kind === 'RETRYABLE_FAILURE' && result.neverSent === true && result.usage === null) {
        // The transport's typed proof that nothing left the process; a message that says so is not proof.
        ledger.release(reservation.reservationId, 'the transport proved the request never left');
      } else if (result.kind === 'RETRYABLE_FAILURE' && result.neverSent === true) {
        // Proof of non-send beside a usage figure the ledger cannot read: two witnesses that contradict each other release nothing.
        ledger.markAmbiguous(reservation.reservationId, 'the transport says the request never left and the provider reported usage: contradictory evidence');
      } else {
        ledger.markAmbiguous(reservation.reservationId, `${result.kind} without usage: the request may have been billed`);
      }
      if (result.kind === 'TERMINAL_FAILURE' || transportAttempt >= BUDGET_LIMITS.MAX_TRANSPORT_RETRIES_PER_REQUEST) return answered(result);
      transportAttempt += 1;
      const retryAfter = typeof result.retryAfterMs === 'number' && Number.isFinite(result.retryAfterMs) && result.retryAfterMs > 0 ? result.retryAfterMs : 0;
      const jitter = parseInt(digestOf({ idempotencyKey, transportAttempt }).slice(0, 2), 16) % 32;
      const wait = Math.max(retryAfter, RETRY_BACKOFF_MS[transportAttempt - 1] ?? 200) + jitter;
      const remaining = Date.parse(ledger.view().deadlineAt) - deps.clock.nowMs();
      if (wait > MAX_RETRY_WAIT_MS || wait >= remaining) {
        ledger.note('transport retry refused: the wait would pass the deadline or the retry ceiling', { transportAttempt, wait, remaining: Math.max(0, remaining) });
        return answered(result);
      }
      ledger.note('transport retry', { transportAttempt, wait });
      await sleep(wait);
    }
  }

  async function runTask(ledger: RunLedger, task: TaskRecord, contracts: AdaptedContracts, candidates: readonly DeterministicCandidate[], input: IntelligenceInput, context: HostContext, decisions: readonly ResolvedDecision[]): Promise<{ result: TaskResult; compiled: CompiledTask | null; calls: number }> {
    const memory = resolveMemory(input.scopedMemorySnapshot, { tenant: context.tenant, targetInstanceRef: contracts.contractView.mode === 'CLEAN_ONLY' ? null : contracts.contractView.instanceId, targetSchemaVersion: contracts.contractView.mode === 'CLEAN_ONLY' ? null : contracts.contractView.targetContractVersion, knownTargetRefs: new Set(contracts.refs.targetByRef.keys()), headers: contracts.profileView.fields.filter((field) => candidates.some((candidate) => candidate.sourceRefs.includes(field.fieldRef))).map((field) => field.header) });
    ledger.note('memory resolved', { evidence: memory.evidence.length, stale: memory.stale.length, conflicted: memory.conflicted.length, refused: memory.refused.length });
    let repair: RepairContext | null = null;
    let calls = 0;
    let lastCompiled: CompiledTask | null = null;
    for (let attempt = 1; attempt <= BUDGET_LIMITS.MAX_SEMANTIC_ATTEMPTS_PER_TASK; attempt += 1) {
      const view = ledger.view();
      const snapshot: BudgetSnapshot = { maxInputTokens: BUDGET_LIMITS.MAX_INPUT_TOKENS_PER_REQUEST, maxOutputTokens: BUDGET_LIMITS.MAX_OUTPUT_TOKENS_PER_REQUEST, remainingBilledInputTokens: view.budget.remainingInputTokens, remainingBilledOutputTokens: view.budget.remainingOutputTokens, remainingTasks: view.budget.remainingTasks + (attempt > 1 ? 1 : 0), deadlineAt: view.deadlineAt };
      const effectiveTask: TaskRecord = attempt === 1 ? task : { ...task, taskType: 'SEMANTIC_REPAIR' };
      const built = buildEnvelope({ task: effectiveTask, contracts, candidates, memoryEvidence: memory.evidence, summaries: input.categoricalSummaries ?? new Map(), projectRevisionId: input.projectRevision.projectRevisionId, projectRevisionHash: input.projectRevision.projectRevisionHash, supportEnvelopeVersion: input.projectRevision.supportEnvelopeVersion, budgetSnapshot: snapshot, repairContext: repair, egressSecret, tenant: context.tenant, attemptId: context.auditAttemptId });
      ledger.note('envelope built', { exemplars: built.envelope.exemplars.length, blockedValues: built.minimization.blocked.length, level: built.minimization.maxDataLevel === 'L0' ? 0 : built.minimization.maxDataLevel === 'L1' ? 1 : 2 });
      if (built.egress.decision !== 'EGRESS_ALLOWED') {
        ledger.recordTaskOutcome({ taskId: task.taskId, outcome: built.egress.decision === 'EGRESS_BLOCKED_BUDGET' ? 'BUDGET_EXHAUSTED' : 'ABSTAINED', attempt, codes: [built.egress.decision, ...built.egress.blockedReasons], envelopeHash: built.hash, proposalDigest: null });
        return { result: { taskId: task.taskId, taskType: task.taskType, outcome: built.egress.decision === 'EGRESS_BLOCKED_BUDGET' ? 'BUDGET_EXHAUSTED' : 'ABSTAINED', attempts: attempt, envelopeHash: built.hash, proposalDigest: null, codes: [built.egress.decision] }, compiled: null, calls };
      }
      let call;
      try {
        call = await callGateway(ledger, built.envelope, built.hash, built.egress, attempt);
      } catch (error) {
        if (isIntelligenceError(error) && (error.code === 'BUDGET_EXHAUSTED' || error.code === 'BUDGET_RESERVATION_CONFLICT')) {
          ledger.recordTaskOutcome({ taskId: task.taskId, outcome: 'BUDGET_EXHAUSTED', attempt, codes: [error.code], envelopeHash: built.hash, proposalDigest: null });
          return { result: { taskId: task.taskId, taskType: task.taskType, outcome: 'BUDGET_EXHAUSTED', attempts: attempt, envelopeHash: built.hash, proposalDigest: null, codes: [error.code, error.message] }, compiled: null, calls };
        }
        throw error;
      }
      if (!call.fromStore) calls += 1;
      const { result } = call;
      // The envelope hash the response answers: this build's, or — for a response the ledger held — the one the dead process sent, which differs from this build's by the budget snapshot alone and is the one the proposal names.
      const envelopeHash = call.envelopeHash;
      if (call.fromStore) ledger.note('response reused from the ledger', { attempt, rebuiltHashDiffers: envelopeHash === built.hash ? 0 : 1 });
      if (result.kind === 'RETRYABLE_FAILURE' || result.kind === 'AMBIGUOUS' || result.kind === 'TERMINAL_FAILURE') {
        const outcome: TaskOutcome = result.kind === 'TERMINAL_FAILURE' ? 'PROVIDER_TERMINAL_FAILURE' : 'PROVIDER_RETRYABLE_FAILURE';
        ledger.recordTaskOutcome({ taskId: task.taskId, outcome, attempt, codes: [result.kind, recordedReason(result.reason), ...call.codes], envelopeHash, proposalDigest: null });
        return { result: { taskId: task.taskId, taskType: task.taskType, outcome, attempts: attempt, envelopeHash, proposalDigest: null, codes: [result.kind, ...call.codes] }, compiled: null, calls };
      }
      if (result.stopReason === 'refusal' || result.stopReason === 'max_tokens') {
        ledger.recordTaskOutcome({ taskId: task.taskId, outcome: 'PROVIDER_TERMINAL_FAILURE', attempt, codes: [`STOP_${result.stopReason.toUpperCase()}`, ...call.codes], envelopeHash, proposalDigest: null });
        return { result: { taskId: task.taskId, taskType: task.taskType, outcome: 'PROVIDER_TERMINAL_FAILURE', attempts: attempt, envelopeHash, proposalDigest: null, codes: [`STOP_${result.stopReason.toUpperCase()}`, ...call.codes] }, compiled: null, calls };
      }
      const parsed = parseProposal(result.content);
      if (!parsed.ok) {
        const codes = [...parsed.problems.slice(0, 16).map((problem) => `${problem.pointer}:${problem.message}`), ...call.codes];
        ledger.recordTaskOutcome({ taskId: task.taskId, outcome: 'INVALID_SCHEMA', attempt, codes, envelopeHash, proposalDigest: digestOf(result.content) });
        if (attempt < BUDGET_LIMITS.MAX_SEMANTIC_ATTEMPTS_PER_TASK) {
          repair = { previousProposalDigest: digestOf(result.content), validationCodes: ['INVALID_SCHEMA'], allowedValues: [], allowedTargetRefs: [...built.envelope.constraints.allowedTargetIds] };
          continue;
        }
        return { result: { taskId: task.taskId, taskType: task.taskType, outcome: 'INVALID_SCHEMA', attempts: attempt, envelopeHash, proposalDigest: digestOf(result.content), codes }, compiled: null, calls };
      }
      // The semantic content of this build is the content the response answered; only the hash the proposal is checked against comes from the ledger.
      const compiled = compileProposal({ envelope: built.envelope, envelopeHash, proposal: parsed.proposal, runId: ledger.runId, contracts, decisions });
      lastCompiled = call.codes.length === 0 ? compiled : { ...compiled, codes: [...compiled.codes, ...call.codes] };
      ledger.recordTaskOutcome({ taskId: task.taskId, outcome: compiled.outcome, attempt, codes: lastCompiled.codes, envelopeHash, proposalDigest: compiled.proposalDigest });
      if (compiled.repairable && attempt < BUDGET_LIMITS.MAX_SEMANTIC_ATTEMPTS_PER_TASK) {
        repair = { previousProposalDigest: compiled.proposalDigest, validationCodes: [...new Set(compiled.codes)].slice(0, 64), allowedValues: [], allowedTargetRefs: [...built.envelope.constraints.allowedTargetIds] };
        continue;
      }
      return { result: { taskId: task.taskId, taskType: task.taskType, outcome: compiled.outcome, attempts: attempt, envelopeHash, proposalDigest: compiled.proposalDigest, codes: lastCompiled.codes }, compiled: lastCompiled, calls };
    }
    return { result: { taskId: task.taskId, taskType: task.taskType, outcome: lastCompiled?.outcome ?? 'INVALID_SEMANTICS', attempts: BUDGET_LIMITS.MAX_SEMANTIC_ATTEMPTS_PER_TASK, envelopeHash: lastCompiled?.envelopeHash ?? null, proposalDigest: lastCompiled?.proposalDigest ?? null, codes: lastCompiled?.codes ?? ['ATTEMPTS_EXHAUSTED'] }, compiled: lastCompiled, calls };
  }

  function assemble(contracts: AdaptedContracts, decisions: readonly ResolvedDecision[], compiled: readonly CompiledTask[], input: IntelligenceInput): { configuration: CandidateConfiguration; items: readonly CompiledItem[]; deterministic: readonly ResolvedDecision[]; contradictions: readonly string[]; preserved: readonly string[]; decisionsRequired: readonly { candidateRef: string; reason: string }[] } {
    const fields: ConfigFragmentField[] = [];
    // The deterministic decisions that put a field into the configuration, in field order: each is projected into the draft's evidence beside the accepted proposals (IC-09).
    const deterministic: ResolvedDecision[] = [];
    // A target is claimed once per record mapping — the file and the object it
    // is delivered as — never once per run: two files that both hold CONTACT
    // each map their own Email to contact.email (IC-08), while two columns of
    // one file competing for one target remain a contradiction the agency
    // decides. The key is `${recordId}|${destinationField}`.
    const claimed = new Map<string, string>();
    const contradictions: string[] = [];
    const preserved: string[] = [];
    const decisionsRequired: { candidateRef: string; reason: string }[] = [];
    const items = compiled.flatMap((task) => task.items);
    const recordIdOf = (fileId: string, destinationField: string): { readonly recordId: string; readonly object: string } => {
      const object = destinationField.split('.')[0] ?? 'contact';
      return { recordId: `${fileId}-${object}`, object };
    };
    const claimKey = (recordId: string, destinationField: string): string => `${recordId}|${destinationField}`;
    // The options of an ENUM target as the attested contract lists them: Migration Core's allowedValues, copied from the contract and from nowhere else.
    const allowedValuesOf = (targetRef: string | null, semanticType: string): readonly string[] | undefined => {
      if (semanticType !== 'ENUM' || targetRef === null || contracts.contractView.mode === 'CLEAN_ONLY') return undefined;
      const options = contracts.contractView.fields.find((field) => field.targetRef === targetRef)?.options ?? [];
      return options.length > 0 ? [...options] : undefined;
    };
    /** Adds the mapping unless another column of the same record mapping already holds the target; then the earlier claim stands and the agency decides. */
    const addField = (candidateRef: string, fieldRef: string, targetRef: string | null, destinationField: string, semanticType: string, primitive: string | null, params: Readonly<Record<string, string>> | null, contradiction: string): boolean => {
      const info = contracts.refs.fieldByRef.get(fieldRef);
      if (info === undefined) return false;
      const { recordId, object } = recordIdOf(info.fileId, destinationField);
      const owner = claimed.get(claimKey(recordId, destinationField));
      if (owner !== undefined && owner !== fieldRef) {
        contradictions.push(contradiction);
        decisionsRequired.push({ candidateRef, reason: `DUPLICATE_TARGET:${destinationField}` });
        return false;
      }
      claimed.set(claimKey(recordId, destinationField), fieldRef);
      const allowedValues = allowedValuesOf(targetRef, semanticType);
      fields.push({ recordId, fileId: info.fileId, filePath: info.filePath, object: object.toUpperCase(), columnHeader: info.header, columnLocator: info.locator, destinationField, semanticType, transformPrimitive: primitive, typedTransformParams: params, ...(allowedValues === undefined ? {} : { allowedValues }) });
      return true;
    };
    // Deterministic mappings first; they were decided on facts and outrank a proposal about the same field.
    for (const decision of decisions) {
      if (decision.kind === 'FIELD_MAPPING' && decision.targetRef !== null) {
        const info = contracts.refs.targetByRef.get(decision.targetRef);
        if (info !== undefined && info.destinationField !== '' && addField(decision.fieldRef, decision.fieldRef, decision.targetRef, info.destinationField, decision.semanticType ?? 'TEXT', null, null, `${info.destinationField} is claimed by two source fields of one record mapping`)) deterministic.push(decision);
      }
    }
    for (const item of items) {
      if (item.outcome === 'PROPOSED' && item.destinationField !== null && item.sourceFieldRef !== null) {
        // Two sources for one target inside one record mapping: the earlier
        // claim (a deterministic mapping outranks a proposal) stands and the
        // agency decides the other; nothing is dropped and nothing is guessed.
        addField(item.candidateRef, item.sourceFieldRef, item.targetRef, item.destinationField, item.semanticType ?? 'TEXT', item.transformPrimitive, item.typedTransformParams, `${item.destinationField}: a proposal contradicts a deterministic mapping or another task in the same record mapping`);
      } else if (item.outcome === 'REQUIRES_AGENCY_DECISION') {
        decisionsRequired.push({ candidateRef: item.candidateRef, reason: item.codes[0] ?? item.rationaleCode });
      } else if (item.sourceFieldRef !== null) {
        preserved.push(item.sourceFieldRef);
      }
    }
    for (const decision of decisions) if (decision.kind === 'PRESERVE_UNMAPPED' && !fields.some((field) => contracts.refs.fieldByRef.get(decision.fieldRef)?.locator === field.columnLocator) && !preserved.includes(decision.fieldRef)) preserved.push(decision.fieldRef);
    const configuration: CandidateConfiguration = { configurationRef: `cfg_${digestOf({ fields, profile: contracts.profileHash }).slice(0, 16)}`, mode: input.projectRevision.mode, profileHash: contracts.profileHash, candidateSetHash: contracts.candidateSetHash, targetContractHash: contracts.targetContractHash, fields };
    return { configuration, items, deterministic, contradictions, preserved: [...new Set(preserved)], decisionsRequired };
  }

  /** A deterministic decision as draft evidence: the rule is the rationale, the decision's refs are the refs, the class is the rule's; no primitive — the resolver maps, it never transforms. */
  function deterministicEvidence(decision: ResolvedDecision, destinationField: string): DraftEvidence {
    return { origin: 'DETERMINISTIC', candidateRef: decision.decisionRef, evidenceClass: DETERMINISTIC_EVIDENCE_CLASS[decision.rule] ?? 'SUPPORTED', rationaleCode: decision.rule, evidenceRefs: decision.evidenceRefs, sourceFieldRef: decision.sourceFieldRef, targetRef: decision.targetRef, destinationField, semanticType: decision.semanticType, transformPrimitive: null, typedTransformParams: null };
  }

  /**
   * The receipt against what this run knows. Shape first — a member missing,
   * a count that is not a finite integer, an unknown member — then the
   * bindings: the exact configuration handed over, the hashes, exact row
   * coverage, a Migration Core version this core accepts, an instant not
   * before the run started and not after now, and an internally consistent
   * verdict. Every problem is a code; any one of them means no draft.
   *
   * "Now" is the injected clock's, with no tolerance: the host dates its
   * receipt by the same clock it hands this core (one clock discipline
   * across the boundary, as the fixtures' adapter shows), so a receipt from
   * the future is a receipt dated by another clock, or made up.
   */
  function validationIsSound(result: FullDatasetValidationResult, configuration: CandidateConfiguration, contracts: AdaptedContracts, rowsInProfile: number, runCreatedAt: string, nowMs: number): readonly string[] {
    const problems: string[] = [];
    const shape = validate(result, FULL_DATASET_VALIDATION_RESULT_SCHEMA);
    if (shape.length > 0) {
      problems.push('VALIDATION_RECEIPT_MALFORMED', ...shape.slice(0, 8).map((problem) => `${problem.pointer}:${problem.message}`));
      return problems;
    }
    if (result.configurationRef !== configuration.configurationRef) problems.push('VALIDATION_FOR_ANOTHER_CONFIGURATION');
    if (result.configurationDigest !== digestOf(configuration)) problems.push('VALIDATION_CONFIGURATION_DIGEST_MISMATCH');
    if (result.profileHash !== contracts.profileHash || result.candidateSetHash !== contracts.candidateSetHash || result.targetContractHash !== contracts.targetContractHash) problems.push('VALIDATION_HASHES_STALE');
    if (result.rowsValidated <= 0 || result.rowsInProfile !== rowsInProfile || result.rowsValidated < rowsInProfile) problems.push('VALIDATION_COVERAGE_INCOMPLETE');
    // More rows than the profile holds is not generosity: it is a receipt about another dataset.
    if (result.rowsValidated !== rowsInProfile) problems.push('VALIDATION_COVERAGE_INEXACT');
    if (!SUPPORTED_MIGRATION_CORE.coreVersions.includes(result.coreVersion)) problems.push('VALIDATION_CORE_VERSION_UNSUPPORTED');
    const verdicts = [result.ok, result.problems.length === 0, result.reconciliationHolds, result.packageVerified];
    if (verdicts.some((verdict) => verdict !== result.ok)) problems.push('VALIDATION_RECEIPT_INCONSISTENT');
    // A package the host says it verified was written and reported on; a verified verdict that names no package digest or no report digest is a receipt about nothing that ran.
    if ((result.ok || result.packageVerified) && (result.evidence.packageDigest === null || result.evidence.reportDigest === null) && !problems.includes('VALIDATION_RECEIPT_INCONSISTENT')) problems.push('VALIDATION_RECEIPT_INCONSISTENT');
    const validatedAt = Date.parse(result.validatedAt);
    if (!Number.isFinite(validatedAt) || validatedAt < Date.parse(runCreatedAt)) problems.push('VALIDATION_BEFORE_RUN_STARTED');
    if (validatedAt > nowMs) problems.push('VALIDATION_AFTER_NOW');
    if (!result.reconciliationHolds || !result.packageVerified) problems.push('VALIDATION_RECONCILIATION_OR_VERIFY_FAILED');
    if (!result.ok) problems.push('VALIDATION_REPORTED_PROBLEMS');
    return problems;
  }

  /** One IntelligenceRun, by one owner: the invocation opens its own ledger handle, takes the lease under it and makes every write under it. */
  async function runAttempt(input: IntelligenceInput, context: HostContext): Promise<IntelligenceResult> {
    const started = deps.clock.nowMs();
    const versionProblems = [...compatibilityProblems({ envelopeSchemaVersion: ENVELOPE_SCHEMA_VERSION, proposalSchemaVersion: PROPOSAL_SCHEMA_VERSION, sourceProfileVersion: input.sourceProfile.profile.profileVersion, candidateSetVersion: input.candidateSet.candidateSet.candidateSetVersion, targetContractVersion: input.targetContract?.contract.contractVersion ?? null, coreVersion: input.candidateSet.candidateSet.refs.coreVersion, configSchemaVersion: input.candidateSet.candidateSet.refs.configSchemaVersion })];
    if (input.policyBundle.modelPolicyVersion !== MODEL_POLICY_VERSION) versionProblems.push(`modelPolicyVersion ${input.policyBundle.modelPolicyVersion} is not ${MODEL_POLICY_VERSION}`);
    if (input.policyBundle.promptBundleVersion !== PROMPT_BUNDLE_VERSION) versionProblems.push(`promptBundleVersion ${input.policyBundle.promptBundleVersion} is not ${PROMPT_BUNDLE_VERSION}`);
    if (context.tenant.agencyId.trim() === '' || context.tenant.clientId.trim() === '') throw new IntelligenceError('TENANT_MISMATCH', 'the host context names no tenant');
    if (typeof context.auditAttemptId !== 'string' || context.auditAttemptId.trim() === '') throw new IntelligenceError('CONTRACT_VIOLATION', 'the host context names no AuditAttempt identity');
    // The identity the attempt is bound to: tenant and attempt make the id; revision, hashes and every version that shapes a request — the data and masking policies among them, since what may leave and how it is masked is content of the attempt — are checked against the ledger on every reopening.
    // What the host declared is bound too — the policy bundle it asked for, the mode, the declared objects, the memory snapshot — as the host declared it, before this build says whether it accepts it: the same attempt id resubmitted with another declaration is a conflict, not a redelivery, and never answered from the stored result (IC-04).
    const declared = { declaredModelPolicyVersion: input.policyBundle.modelPolicyVersion, declaredPromptBundleVersion: input.policyBundle.promptBundleVersion, declaredMode: input.projectRevision.mode };
    // The resource policy and the summaries the host extracted are content of the attempt as well: the same id with another wall-clock bound or other column values is another attempt, never answered from this one's stored result.
    const declaredContent = { declaredObjects: digestOf(input.projectRevision.declaredObjects ?? null), memorySnapshot: digestOf(input.scopedMemorySnapshot), resourceProfile: digestOf({ wallClockMs: input.resourceProfile.wallClockMs ?? null }), categoricalSummaries: digestOf(input.categoricalSummaries === undefined ? null : Object.fromEntries([...input.categoricalSummaries.entries()].map(([locator, values]) => [locator, [...values]]))) };
    const ledger = RunLedger.create(deps.ledgerStore, deps.clock, { auditAttemptId: context.auditAttemptId, projectRevisionHash: input.projectRevision.projectRevisionHash, hashes: { profile: input.sourceProfile.profileHash, candidateSet: input.candidateSet.candidateSetHash, targetContract: input.targetContract?.contractHash ?? null, ...declaredContent }, versions: { intelligenceCoreVersion: INTELLIGENCE_CORE_VERSION, envelopeSchemaVersion: ENVELOPE_SCHEMA_VERSION, proposalSchemaVersion: PROPOSAL_SCHEMA_VERSION, promptBundleVersion: PROMPT_BUNDLE_VERSION, modelPolicyVersion: MODEL_POLICY_VERSION, dataPolicyVersion: DATA_POLICY_VERSION, maskingPolicyVersion: MASKING_POLICY_VERSION, promptBundleHash: PROMPT_BUNDLE_HASH, modelPolicyHash: digestOf(MODEL_POLICY_V1), ...declared }, tenant: context.tenant, ...(input.resourceProfile.wallClockMs !== undefined ? { wallClockMs: input.resourceProfile.wallClockMs } : {}) });
    const provenance = { intelligenceCoreVersion: INTELLIGENCE_CORE_VERSION, envelopeSchemaVersion: ENVELOPE_SCHEMA_VERSION, proposalSchemaVersion: PROPOSAL_SCHEMA_VERSION, promptBundleVersion: PROMPT_BUNDLE_VERSION, promptBundleHash: PROMPT_BUNDLE_HASH, modelPolicyVersion: MODEL_POLICY_VERSION, modelPolicyHash: digestOf(MODEL_POLICY_V1), dataPolicyVersion: DATA_POLICY_VERSION, maskingPolicyVersion: MASKING_POLICY_VERSION, memoryContractVersion: MEMORY_CONTRACT_VERSION, compilerContractVersion: COMPILER_CONTRACT_VERSION, profileHash: input.sourceProfile.profileHash, candidateSetHash: input.candidateSet.candidateSetHash, targetContractHash: input.targetContract?.contractHash ?? null, projectRevisionHash: input.projectRevision.projectRevisionHash };
    const notDraftable = (fullValidation: FullDatasetValidationResult | null, unresolved: IntelligenceResult['unresolvedItems'], decisionsRequired: readonly { candidateRef: string; reason: string }[], preserved: readonly string[]): DraftMigrationPlan => ({ planVersion: '1.0.0', status: 'NOT_DRAFTABLE', configuration: null, impact: { fieldsMapped: 0, rowsCovered: 0, fieldsPreserved: preserved.length }, evidence: [], unresolved, unsupportedPreserved: preserved, decisionsRequired, fullValidation, note: 'A SYSTEM_DRAFT is not an approval, a quote or an authorisation to execute.' });
    /** The cause a terminal state recorded from outside puts on the record: the host's cancellation by name, any other state by its name. */
    const causeOf = (recorded: RunState): string => (recorded === 'CANCELLED' ? 'RUN_CANCELLED' : `RUN_${recorded}`);
    /**
     * What the record closed the run with from outside this flow, if
     * anything: a terminal state already on it, or the host's cancellation
     * when its closing transition never landed — `cancel()` writes CANCELLED
     * and then the STATE, and a host that dies between the two has still
     * cancelled the run; the state is closed from the CANCELLED event by
     * whoever finishes the attempt, never worked past.
     */
    const closedFromOutside = (view: { readonly state: RunState; readonly cancelled: boolean }): RunState | null => (TERMINAL_RUN_STATES.has(view.state) ? view.state : view.cancelled ? 'CANCELLED' : null);
    /**
     * The closing transition, idempotent: an append lost to a writer that
     * changed nothing about it (the host's cancel, a note) is decided again
     * on the re-read log, and a terminal state recorded meanwhile stands —
     * as does a cancellation on the record whose own STATE never landed.
     * Returns the terminal state on record when it is done.
     */
    const closeTerminal = (intended: RunState, intendedDraft: boolean): RunState => {
      let lost: unknown = null;
      for (let tries = 0; tries < 4; tries += 1) {
        const view = ledger.view();
        const recorded = view.state;
        if (TERMINAL_RUN_STATES.has(recorded)) {
          // A terminal state was recorded while this process worked (a cancellation from outside). Not swallowed: the ledger names the state this flow meant to reach and did not.
          if (recorded !== intended) ledger.note(`terminal state ${recorded} already recorded; ${intended} not applied`, { intendedDraft: intendedDraft ? 1 : 0 });
          return recorded;
        }
        const closing = closedFromOutside(view) ?? intended;
        if (closing !== intended) ledger.note(`cancellation already recorded without its closing state; ${intended} not applied`, { intendedDraft: intendedDraft ? 1 : 0 });
        try {
          ledger.transition(closing, closing !== intended ? 'cancellation on record closed' : tries === 0 ? 'run finished' : 'run finished; decided again after a lost append');
          return closing;
        } catch (error) {
          if (!isIntelligenceError(error) || error.code !== 'LEDGER_CONFLICT') throw error;
          lost = error;
        }
      }
      throw lost;
    };
    /**
     * The answer the host gets: the stored RESULT, read under the terminal
     * state on record. The RESULT names the state its owner meant to close
     * with; when the record closed otherwise — a cancellation landed between
     * the answer and its closing transition — the record wins: that state,
     * no draft, no memory candidates, the cause named first. A function of
     * the log alone, so every redelivery reads the same answer.
     */
    const publish = (stored: Omit<IntelligenceResult, 'runLedger'>, recorded: RunState): IntelligenceResult => {
      if (recorded === stored.state) return { ...stored, runLedger: ledger.export() };
      const cause = causeOf(recorded);
      const unresolved = stored.unresolvedItems.some((item) => item.candidateRef === 'run' && item.codes[0] === cause) ? stored.unresolvedItems : [...stored.unresolvedItems, { candidateRef: 'run', outcome: 'BUDGET_EXHAUSTED' as const, codes: [cause, `RESULT_NAMED_${stored.state}`] }];
      const draft = notDraftable(null, unresolved, stored.draft.decisionsRequired, stored.draft.unsupportedPreserved);
      return { ...stored, proposalDigest: digestOf({ tasks: stored.tasks, draft: draft.configuration }), state: recorded, draft, unresolvedItems: unresolved, memoryCandidates: [], runLedger: ledger.export() };
    };
    /**
     * The end of the run. The RESULT is stored first and the closing
     * transition made after it, so the attempt is never terminal without an
     * answer: a process that dies between the two leaves a RESULT naming
     * its terminal state, and the reopening closes the state from it and
     * answers, with nothing recomputed and nothing bought. A terminal state
     * something else recorded before this point (a cancellation from
     * outside) is what the result names, and nothing a draft would say
     * against it; the cause is on the unresolved items, first in its codes.
     */
    const finish = (state: RunState | null, tasks: readonly TaskResult[], draftIntended: DraftMigrationPlan, unresolvedIntended: IntelligenceResult['unresolvedItems'], memoryCandidatesIntended: readonly MemoryCandidate[], counters: { calls: number; planned: number; leftOut: number; decisions: number }): IntelligenceResult => {
      let draft = draftIntended;
      let unresolved = unresolvedIntended;
      let memoryCandidates = memoryCandidatesIntended;
      const before = ledger.view();
      // The record's closing, if it closed from outside: a terminal state already written, or a cancellation whose own STATE never landed.
      const recordedBefore = closedFromOutside(before);
      let intended = state;
      if (recordedBefore !== null) {
        if (state !== null && state !== recordedBefore) ledger.note(`terminal state ${recordedBefore} already recorded; ${state} not applied`, { intendedDraft: draft.status === 'SYSTEM_DRAFT' ? 1 : 0 });
        const cause = causeOf(recordedBefore);
        if (!unresolved.some((item) => item.candidateRef === 'run' && item.codes[0] === cause)) unresolved = [...unresolved, { candidateRef: 'run', outcome: 'BUDGET_EXHAUSTED' as const, codes: [cause] }];
        draft = notDraftable(draft.status === 'SYSTEM_DRAFT' ? null : draft.fullValidation, unresolved, draft.decisionsRequired, draft.unsupportedPreserved);
        memoryCandidates = [];
        intended = recordedBefore;
      }
      if (intended === null) throw new IntelligenceError('CONTRACT_VIOLATION', `run ${ledger.runId} reached its end in ${before.state} with no terminal state to close with`);
      const view = ledger.view();
      // Cost is what the ledger holds, not what this process counted: a resumed run reports the invocations of the process that died too.
      const budget = view.budget;
      const resourceEvidence: IntelligenceResult['resourceEvidence'] = { providerInvocations: budget.invocations, modelCalls: budget.responses, ambiguousReservations: budget.ambiguousReservations, billedInputTokens: budget.billedInputTokens + budget.ambiguousInputTokens, billedOutputTokens: budget.billedOutputTokens + budget.ambiguousOutputTokens, ambiguousInputTokens: budget.ambiguousInputTokens, ambiguousOutputTokens: budget.ambiguousOutputTokens, tasksPlanned: counters.planned, tasksLeftOut: counters.leftOut, deterministicDecisions: counters.decisions, wallClockMs: deps.clock.nowMs() - started };
      const stored: Omit<IntelligenceResult, 'runLedger'> = { proposalRef: `prop_${digestOf(tasks.map((task) => task.proposalDigest)).slice(0, 16)}`, proposalDigest: digestOf({ tasks, draft: draft.configuration }), runId: ledger.runId, state: intended, tasks, draft, unresolvedItems: unresolved, memoryCandidates, resourceEvidence, provenance };
      // The answer first, durable under the state it names; then the state. The other order left a crash between the two with a closed run and no answer.
      const kept = ledger.storeResult(stored) as Omit<IntelligenceResult, 'runLedger'>;
      const reached = closeTerminal(kept.state as RunState, kept.draft.status === 'SYSTEM_DRAFT');
      const result = publish(kept, reached);
      telemetry({ runId: ledger.runId, kind: 'RUN_FINISHED', counters: { calls: resourceEvidence.providerInvocations, requests: counters.calls, billedInput: resourceEvidence.billedInputTokens, billedOutput: resourceEvidence.billedOutputTokens, tasks: tasks.length }, codes: [result.state] });
      return result;
    };

    // A redelivery of a finished run answers with the result the ledger
    // holds; nothing is recomputed and nothing is billed.
    const already = ledger.storedResult() as Omit<IntelligenceResult, 'runLedger'> | undefined;
    const opened = ledger.view();
    if (already !== undefined) {
      if (!TERMINAL_RUN_STATES.has(opened.state)) {
        // The owner died between its RESULT and the closing transition. The answer is on the record; the state is closed from it here, under this invocation's lease — inside the dead owner's lease the redelivery is WORKER_NOT_OWNER, as after any crash — and nothing is recomputed or bought.
        ledger.acquireLease(workerId, WORKER_LEASE_MS);
        ledger.note('closing transition recovered from the stored result', { events: opened.events });
        closeTerminal(already.state as RunState, already.draft.status === 'SYSTEM_DRAFT');
      }
      return publish(already, ledger.view().state);
    }
    if (opened.cancelled) {
      // The host cancelled an attempt no owner finished (whether or not its own closing STATE landed): there is nothing to resume and nothing to buy; the answer is the cancellation, stored so the next redelivery reads it.
      ledger.acquireLease(workerId, WORKER_LEASE_MS);
      const cancelled = { candidateRef: 'run', outcome: 'BUDGET_EXHAUSTED' as const, codes: ['RUN_CANCELLED'] };
      return finish(null, [], notDraftable(null, [cancelled], [], []), [cancelled], [], { calls: 0, planned: 0, leftOut: 0, decisions: 0 });
    }
    // Impossible by construction since the RESULT precedes the closing transition; kept for a log written under the earlier order.
    if (TERMINAL_RUN_STATES.has(opened.state)) throw new IntelligenceError('INVALID_TRANSITION', `run ${ledger.runId} is terminal (${opened.state}) without a stored result; the ledger holds what happened`);
    // One worker owns the attempt. The lease is taken here, before anything
    // is reserved or any in-flight reservation is judged: a second live
    // worker on the same attempt finds the first's lease in force and
    // leaves with WORKER_NOT_OWNER, having spent nothing; it takes over
    // only once that lease has lapsed by the run's clock (IC-01).
    ledger.acquireLease(workerId, WORKER_LEASE_MS);
    // A run found unfinished is resumed from its events: whatever was sent
    // and answered is reused, whatever was sent and not answered is kept
    // as ambiguous, and the work goes on from there.
    if (opened.events > 1) {
      const inFlight = ledger.reopenInFlight('reservation open when the run was reopened; the request may have reached the provider');
      ledger.note('run resumed from the ledger', { events: opened.events, inFlight });
    }

    if (versionProblems.length > 0) {
      ledger.note(`versions refused: ${versionProblems.join('; ')}`, { problems: versionProblems.length });
      return finish('FAILED_CONTRACT', [], notDraftable(null, [], [], []), [{ candidateRef: 'run', outcome: 'INCOMPATIBLE_CONTRACT_VERSION', codes: versionProblems }], [], { calls: 0, planned: 0, leftOut: 0, decisions: 0 });
    }
    let contracts: AdaptedContracts;
    try {
      contracts = adaptContracts({ mode: input.projectRevision.mode, profile: input.sourceProfile, candidateSet: input.candidateSet, targetContract: input.targetContract });
    } catch (error) {
      const code = isIntelligenceError(error) ? error.code : 'CONTRACT_VIOLATION';
      ledger.note(`contracts refused: ${error instanceof Error ? error.message : String(error)}`, { adapted: 0 });
      return finish('FAILED_CONTRACT', [], notDraftable(null, [], [], []), [{ candidateRef: 'run', outcome: code === 'INCOMPATIBLE_CONTRACT_VERSION' ? 'INCOMPATIBLE_CONTRACT_VERSION' : 'STALE_INPUT', codes: [code] }], [], { calls: 0, planned: 0, leftOut: 0, decisions: 0 });
    }
    const resolution = resolve(contracts, { ...(input.projectRevision.declaredObjects === undefined ? {} : { declaredObjects: input.projectRevision.declaredObjects }), ...(input.projectRevision.recordIdColumns === undefined ? {} : { recordIdColumns: input.projectRevision.recordIdColumns }) });
    const planned = plan(input.projectRevision.projectRevisionHash, resolution.openQuestions);
    ledger.note('resolved and planned', { decisions: resolution.decisions.length, questions: resolution.openQuestions.length, tasks: planned.tasks.length, leftOut: planned.leftOut.length });
    const derivedByRef = new Map(resolution.derivedCandidates.map((candidate) => [candidate.candidateRef, candidate]));
    const tasks: TaskResult[] = [];
    const compiledTasks: CompiledTask[] = [];
    let calls = 0;
    // A resumed run re-enters the task loop from wherever it died; the states that already sit before the loop stay put.
    const before = ledger.view().state;
    if (planned.tasks.length > 0 && (before === 'CREATED' || before === 'RUNNING' || before === 'COMPILING')) ledger.transition('ENVELOPE_VALIDATED', before === 'CREATED' ? 'tasks planned' : 'resumed');
    for (const task of planned.tasks) {
      const view = ledger.view();
      if (view.cancelled) break;
      if (ledger.deadlinePassed()) {
        tasks.push({ taskId: task.taskId, taskType: task.taskType, outcome: 'BUDGET_EXHAUSTED', attempts: 0, envelopeHash: null, proposalDigest: null, codes: ['DEADLINE_PASSED'] });
        continue;
      }
      const candidates = task.candidateRefs.map((ref) => derivedByRef.get(ref)).filter((candidate): candidate is DeterministicCandidate => candidate !== undefined);
      if (view.state === 'ENVELOPE_VALIDATED') ledger.transition('EGRESS_APPROVED', `task ${task.taskId}`);
      if (ledger.view().state === 'EGRESS_APPROVED') ledger.transition('RUNNING', `task ${task.taskId}`);
      let outcome;
      try {
        outcome = await runTask(ledger, task, contracts, candidates, input, context, resolution.decisions);
      } catch (error) {
        if (isIntelligenceError(error) && (error.code === 'RUN_CANCELLED' || error.code === 'DEADLINE_PASSED' || error.code === 'BUDGET_EXHAUSTED')) {
          // Exhaustion of any kind ends the loop; a budget exhaustion is recorded on the task, so a redelivery finds the outcome and does not buy the request again.
          if (error.code === 'BUDGET_EXHAUSTED') ledger.recordTaskOutcome({ taskId: task.taskId, outcome: 'BUDGET_EXHAUSTED', attempt: 0, codes: [error.code, error.message], envelopeHash: null, proposalDigest: null });
          tasks.push({ taskId: task.taskId, taskType: task.taskType, outcome: 'BUDGET_EXHAUSTED', attempts: 0, envelopeHash: null, proposalDigest: null, codes: [error.code] });
          break;
        }
        if (isIntelligenceError(error) && error.code === 'EGRESS_BLOCKED') {
          tasks.push({ taskId: task.taskId, taskType: task.taskType, outcome: 'ABSTAINED', attempts: 1, envelopeHash: null, proposalDigest: null, codes: [error.code] });
          continue;
        }
        throw error;
      }
      calls += outcome.calls;
      tasks.push(outcome.result);
      if (outcome.compiled !== null) compiledTasks.push(outcome.compiled);
    }
    for (const question of planned.leftOut) {
      tasks.push({ taskId: `left_${question.questionRef.slice(2)}`, taskType: question.taskType, outcome: 'ABSTAINED', attempts: 0, envelopeHash: null, proposalDigest: null, codes: ['TASK_CAP_REACHED_PRESERVED'] });
    }
    const view = ledger.view();
    if (view.cancelled) {
      // The host's cancellation ended the task loop: the run is CANCELLED on the record, and finish() names the cause on the result whether or not a task was cut short by it.
      const items = tasks.map((task) => ({ candidateRef: task.taskId, outcome: task.outcome, codes: task.codes }));
      return finish(null, tasks, notDraftable(null, items, [], []), items, [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    }
    const exhausted = tasks.some((task) => task.outcome === 'BUDGET_EXHAUSTED');
    const providerFailed = tasks.some((task) => task.outcome === 'PROVIDER_RETRYABLE_FAILURE' || task.outcome === 'PROVIDER_TERMINAL_FAILURE');
    const compilerFailed = tasks.some((task) => task.outcome === 'FORBIDDEN_PROPOSAL' || task.outcome === 'INVALID_SEMANTICS' || task.outcome === 'INVALID_SCHEMA' || task.outcome === 'STALE_INPUT');
    const assembled = assemble(contracts, resolution.decisions, compiledTasks, input);
    const unresolved = [...assembled.items.filter((item) => item.outcome !== 'PROPOSED').map((item) => ({ candidateRef: item.candidateRef, outcome: item.outcome, codes: item.codes })), ...assembled.contradictions.map((text) => ({ candidateRef: 'assembly', outcome: 'REQUIRES_AGENCY_DECISION' as const, codes: [text] }))];
    void unresolved;
    const memoryCandidates = assembled.items.filter((item) => item.outcome === 'PROPOSED' && item.targetRef !== null && item.sourceFieldRef !== null).map((item) => memoryCandidateFrom({ runId: ledger.runId, taskId: item.candidateRef, tenant: context.tenant, header: contracts.refs.fieldByRef.get(item.sourceFieldRef ?? '')?.header ?? '', targetRef: item.targetRef, semanticType: item.semanticType, scope: 'CLIENT' }));
    if (view.state === 'RUNNING' || view.state === 'ENVELOPE_VALIDATED' || view.state === 'EGRESS_APPROVED') {
      if (view.state !== 'RUNNING') {
        if (view.state === 'ENVELOPE_VALIDATED') ledger.transition('EGRESS_APPROVED', 'assembly');
        ledger.transition('RUNNING', 'assembly');
      }
      ledger.transition('COMPILING', 'assembly');
    }
    // Exhaustion found after assembly is still exhaustion: the terminal state names the budget, from COMPILING as from RUNNING (IC-02, IC-12).
    if (exhausted) return finish('BUDGET_EXHAUSTED', tasks, notDraftable(null, unresolved, assembled.decisionsRequired, assembled.preserved), unresolved, [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    // The terminal state names the cause, not the phase the flow was in when the outcomes were read: a task the provider failed ends FAILED_PROVIDER (from COMPILING as from RUNNING; a run resumed past validation has no exit to it and keeps the compiler's).
    if (providerFailed) return finish(ledger.view().state === 'FULL_VALIDATING' ? 'FAILED_COMPILER' : 'FAILED_PROVIDER', tasks, notDraftable(null, unresolved, assembled.decisionsRequired, assembled.preserved), unresolved, [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    if (compilerFailed) return finish(ledger.view().state === 'COMPILING' ? 'FAILED_COMPILER' : 'FAILED_CONTRACT', tasks, notDraftable(null, unresolved, assembled.decisionsRequired, assembled.preserved), unresolved, [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    if (assembled.configuration.fields.length === 0) {
      // Nothing to validate: every field is preserved or waits for the agency. Material abstention, not a draft.
      return finish('ABSTAINED_MATERIAL', tasks, notDraftable(null, unresolved, assembled.decisionsRequired, assembled.preserved), unresolved, memoryCandidates, { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    }
    if (ledger.view().state === 'CREATED') {
      // Everything was decided deterministically: no envelope, no call, straight to validation.
      ledger.transition('ENVELOPE_VALIDATED', 'no task needed');
      ledger.transition('EGRESS_APPROVED', 'no task needed');
      ledger.transition('RUNNING', 'no task needed');
      ledger.transition('COMPILING', 'deterministic only');
    }
    if (ledger.view().state !== 'FULL_VALIDATING') ledger.transition('FULL_VALIDATING', assembled.configuration.configurationRef);
    let validation: FullDatasetValidationResult;
    try {
      // The host's validation of the whole dataset can outlast the lease as a provider call can; the lease is kept while it runs.
      validation = await keepingLease(ledger, () => deps.validationPort.validate(assembled.configuration));
    } catch (error) {
      ledger.note('validation port failed', {});
      const failed = { candidateRef: 'validation', outcome: 'STALE_INPUT' as const, codes: ['VALIDATION_PORT_UNAVAILABLE', error instanceof Error ? error.message : String(error)] };
      return finish('FAILED_COMPILER', tasks, notDraftable(null, [...unresolved, failed], assembled.decisionsRequired, assembled.preserved), [...unresolved, failed], [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    }
    // The await is a boundary: what the run knew before it is not what it knows after. A cancellation that landed while the host validated ends the run cancelled, and a deadline that passed ends it abstained — a receipt, however sound, does not make a draft of a run that is no longer open.
    const afterValidation = ledger.view();
    if (afterValidation.cancelled) {
      const cancelled = { candidateRef: 'run', outcome: 'BUDGET_EXHAUSTED' as const, codes: ['RUN_CANCELLED'] };
      return finish(null, tasks, notDraftable(null, [...unresolved, cancelled], assembled.decisionsRequired, assembled.preserved), [...unresolved, cancelled], [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    }
    if (ledger.deadlinePassed()) {
      ledger.note('deadline passed during validation', { validations: 1 });
      const late = { candidateRef: 'run', outcome: 'BUDGET_EXHAUSTED' as const, codes: ['DEADLINE_PASSED'] };
      return finish('ABSTAINED_MATERIAL', tasks, notDraftable(null, [...unresolved, late], assembled.decisionsRequired, assembled.preserved), [...unresolved, late], [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    }
    const rowsInProfile = contracts.profileView.dataRowCount;
    const soundness = validationIsSound(validation, assembled.configuration, contracts, rowsInProfile, ledger.createdAt(), deps.clock.nowMs());
    if (soundness.length > 0) {
      // The receipt may be anything at this point — null, an array, a record missing its members — so nothing is read off it before its shape is known, and a malformed one is not carried into the result.
      const shaped = soundness[0] !== 'VALIDATION_RECEIPT_MALFORMED';
      const reported = shaped && Array.isArray(validation.problems) ? validation.problems.slice(0, 8).map((problem) => String(problem)) : [];
      const failed = { candidateRef: 'validation', outcome: 'STALE_INPUT' as const, codes: [...soundness, ...reported] };
      return finish('FAILED_COMPILER', tasks, notDraftable(shaped ? validation : null, [...unresolved, failed], assembled.decisionsRequired, assembled.preserved), [...unresolved, failed], [], { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
    }
    const draft: DraftMigrationPlan = {
      planVersion: '1.0.0',
      status: 'SYSTEM_DRAFT',
      configuration: assembled.configuration,
      impact: { fieldsMapped: assembled.configuration.fields.length, rowsCovered: validation.rowsValidated, fieldsPreserved: assembled.preserved.length },
      // Every field the configuration carries is accounted for: the deterministic decisions that put fields in, each under its rule, then the proposals the compiler accepted (IC-09).
      evidence: [
        ...assembled.deterministic.map((decision) => deterministicEvidence(decision, contracts.refs.targetByRef.get(decision.targetRef ?? '')?.destinationField ?? decision.destinationField ?? '')),
        ...assembled.items.filter((item) => item.outcome === 'PROPOSED').map((item): DraftEvidence => ({ origin: 'PROPOSED', candidateRef: item.candidateRef, evidenceClass: item.evidenceClass, rationaleCode: item.rationaleCode, evidenceRefs: item.evidenceRefs, sourceFieldRef: item.sourceFieldRef, targetRef: item.targetRef, destinationField: item.destinationField, semanticType: item.semanticType, transformPrimitive: item.transformPrimitive, typedTransformParams: item.typedTransformParams })),
      ],
      unresolved,
      unsupportedPreserved: assembled.preserved,
      decisionsRequired: assembled.decisionsRequired,
      fullValidation: validation,
      note: 'A SYSTEM_DRAFT is not an approval, a quote or an authorisation to execute.',
    };
    return finish('PROPOSAL_READY', tasks, draft, unresolved, memoryCandidates, { calls, planned: planned.tasks.length, leftOut: planned.leftOut.length, decisions: resolution.decisions.length });
  }

  return {
    async run(input: IntelligenceInput, context: HostContext): Promise<IntelligenceResult> {
      try {
        return await runAttempt(input, context);
      } catch (error) {
        // Fenced out: the attempt was taken over while this invocation waited, and what it brought back was discarded, not committed. Payload-free on the telemetry; the ledger holds the takeover's account, and a redelivery answers from it.
        if (isIntelligenceError(error) && error.code === 'LEDGER_FENCED') telemetry({ runId: String(error.details['runId'] ?? ''), kind: 'WRITE_FENCED', counters: { discarded: 1 }, codes: [error.code, String(error.details['kind'] ?? '')] });
        throw error;
      }
    },
    cancel(runId: string, reason: string): void {
      RunLedger.open(deps.ledgerStore, deps.clock, runId).cancel(reason);
    },
    readRun(runId: string): readonly LedgerEvent[] {
      return RunLedger.open(deps.ledgerStore, deps.clock, runId).export();
    },
  };
}
