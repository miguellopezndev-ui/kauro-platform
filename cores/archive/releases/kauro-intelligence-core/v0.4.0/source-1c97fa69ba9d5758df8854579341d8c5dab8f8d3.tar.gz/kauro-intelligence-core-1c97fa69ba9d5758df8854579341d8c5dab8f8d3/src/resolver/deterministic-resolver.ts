/**
 * The Deterministic Resolver, canon §22–§24: everything decidable from the
 * frozen profile and the target contract is decided here, without a model.
 * Exact header matches, exact enum equality, identity proof classification,
 * no-op detection and preservation defaults become decisions; what is left —
 * a material semantic question — becomes an open question the planner turns
 * into a task. Nothing here reads a row, and a suggestion is never a proof.
 *
 * The resolver does not rewrite Migration Core's candidate set. It derives
 * decision candidates from it under named rules, each carrying the set's
 * hash and the candidate it came from, so the two are never confused.
 */
import { CANONICAL_FIELDS, SEMANTIC_TYPES } from 'kavo-migration-core';

import type { AdaptedContracts } from '../adapter/contract-adapter.js';
import { digestOf } from '../contracts/canonical.js';
import { cleanOnlyTargetRef } from '../contracts/envelope.js';
import type { DeterministicCandidate, SourceFieldFact, TaskType } from '../contracts/envelope.js';

/**
 * Identity proof, MC canon §27 and IC §40–§41. Statistical uniqueness is
 * never identity: a column proves identity only when it is unique, populated
 * on every row AND an authoritative identifier names it — the record id
 * column the project declares for the file, or a target the contract flags
 * externalId/idLookup whose name the header matches exactly. A unique email,
 * phone or name is an IDENTITY_SIGNAL: something to point at, never a proof.
 */
export type IdentityProof = 'PROVEN_UNIQUE_IDENTIFIER' | 'IDENTITY_SIGNAL' | 'UNIQUE_BUT_UNPROVEN' | 'NOT_UNIQUE' | 'NO_EVIDENCE';

export interface ResolvedDecision {
  readonly decisionRef: string;
  readonly kind: 'FIELD_MAPPING' | 'SEMANTIC_TYPE' | 'NO_OP' | 'IDENTITY_PROOF' | 'PRESERVE_UNMAPPED';
  readonly fieldRef: string;
  readonly targetRef: string | null;
  readonly semanticType: string | null;
  readonly identityProof: IdentityProof | null;
  readonly rule: string;
  readonly evidenceRefs: readonly string[];
  /** Where the decision came from: the draft projects these alongside the model's PROPOSED items. */
  readonly origin: 'DETERMINISTIC';
  /** The record mapping the decision belongs to — `${fileId}-${object}` — the scope inside which a target is claimed once. */
  readonly recordId: string | null;
  readonly sourceFieldRef: string;
  readonly destinationField: string | null;
  readonly impactRows: number;
}

export interface ResolveOptions {
  readonly declaredObjects?: Readonly<Record<string, string>>;
  /** The source record id column each file declares (by path or file id) — the project's authoritative identifier, never inferred. */
  readonly recordIdColumns?: Readonly<Record<string, string>>;
}

export interface OpenQuestion {
  readonly questionRef: string;
  readonly taskType: TaskType;
  readonly fieldRefs: readonly string[];
  readonly candidateRefs: readonly string[];
  readonly reason: string;
  /** Semantic complexity, for partitioning: the number of plausible answers, not the number of rows. */
  readonly complexity: number;
}

export interface Resolution {
  readonly decisions: readonly ResolvedDecision[];
  readonly openQuestions: readonly OpenQuestion[];
  /** Decision candidates derived for the open questions, with explicit allowed targets. */
  readonly derivedCandidates: readonly DeterministicCandidate[];
}

const normalise = (text: string): string =>
  text
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[^a-z0-9]+/gu, '');

const SHAPE_TO_SEMANTIC: Readonly<Record<string, string>> = Object.freeze({
  emailLike: 'EMAIL',
  phoneInternational: 'PHONE',
  phoneLocalDigits: 'PHONE',
  isoDate: 'DATE',
  slashDateAmbiguous: 'DATE',
  booleanLike: 'BOOLEAN',
  integer: 'NUMBER',
  decimalPoint: 'NUMBER',
  decimalComma: 'NUMBER',
  groupedNumber: 'NUMBER',
  urlLike: 'URL',
});

/** The semantic type a target field's contract type implies, for exact compatibility. */
function targetSemantic(type: string, options: readonly string[]): string {
  const token = type.toLowerCase();
  if (options.length > 0) return 'ENUM';
  if (token.includes('email')) return 'EMAIL';
  if (token.includes('phone')) return 'PHONE';
  if (token === 'date') return 'DATE';
  if (token.includes('datetime') || token === 'date_time' || token === 'timestamp') return 'DATETIME';
  if (token.includes('bool') || token === 'checkbox') return 'BOOLEAN';
  if (token.includes('number') || token.includes('double') || token.includes('int') || token.includes('currency') || token.includes('percent')) return 'NUMBER';
  if (token.includes('url')) return 'URL';
  return 'TEXT';
}

const SIGNAL_SHAPES = new Set(['emailLike', 'phoneInternational', 'phoneLocalDigits']);
const SIGNAL_HEADER = /email|e-mail|mail|phone|tel|mobile|name|nombre|correo/iu;

/**
 * Identity proof from facts, strictest rule the available facts allow:
 * uniqueness and population come from the profile; authority comes from the
 * declared record id column or from a target the contract flags as an
 * external id, and from nowhere else. A well-formed shape is not authority.
 */
function identityProof(field: SourceFieldFact, authority: { declaredRecordId: boolean; contractExternalId: boolean }): IdentityProof {
  if (field.nonEmptyCount === 0) return 'NO_EVIDENCE';
  if (field.uniqueAmongNonEmpty !== true) return 'NOT_UNIQUE';
  const populatedEverywhere = field.nonEmptyCount === field.rowCount;
  const signal = field.shapeCandidates.some((shape) => SIGNAL_SHAPES.has(shape)) || SIGNAL_HEADER.test(field.header);
  // The record id column the project declares is the identity Migration Core
  // itself runs the file on; a contract's externalId/idLookup flag is the
  // other authority. Neither lends authority to a contact signal: a project
  // that names its Email column as the record id, or a vendor that looks
  // contacts up by email, does not make an email an identity (MC §27, IC-07).
  const authoritative = (authority.declaredRecordId || authority.contractExternalId) && !signal;
  if (authoritative && populatedEverywhere) return 'PROVEN_UNIQUE_IDENTIFIER';
  return signal ? 'IDENTITY_SIGNAL' : 'UNIQUE_BUT_UNPROVEN';
}

export function resolve(contracts: AdaptedContracts, options: ResolveOptions = {}): Resolution {
  const decisions: ResolvedDecision[] = [];
  const questions: OpenQuestion[] = [];
  const derived: DeterministicCandidate[] = [];
  const { profileView, contractView, refs } = contracts;

  // Targets, by normalised label and api name, with the semantic type each implies.
  type TargetEntry = { targetRef: string; semantic: string; options: readonly string[]; required: boolean; writable: boolean; object: string; destinationField: string; identityAuthority: boolean };
  const targets: TargetEntry[] = [];
  const byName = new Map<string, TargetEntry[]>();
  const add = (key: string, entry: TargetEntry): void => {
    const list = byName.get(key) ?? [];
    if (!list.some((existing) => existing.targetRef === entry.targetRef)) list.push(entry);
    byName.set(key, list);
  };
  if (contractView.mode === 'CLEAN_ONLY') {
    for (const name of contractView.canonicalFields) {
      const definition = CANONICAL_FIELDS[name as keyof typeof CANONICAL_FIELDS];
      const entry: TargetEntry = { targetRef: cleanOnlyTargetRef(name), semantic: name.endsWith('email') ? 'EMAIL' : name.endsWith('phone') ? 'PHONE' : name.endsWith('website') || name.endsWith('domain') ? 'URL' : 'TEXT', options: [], required: false, writable: true, object: (name.split('.')[0] ?? '').toUpperCase(), destinationField: name, identityAuthority: false };
      targets.push(entry);
      add(normalise(name.split('.')[1] ?? name), entry);
      add(normalise(name), entry);
      if (definition !== undefined) add(normalise(definition.description.replace(/\.$/u, '')), entry);
    }
  } else {
    for (const field of contractView.fields) {
      const info = refs.targetByRef.get(field.targetRef);
      const delivered = info?.destinationField ?? '';
      const entry: TargetEntry = { targetRef: field.targetRef, semantic: targetSemantic(field.type, field.options), options: field.options, required: field.required, writable: field.createable || field.updateable, object: (delivered.split('.')[0] ?? '').toUpperCase(), destinationField: delivered, identityAuthority: info?.identityAuthority ?? false };
      targets.push(entry);
      if (delivered === '') continue; // outside the support envelope: not a target a proposal may name
      add(normalise(field.label), entry);
      add(normalise(field.apiName), entry);
    }
  }

  // The object of each file: declared by the project, or the object whose
  // fields the headers name strictly most often; a tie is an OBJECT_MAPPING
  // question and the file's fields wait, preserved, for the answer.
  const objectOfFile = new Map<string, string | null>();
  const fileIds = [...new Set(profileView.fields.map((field) => field.fileId))];
  for (const fileId of fileIds) {
    const path = [...refs.fieldByRef.values()].find((entry) => entry.fileId === fileId)?.filePath ?? fileId;
    const declared = options.declaredObjects?.[path] ?? options.declaredObjects?.[fileId];
    if (declared !== undefined) {
      objectOfFile.set(fileId, declared);
      continue;
    }
    const counts = new Map<string, number>();
    for (const field of profileView.fields.filter((entry) => entry.fileId === fileId)) {
      const objects = new Set((byName.get(normalise(field.header)) ?? []).map((entry) => entry.object));
      for (const object of objects) counts.set(object, (counts.get(object) ?? 0) + 1);
    }
    const ranked = [...counts.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1));
    const best = ranked[0];
    const second = ranked[1];
    if (best !== undefined && (second === undefined || best[1] > second[1])) objectOfFile.set(fileId, best[0]);
    else {
      objectOfFile.set(fileId, null);
      const fileFields = profileView.fields.filter((entry) => entry.fileId === fileId);
      const objectCandidateRef = `cand_${digestOf(['derived-object', contracts.candidateSetHash, fileId]).slice(0, 16)}`;
      derived.push({ candidateRef: objectCandidateRef, candidateType: 'DERIVED_OBJECT_DECISION', sourceRefs: fileFields.map((entry) => entry.fieldRef), allowedTargetRefs: [], allowedPrimitiveRefs: [], evidenceRefs: fileFields.flatMap((entry) => entry.evidenceRefs), impactCounts: { rows: fileFields[0]?.rowCount ?? 0, distinct: null }, constraints: { destructiveAllowed: false, identityAutoMergeAllowed: false }, derivedFrom: { candidateSetHash: contracts.candidateSetHash, candidateRef: null, rule: 'RESOLVER_OBJECT_DECISION' } });
      questions.push({ questionRef: `q_${digestOf(['object', fileId]).slice(0, 16)}`, taskType: 'OBJECT_MAPPING', fieldRefs: fileFields.map((entry) => entry.fieldRef), candidateRefs: [objectCandidateRef], reason: ranked.length === 0 ? 'no header names any object' : `headers name ${ranked.slice(0, 3).map(([object, count]) => `${object}x${String(count)}`).join(', ')}`, complexity: Math.max(1, ranked.length) });
    }
  }

  // A target is claimed once per record mapping — the file and its object —
  // never once per run: two files that both hold CONTACT each map their own
  // Email to contact.email, while two columns of one file competing for one
  // target remain a conflict the agency decides.
  const claimed = new Map<string, string>(); // `${recordId}|${targetRef}` → fieldRef, to see double claims inside one record mapping
  const recordIdOf = (fileId: string, object: string | null): string | null => (object === null ? null : `${fileId}-${object.toLowerCase()}`);
  const claimKey = (recordId: string | null, targetRef: string): string => `${recordId ?? ''}|${targetRef}`;
  const declaredRecordIdHeader = (fileId: string): string | null => {
    const path = refs.fieldByRef.get([...refs.fieldByRef.keys()].find((ref) => refs.fieldByRef.get(ref)?.fileId === fileId) ?? '')?.filePath;
    const header = options.recordIdColumns?.[path ?? ''] ?? options.recordIdColumns?.[fileId];
    return header === undefined ? null : normalise(header);
  };
  const facts = profileView.fields.map((field) => {
    const object = objectOfFile.get(field.fileId) ?? null;
    const key = normalise(field.header);
    const matches = key === '' || object === null ? [] : (byName.get(key) ?? []).filter((entry) => entry.writable && entry.object === object);
    const shape = field.shapeCandidates[0] ?? null;
    const impliedSemantic = shape === null ? null : (SHAPE_TO_SEMANTIC[shape] ?? null);
    // Identity authority is a declared fact: the file's record id column, or an exact-name target the contract flags externalId/idLookup.
    const declaredId = declaredRecordIdHeader(field.fileId);
    const authority = { declaredRecordId: declaredId !== null && key !== '' && declaredId === key, contractExternalId: matches.some((entry) => entry.identityAuthority) };
    return { field, object, recordId: recordIdOf(field.fileId, object), matches, shape, impliedSemantic, authority };
  });
  // First pass: the exact matches claim their targets, in field order, so the
  // second pass never offers a claimed target as a plausible answer.
  const decidedFields = new Set<string>();
  for (const { field, recordId, matches, impliedSemantic } of facts) {
    if (field.nonEmptyCount === 0 || matches.length !== 1) continue;
    const target = matches[0] as TargetEntry;
    const compatible = impliedSemantic === null || impliedSemantic === target.semantic || target.semantic === 'TEXT' || (target.semantic === 'ENUM' && impliedSemantic === null);
    if (compatible && !claimed.has(claimKey(recordId, target.targetRef))) {
      claimed.set(claimKey(recordId, target.targetRef), field.fieldRef);
      decidedFields.add(field.fieldRef);
      decisions.push({ decisionRef: `dec_${digestOf(['map', field.fieldRef, target.targetRef]).slice(0, 16)}`, kind: 'FIELD_MAPPING', fieldRef: field.fieldRef, targetRef: target.targetRef, semanticType: target.semantic === 'ENUM' ? 'ENUM' : (impliedSemantic ?? target.semantic), identityProof: null, rule: 'EXACT_HEADER_MATCH_AND_COMPATIBLE_SHAPE', evidenceRefs: field.evidenceRefs, origin: 'DETERMINISTIC', recordId, sourceFieldRef: field.fieldRef, destinationField: target.destinationField, impactRows: field.nonEmptyCount });
    }
  }
  for (const { field, object, recordId, matches, shape, impliedSemantic, authority } of facts) {

    // Identity proof is classified for every field; a proposal may point at it, never grant it.
    const proof = identityProof(field, authority);
    decisions.push({ decisionRef: `dec_${digestOf(['identity', field.fieldRef]).slice(0, 16)}`, kind: 'IDENTITY_PROOF', fieldRef: field.fieldRef, targetRef: null, semanticType: null, identityProof: proof, rule: 'AUTHORITATIVE_IDENTIFIER_UNIQUE_AND_POPULATED', evidenceRefs: field.evidenceRefs, origin: 'DETERMINISTIC', recordId, sourceFieldRef: field.fieldRef, destinationField: null, impactRows: field.nonEmptyCount });

    if (field.nonEmptyCount === 0) {
      decisions.push({ decisionRef: `dec_${digestOf(['noop', field.fieldRef]).slice(0, 16)}`, kind: 'NO_OP', fieldRef: field.fieldRef, targetRef: null, semanticType: null, identityProof: null, rule: 'EMPTY_COLUMN_HAS_NO_IMPACT', evidenceRefs: field.evidenceRefs, origin: 'DETERMINISTIC', recordId, sourceFieldRef: field.fieldRef, destinationField: null, impactRows: 0 });
      continue;
    }

    if (decidedFields.has(field.fieldRef)) continue;

    // A material semantic question: which target, if any, or which type.
    if (object === null) continue; // waits for the object decision; preserved below
    const plausible = targets.filter((entry) => entry.writable && entry.object === object && !claimed.has(claimKey(recordId, entry.targetRef)) && (impliedSemantic === null || entry.semantic === impliedSemantic || entry.semantic === 'TEXT'));
    const candidateRef = `cand_${digestOf(['derived', contracts.candidateSetHash, field.fieldRef]).slice(0, 16)}`;
    const original = contracts.candidates.find((candidate) => candidate.sourceRefs.includes(field.fieldRef)) ?? null;
    derived.push({
      candidateRef,
      candidateType: 'DERIVED_FIELD_DECISION',
      sourceRefs: [field.fieldRef],
      allowedTargetRefs: plausible.map((entry) => entry.targetRef),
      allowedPrimitiveRefs: ['PRESERVE_AS_IS', 'TRIM_WHITESPACE', ...(impliedSemantic === 'EMAIL' ? ['NORMALISE_EMAIL_CASE'] : []), ...(impliedSemantic === 'PHONE' ? ['PARSE_PHONE_E164'] : []), ...(impliedSemantic === 'DATE' ? ['PARSE_DATE_ISO'] : []), ...(impliedSemantic === 'BOOLEAN' ? ['NORMALISE_BOOLEAN'] : []), ...(impliedSemantic === 'NUMBER' ? ['NORMALISE_NUMBER'] : [])],
      evidenceRefs: field.evidenceRefs,
      impactCounts: { rows: field.nonEmptyCount, distinct: field.distinctCount },
      constraints: { destructiveAllowed: false, identityAutoMergeAllowed: false },
      derivedFrom: { candidateSetHash: contracts.candidateSetHash, candidateRef: original?.candidateRef ?? null, rule: 'RESOLVER_FIELD_DECISION' },
    });
    const taskType: TaskType = matches.length > 1 ? 'FIELD_MAPPING' : impliedSemantic === null && shape !== null ? 'SEMANTIC_TYPE' : 'FIELD_MAPPING';
    questions.push({ questionRef: `q_${digestOf(['question', field.fieldRef]).slice(0, 16)}`, taskType, fieldRefs: [field.fieldRef], candidateRefs: [candidateRef], reason: matches.length > 1 ? `header matches ${String(matches.length)} targets` : matches.length === 1 ? 'header matches a target of an incompatible type' : 'no target matches the header', complexity: Math.max(1, plausible.length) });
  }

  // Preservation default for every open field: abstention preserves, never drops.
  const preserved = new Set<string>();
  const fieldsByRef = new Map(profileView.fields.map((field) => [field.fieldRef, field]));
  for (const question of questions) {
    for (const fieldRef of question.fieldRefs) {
      if (preserved.has(fieldRef)) continue;
      preserved.add(fieldRef);
      decisions.push({ decisionRef: `dec_${digestOf(['preserve', fieldRef]).slice(0, 16)}`, kind: 'PRESERVE_UNMAPPED', fieldRef, targetRef: null, semanticType: null, identityProof: null, rule: 'UNMAPPED_IS_PRESERVED', evidenceRefs: [], origin: 'DETERMINISTIC', recordId: recordIdOf(fieldsByRef.get(fieldRef)?.fileId ?? '', objectOfFile.get(fieldsByRef.get(fieldRef)?.fileId ?? '') ?? null), sourceFieldRef: fieldRef, destinationField: null, impactRows: fieldsByRef.get(fieldRef)?.nonEmptyCount ?? 0 });
    }
  }
  void SEMANTIC_TYPES;
  return { decisions, openQuestions: questions, derivedCandidates: derived };
}
