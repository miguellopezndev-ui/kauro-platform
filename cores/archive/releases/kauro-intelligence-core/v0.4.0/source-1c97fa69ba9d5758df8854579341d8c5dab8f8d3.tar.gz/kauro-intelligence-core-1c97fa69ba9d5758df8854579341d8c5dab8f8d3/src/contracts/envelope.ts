/**
 * IntelligenceEnvelopeV1 — the input to one model task, canon §9–§15, §20.
 *
 * The envelope is the minimal view a task needs, structurally separate from
 * instructions, immutable once hashed. It carries facts from the frozen
 * profile, the deterministic candidates the task may choose among, memory
 * evidence, classified exemplars, closed constraints and a budget snapshot.
 * It never carries rows, files, raw personal data or secrets; the classifier
 * and minimizer decide what an exemplar may be, and the egress decision
 * refuses an envelope they did not pass.
 */
import { digestOf } from './canonical.js';
import { CONTRACT_HASH_PATTERN, HEX64_PATTERN, IDENTIFIER_PATTERN, INSTANT_PATTERN, REF_PATTERN, VERSION_PATTERN, s, validate } from './schema.js';
import type { Schema, SchemaProblem } from './schema.js';
import { ENVELOPE_SCHEMA_VERSION } from './versions.js';

export const TASK_TYPES = Object.freeze([
  'OBJECT_MAPPING',
  'FIELD_MAPPING',
  'SEMANTIC_TYPE',
  'TRANSFORMATION_SELECTION',
  'VALUE_MAP',
  'IDENTITY_STRATEGY',
  'DUPLICATE_SIGNAL_STRATEGY',
  'ASSOCIATION_MAPPING',
  'UNMAPPED_HANDLING',
  'TARGET_REQUIREMENT',
  'CONSISTENCY_REVIEW',
  'SEMANTIC_REPAIR',
] as const);
export type TaskType = (typeof TASK_TYPES)[number];

export const PROPOSAL_TYPES = Object.freeze([
  'MAP_OBJECT',
  'MAP_FIELD',
  'SELECT_SEMANTIC_TYPE',
  'APPLY_SUPPORTED_TRANSFORM',
  'MAP_ENUM_VALUE',
  'PROPOSE_IDENTITY_STRATEGY',
  'PROPOSE_DUPLICATE_SIGNAL',
  'MAP_ASSOCIATION',
  'UNMAPPED_PRESERVE',
  'BLOCKING_TARGET_REQUIREMENT',
  'NEEDS_AGENCY_DECISION',
  'ABSTAIN',
] as const);
export type ProposalType = (typeof PROPOSAL_TYPES)[number];

export const DATA_LEVELS = Object.freeze(['L0', 'L1', 'L2'] as const);
export type DataLevel = (typeof DATA_LEVELS)[number];

export const DATA_CLASSES = Object.freeze([
  'SAFE_STRUCTURAL_METADATA',
  'SAFE_LOW_CARDINALITY_SEMANTICS',
  'POTENTIAL_PII',
  'POTENTIAL_SECRET',
  'SENSITIVE_OR_RESTRICTED',
  'FREE_TEXT',
  'UNKNOWN',
] as const);
export type DataClass = (typeof DATA_CLASSES)[number];

export const EXEMPLAR_SELECTION_REASONS = Object.freeze(['SHAPE_CLASS_REPRESENTATIVE', 'RARE_VALUE', 'AMBIGUOUS_SHAPE', 'ENUM_MEMBER', 'OUTLIER_LENGTH'] as const);
export type ExemplarSelectionReason = (typeof EXEMPLAR_SELECTION_REASONS)[number];

/** A fact about a source field, as the profile states it — never recomputed here. */
export interface SourceFieldFact {
  readonly fieldRef: string;
  readonly fileId: string;
  readonly sheet: string | null;
  readonly header: string;
  readonly rowCount: number;
  readonly nonEmptyCount: number;
  readonly distinctCount: number | null;
  readonly uniqueAmongNonEmpty: boolean | null;
  readonly shapeCandidates: readonly string[];
  readonly lengthMin: number | null;
  readonly lengthMax: number | null;
  readonly evidenceRefs: readonly string[];
}

export interface SourceProfileView {
  readonly sourceProfileVersion: string;
  readonly profileHash: string;
  readonly bundleId: string;
  /** Data rows across the whole bundle, from the profile's totals: the coverage a full validation must reach. */
  readonly dataRowCount: number;
  readonly fields: readonly SourceFieldFact[];
}

export interface TargetFieldView {
  readonly targetRef: string;
  readonly objectApiName: string;
  readonly apiName: string;
  readonly label: string;
  readonly type: string;
  readonly createable: boolean;
  readonly updateable: boolean;
  readonly required: boolean;
  readonly unique: boolean;
  readonly options: readonly string[];
}

export interface TargetContractView {
  readonly targetContractVersion: string;
  readonly contractHash: string;
  readonly mode: 'HUBSPOT' | 'SALESFORCE';
  readonly instanceId: string;
  readonly fields: readonly TargetFieldView[];
  readonly relationshipTypes: readonly string[];
}

/** CLEAN_ONLY addresses no vendor: its output contract is Migration Core's own. */
export interface CleanOnlyContractView {
  readonly mode: 'CLEAN_ONLY';
  readonly canonicalFields: readonly string[];
  readonly relationshipTypes: readonly string[];
}

export interface DeterministicCandidate {
  readonly candidateRef: string;
  readonly candidateType: string;
  readonly sourceRefs: readonly string[];
  readonly allowedTargetRefs: readonly string[];
  readonly allowedPrimitiveRefs: readonly string[];
  readonly evidenceRefs: readonly string[];
  readonly impactCounts: { readonly rows: number; readonly distinct: number | null };
  readonly constraints: { readonly destructiveAllowed: false; readonly identityAutoMergeAllowed: false };
  /** How this candidate relates to Migration Core's set: the set's own ref, or the ref it was derived from by the resolver. */
  readonly derivedFrom: { readonly candidateSetHash: string; readonly candidateRef: string | null; readonly rule: string };
}

export interface MemoryEvidenceItem {
  readonly memoryId: string;
  readonly scope: 'CLIENT' | 'AGENCY' | 'GLOBAL';
  readonly knowledgeType: string;
  readonly rule: { readonly sourceHeaderPattern: string; readonly targetRef: string | null; readonly semanticType: string | null };
  readonly verificationOutcome: string;
  readonly weight: number;
  readonly status: 'ACTIVE';
}

export interface Exemplar {
  readonly exemplarRef: string;
  readonly dataLevel: DataLevel;
  readonly fieldRef: string;
  readonly minimizedValueOrClass: string;
  readonly selectionReasonCode: ExemplarSelectionReason;
  readonly maskingPolicyVersion: string;
  readonly dataClass: DataClass;
}

export interface EnvelopeConstraints {
  readonly allowedProposalTypes: readonly ProposalType[];
  readonly allowedTargetIds: readonly string[];
  readonly supportedTransformPrimitives: readonly string[];
  readonly allowedAssociationTypes: readonly string[];
  readonly destructiveAllowed: false;
  readonly identityAutoMergeAllowed: false;
  readonly maxItems: number;
  readonly maxRationaleLength: number;
  readonly dataPolicyVersion: string;
}

export interface BudgetSnapshot {
  readonly maxInputTokens: number;
  readonly maxOutputTokens: number;
  readonly remainingBilledInputTokens: number;
  readonly remainingBilledOutputTokens: number;
  readonly remainingTasks: number;
  readonly deadlineAt: string;
}

export interface RepairContext {
  readonly previousProposalDigest: string;
  readonly validationCodes: readonly string[];
  readonly allowedValues: readonly string[];
  readonly allowedTargetRefs: readonly string[];
}

export interface IntelligenceEnvelopeV1 {
  readonly schemaVersion: string;
  readonly taskId: string;
  readonly taskType: TaskType;
  readonly projectRevisionId: string;
  readonly projectRevisionHash: string;
  readonly supportEnvelopeVersion: string;
  readonly vendorContractVersion: string | null;
  readonly sourceProfileHash: string;
  readonly candidateSetHash: string;
  readonly targetContractHash: string | null;
  readonly sourceProfile: SourceProfileView;
  readonly targetContract: TargetContractView | CleanOnlyContractView;
  readonly deterministicCandidates: readonly DeterministicCandidate[];
  readonly memoryEvidence: readonly MemoryEvidenceItem[];
  readonly exemplars: readonly Exemplar[];
  readonly constraints: EnvelopeConstraints;
  readonly budgetSnapshot: BudgetSnapshot;
  readonly repairContext: RepairContext | null;
}

const ref = s.string({ pattern: REF_PATTERN, maxLength: 64 });
const hex64 = s.string({ pattern: HEX64_PATTERN });
const contractHash = s.string({ pattern: CONTRACT_HASH_PATTERN });
const identifier = s.string({ pattern: IDENTIFIER_PATTERN });
const shortText = s.string({ maxLength: 256 });
const counter = s.integer({ min: 0, max: Number.MAX_SAFE_INTEGER });

const fieldFactSchema = s.object({
  fieldRef: ref,
  fileId: identifier,
  sheet: s.nullable(identifier),
  header: s.string({ maxLength: 512 }),
  rowCount: counter,
  nonEmptyCount: counter,
  distinctCount: s.nullable(counter),
  uniqueAmongNonEmpty: s.nullable(s.boolean()),
  shapeCandidates: s.array(identifier, { maxItems: 16, unique: true }),
  lengthMin: s.nullable(counter),
  lengthMax: s.nullable(counter),
  evidenceRefs: s.array(ref, { maxItems: 32, unique: true }),
});

const targetFieldSchema = s.object({
  targetRef: ref,
  objectApiName: identifier,
  apiName: identifier,
  label: shortText,
  type: identifier,
  createable: s.boolean(),
  updateable: s.boolean(),
  required: s.boolean(),
  unique: s.boolean(),
  options: s.array(s.string({ maxLength: 256 }), { maxItems: 2048 }),
});

const targetContractSchema = s.oneOf([
  s.object({
    targetContractVersion: s.string({ pattern: VERSION_PATTERN }),
    contractHash: contractHash,
    mode: s.enumOf(['HUBSPOT', 'SALESFORCE']),
    instanceId: identifier,
    fields: s.array(targetFieldSchema, { maxItems: 4096 }),
    relationshipTypes: s.array(identifier, { maxItems: 16, unique: true }),
  }),
  s.object({
    mode: s.literal('CLEAN_ONLY'),
    canonicalFields: s.array(identifier, { maxItems: 512, unique: true }),
    relationshipTypes: s.array(identifier, { maxItems: 16, unique: true }),
  }),
]);

const candidateSchema = s.object({
  candidateRef: ref,
  candidateType: identifier,
  sourceRefs: s.array(ref, { maxItems: 64, unique: true }),
  allowedTargetRefs: s.array(ref, { maxItems: 512, unique: true }),
  allowedPrimitiveRefs: s.array(identifier, { maxItems: 32, unique: true }),
  evidenceRefs: s.array(ref, { maxItems: 64, unique: true }),
  impactCounts: s.object({ rows: counter, distinct: s.nullable(counter) }),
  constraints: s.object({ destructiveAllowed: s.literal(false), identityAutoMergeAllowed: s.literal(false) }),
  derivedFrom: s.object({ candidateSetHash: contractHash, candidateRef: s.nullable(ref), rule: identifier }),
});

const memoryEvidenceSchema = s.object({
  memoryId: ref,
  scope: s.enumOf(['CLIENT', 'AGENCY', 'GLOBAL']),
  knowledgeType: identifier,
  rule: s.object({ sourceHeaderPattern: s.string({ maxLength: 256 }), targetRef: s.nullable(ref), semanticType: s.nullable(identifier) }),
  verificationOutcome: identifier,
  weight: s.number({ min: 0, max: 1 }),
  status: s.literal('ACTIVE'),
});

const exemplarSchema = s.object({
  exemplarRef: ref,
  dataLevel: s.enumOf([...DATA_LEVELS]),
  fieldRef: ref,
  minimizedValueOrClass: s.string({ maxLength: 128 }),
  selectionReasonCode: s.enumOf([...EXEMPLAR_SELECTION_REASONS]),
  maskingPolicyVersion: s.string({ pattern: VERSION_PATTERN }),
  dataClass: s.enumOf(['SAFE_STRUCTURAL_METADATA', 'SAFE_LOW_CARDINALITY_SEMANTICS']),
});

export const ENVELOPE_SCHEMA: Schema = s.object({
  schemaVersion: s.literal(ENVELOPE_SCHEMA_VERSION),
  taskId: ref,
  taskType: s.enumOf([...TASK_TYPES]),
  projectRevisionId: identifier,
  projectRevisionHash: hex64,
  supportEnvelopeVersion: s.string({ pattern: VERSION_PATTERN }),
  vendorContractVersion: s.nullable(s.string({ pattern: VERSION_PATTERN })),
  sourceProfileHash: contractHash,
  candidateSetHash: contractHash,
  targetContractHash: s.nullable(contractHash),
  sourceProfile: s.object({
    sourceProfileVersion: s.string({ pattern: VERSION_PATTERN }),
    profileHash: contractHash,
    bundleId: identifier,
    dataRowCount: counter,
    fields: s.array(fieldFactSchema, { maxItems: 4096 }),
  }),
  targetContract: targetContractSchema,
  deterministicCandidates: s.array(candidateSchema, { maxItems: 512 }),
  memoryEvidence: s.array(memoryEvidenceSchema, { maxItems: 64 }),
  exemplars: s.array(exemplarSchema, { maxItems: 256 }),
  constraints: s.object({
    allowedProposalTypes: s.array(s.enumOf([...PROPOSAL_TYPES]), { minItems: 1, unique: true }),
    allowedTargetIds: s.array(ref, { maxItems: 4096, unique: true }),
    supportedTransformPrimitives: s.array(identifier, { maxItems: 64, unique: true }),
    allowedAssociationTypes: s.array(identifier, { maxItems: 16, unique: true }),
    destructiveAllowed: s.literal(false),
    identityAutoMergeAllowed: s.literal(false),
    maxItems: s.integer({ min: 1, max: 512 }),
    maxRationaleLength: s.integer({ min: 16, max: 512 }),
    dataPolicyVersion: s.string({ pattern: VERSION_PATTERN }),
  }),
  budgetSnapshot: s.object({
    maxInputTokens: s.integer({ min: 1 }),
    maxOutputTokens: s.integer({ min: 1 }),
    remainingBilledInputTokens: counter,
    remainingBilledOutputTokens: counter,
    remainingTasks: counter,
    deadlineAt: s.string({ pattern: INSTANT_PATTERN }),
  }),
  repairContext: s.nullable(
    s.object({
      previousProposalDigest: hex64,
      validationCodes: s.array(identifier, { minItems: 1, maxItems: 64 }),
      allowedValues: s.array(s.string({ maxLength: 256 }), { maxItems: 2048 }),
      allowedTargetRefs: s.array(ref, { maxItems: 512 }),
    }),
  ),
});

/** Structural problems plus the referential ones a schema cannot state. */
export function envelopeProblems(envelope: unknown): readonly SchemaProblem[] {
  const problems = [...validate(envelope, ENVELOPE_SCHEMA)];
  if (problems.length > 0) return problems;
  const value = envelope as IntelligenceEnvelopeV1;
  const fieldRefs = new Set(value.sourceProfile.fields.map((field) => field.fieldRef));
  const targetRefs = new Set(value.targetContract.mode === 'CLEAN_ONLY' ? value.targetContract.canonicalFields.map((name) => cleanOnlyTargetRef(name)) : value.targetContract.fields.map((field) => field.targetRef));
  const candidateRefs = new Set<string>();
  value.deterministicCandidates.forEach((candidate, index) => {
    if (candidateRefs.has(candidate.candidateRef)) problems.push({ pointer: `/deterministicCandidates/${String(index)}/candidateRef`, message: 'duplicate candidateRef' });
    candidateRefs.add(candidate.candidateRef);
    if (candidate.derivedFrom.candidateSetHash !== value.candidateSetHash) problems.push({ pointer: `/deterministicCandidates/${String(index)}/derivedFrom`, message: 'derived from another candidate set' });
    candidate.sourceRefs.forEach((sourceRef, at) => {
      if (!fieldRefs.has(sourceRef)) problems.push({ pointer: `/deterministicCandidates/${String(index)}/sourceRefs/${String(at)}`, message: 'names a field the profile view does not carry' });
    });
    candidate.allowedTargetRefs.forEach((targetRef, at) => {
      if (!targetRefs.has(targetRef)) problems.push({ pointer: `/deterministicCandidates/${String(index)}/allowedTargetRefs/${String(at)}`, message: 'names a target the contract view does not carry' });
      if (!value.constraints.allowedTargetIds.includes(targetRef)) problems.push({ pointer: `/deterministicCandidates/${String(index)}/allowedTargetRefs/${String(at)}`, message: 'outside constraints.allowedTargetIds' });
    });
  });
  value.exemplars.forEach((exemplar, index) => {
    if (!fieldRefs.has(exemplar.fieldRef)) problems.push({ pointer: `/exemplars/${String(index)}/fieldRef`, message: 'names a field the profile view does not carry' });
  });
  value.constraints.allowedTargetIds.forEach((targetRef, index) => {
    if (!targetRefs.has(targetRef)) problems.push({ pointer: `/constraints/allowedTargetIds/${String(index)}`, message: 'names a target the contract view does not carry' });
  });
  if (value.targetContract.mode === 'CLEAN_ONLY') {
    if (value.targetContractHash !== null) problems.push({ pointer: '/targetContractHash', message: 'CLEAN_ONLY addresses no vendor instance and carries no target contract hash' });
    if (value.vendorContractVersion !== null) problems.push({ pointer: '/vendorContractVersion', message: 'CLEAN_ONLY carries no vendor contract version' });
  } else {
    if (value.targetContractHash !== value.targetContract.contractHash) problems.push({ pointer: '/targetContractHash', message: 'does not match the contract view' });
    if (value.vendorContractVersion !== value.targetContract.targetContractVersion) problems.push({ pointer: '/vendorContractVersion', message: 'does not match the contract view' });
  }
  if (value.sourceProfileHash !== value.sourceProfile.profileHash) problems.push({ pointer: '/sourceProfileHash', message: 'does not match the profile view' });
  if (value.taskType === 'SEMANTIC_REPAIR' && value.repairContext === null) problems.push({ pointer: '/repairContext', message: 'a repair task carries its repair context' });
  if (value.taskType !== 'SEMANTIC_REPAIR' && value.repairContext !== null) problems.push({ pointer: '/repairContext', message: 'only a repair task carries a repair context' });
  return problems;
}

export function cleanOnlyTargetRef(canonicalField: string): string {
  // A CLEAN_ONLY target is a canonical field of Migration Core's own output
  // contract; its ref is derived from the name so it is stable and closed.
  return `tgt_${digestOf(`CLEAN_ONLY:${canonicalField}`).slice(0, 16)}`;
}

export function envelopeHash(envelope: IntelligenceEnvelopeV1): string {
  return digestOf(envelope);
}
