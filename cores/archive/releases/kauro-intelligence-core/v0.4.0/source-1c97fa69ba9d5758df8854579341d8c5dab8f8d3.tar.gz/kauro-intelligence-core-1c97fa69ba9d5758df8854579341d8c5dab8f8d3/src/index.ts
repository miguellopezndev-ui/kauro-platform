/**
 * Kauro Intelligence Core — public entry.
 *
 * Intelligence interprets and proposes; Migration Core executes and proves;
 * the agency decides what is ambiguous or destructive. Everything a host
 * needs is exported here and nothing else exists for it: the API, the
 * contracts, the versions, the gateway interface with its offline
 * implementations, the ledger with its injectable store and clock, the
 * memory resolver, the benchmark format.
 */
export { createIntelligenceCore } from './api/intelligence-core.js';
export type { IntelligenceCore, IntelligenceResult, DraftMigrationPlan } from './api/intelligence-core.js';

export type { HostContext, IntelligenceInput, ProjectRevision, ResourceProfile, CandidateConfiguration, ConfigFragmentField, FullDatasetValidationPort, FullDatasetValidationResult, CoreDependencies } from './ports/ports.js';

export * from './contracts/versions.js';
export { canonicalJson, digestOf, sha256Hex, stableRef, CanonicalError } from './contracts/canonical.js';
export { validate, parseJsonBounded, DEFAULT_LIMITS, SUSPICIOUS_UNICODE } from './contracts/schema.js';
export type { Schema, SchemaProblem, SchemaLimits } from './contracts/schema.js';
export { IntelligenceError, isIntelligenceError, ERROR_CODES, TASK_OUTCOMES } from './contracts/errors.js';
export type { ErrorCode, TaskOutcome } from './contracts/errors.js';
export { ENVELOPE_SCHEMA, TASK_TYPES, PROPOSAL_TYPES, DATA_LEVELS, DATA_CLASSES, envelopeProblems, envelopeHash, cleanOnlyTargetRef } from './contracts/envelope.js';
export type { IntelligenceEnvelopeV1, TaskType, ProposalType, DataLevel, DataClass, Exemplar, DeterministicCandidate, EnvelopeConstraints, BudgetSnapshot, RepairContext, SourceProfileView, SourceFieldFact, TargetContractView, CleanOnlyContractView, MemoryEvidenceItem } from './contracts/envelope.js';
export { PROPOSAL_SCHEMA, PROPOSAL_ITEM_SCHEMA, PRIMITIVES, PRIMITIVE_REFS, RATIONALE_CODES, EVIDENCE_CLASSES, ABSTAIN_REASONS, proposalJsonSchema, proposalShapeProblems } from './contracts/proposal.js';
export type { IntelligenceProposalV1, ProposalItem, PrimitiveRef, RationaleCode, EvidenceClass } from './contracts/proposal.js';
export { RUN_STATES, RUN_TRANSITIONS, TERMINAL_RUN_STATES, BUDGET_LIMITS, MEMORY_SCOPES, MEMORY_STATES, OUTCOME_LADDER } from './contracts/run.js';
export type { RunState, TaskRecord, TaskResult, Usage, Reservation, MemoryEntry, MemoryCandidate, MemoryScope, MemoryState, VerificationOutcome } from './contracts/run.js';

export { RunLedger, MemoryLedgerStore, SystemClock, VirtualClock } from './kernel/ledger.js';
export type { Clock, LedgerStore, LedgerEvent, RunView, BudgetView } from './kernel/ledger.js';

export { adaptContracts } from './adapter/contract-adapter.js';
export type { AdaptedContracts, RefTable } from './adapter/contract-adapter.js';
export { resolve as resolveDeterministically } from './resolver/deterministic-resolver.js';
export type { Resolution, ResolvedDecision, OpenQuestion, IdentityProof } from './resolver/deterministic-resolver.js';
export { plan as planTasks, MAX_COMPLEXITY_PER_TASK, MAX_QUESTIONS_PER_TASK } from './planner/task-planner.js';
export type { Plan } from './planner/task-planner.js';
export { resolveMemory, memoryCandidateFrom, promoteCandidate, retireForDeletedClient, INSTRUCTION_LIKE } from './memory/memory-resolver.js';
export type { MemoryQuery, MemoryResolution, TenantContext } from './memory/memory-resolver.js';
export { classifyValue, classifyMetadataText, maskShape } from './classifier/data-classifier.js';
export type { Classification } from './classifier/data-classifier.js';
export { buildEnvelope, minimize, decideEgress, assertEgressBinds, MASKING_POLICY_VERSION, DATA_POLICY_VERSION } from './envelope/envelope-builder.js';
export type { BuiltEnvelope, EgressDecision, EgressDecisionKind, MinimizationReport, CategoricalSummaries } from './envelope/envelope-builder.js';
export { MODEL_POLICY_V1, MODEL_POLICY_HASH, PROMPT_BUNDLE_V1, PROMPT_BUNDLE_HASH } from './gateway/model-gateway.js';
export type { ModelGateway, ModelPolicy, GatewayRequest, GatewayResult, GatewayUsage } from './gateway/model-gateway.js';
export { scriptedGateway, replayGateway, oracleGateway, oracleProposal } from './gateway/fake-gateway.js';
export type { ScriptEntry, ScriptedGateway } from './gateway/fake-gateway.js';
export { transportGateway, buildProviderRequest, parseProviderResponse } from './gateway/transport-gateway.js';
export type { Transport, ProviderRequest, ProviderResponse } from './gateway/transport-gateway.js';
export { parseProposal, compileProposal } from './compiler/compiler.js';
export type { CompiledTask, CompiledItem, ParseResult } from './compiler/compiler.js';
export { sealExpectedTruth, scoreFixture, report as benchmarkReport, FIXTURE_FAMILIES, HARD_GATES } from './benchmark/harness.js';
export type { BenchmarkFixture, FixtureScore, BenchmarkReport, FixtureFamily } from './benchmark/harness.js';
export { usageIsValid, type AppendOutcome } from './kernel/ledger.js';
export { FULL_DATASET_VALIDATION_RESULT_SCHEMA } from './ports/ports.js';
export { MAX_INVOCATIONS_PER_REQUEST } from './contracts/run.js';
export { TransportError, parseProviderRequestPayload } from './gateway/transport-gateway.js';
export type { TransportStage, ProviderRequestHeader, ProviderRequestPayload } from './gateway/transport-gateway.js';
export { oracleTransport } from './gateway/fake-gateway.js';
export type { ScriptPayload } from './gateway/fake-gateway.js';
export type { MetadataKind } from './classifier/data-classifier.js';
export { BENCHMARK_FIXTURE_FORMAT_VERSION, EXPECTED_DECISIONS, OUTCOME_CLASSES, QUALITY_THRESHOLDS, SCORER_FAILURES, fixtureProblems, truthIntact, observeEgress, outcomeClassOf, qualifyThreeRuns, type UnsealedFixture, type ExpectedCandidate, type ExpectedDecision, type ExpectedInputHashes, type BudgetCeiling, type HardGateMarkers, type HardGate, type OutcomeClass, type ObservedEgress, type ScoreCheck, type GateReport, type FamilyRate, type Qualification } from './benchmark/harness.js';
// The runner surface an IC-2 benchmark runner needs from the packed tarball: the capture at the transport, the wire-form and body tests, the report modes, the qualification universe and the report digest.
export { capturingTransport, isTransportBody, wireForms, REPORT_MODES, QUALIFICATION_CORPUS, corpusShortfall, reportDigestOf } from './benchmark/harness.js';
export type { ReportMode, ObservedOutcomeClass } from './benchmark/harness.js';
