#!/usr/bin/env node
/**
 * Sabotage: each material gate is broken in turn and the suite must kill it.
 *
 * A copy of the tree is made under tmp/sabotage-tree, one mutation is applied
 * to a source file in the copy, the copy is built and its tests run, and the
 * outcome is classified: KILLED when the suite fails on an assertion,
 * SURVIVED when it passes, DID_NOT_COMPILE when the build fails, INFRA_ERROR
 * when the runner itself failed or the run timed out. Only KILLED counts; a
 * mutation that did not compile, timed out or could not run is not a kill. A
 * healthy baseline must pass first or nothing here means anything. Nothing
 * under the real tree is touched.
 *
 * Two modes, two files, never confused:
 *
 *   node tools/sabotage.mjs                QUALIFICATION — the whole inventory;
 *                                          writes tmp/sabotage-report.json,
 *                                          exit 0 only when every id is killed.
 *   node tools/sabotage.mjs --only a,b     DIAGNOSTIC — the ids named, for a
 *                                          developer; writes
 *                                          tmp/sabotage-diagnostic.json with
 *                                          qualifies:false and passed:false,
 *                                          exit 0 when the selection is killed.
 *                                          An unknown or empty selection is
 *                                          exit 2, not an empty PASS.
 *
 * The qualification report binds itself to what it measured: the commit and
 * tree it ran on and whether the tree was clean, the digests of the inventory
 * files, of this runner and the test driver, and of every production file
 * before mutation; and its counts come from unique reached ids, so a partial
 * or edited record set cannot add up to the inventory.
 */
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SABOTAGE_GATE, gitSubject, loadInventory, producerHashes, qualifies, recount, sha256File } from './lib/verify-sabotage-report.mjs';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const copy = join(root, 'tmp', 'sabotage-tree');
// A build-and-test that has not finished in ten minutes is broken infrastructure, not a kill.
const RUN_TIMEOUT_MS = 10 * 60 * 1000;

const args = process.argv.slice(2);
const selected = [];
for (let i = 0; i < args.length; i += 1) {
  if (args[i] === '--only') {
    const value = args[i + 1];
    if (value === undefined || value.startsWith('--')) {
      process.stderr.write('--only needs one or more mutation ids (comma-separated)\n');
      process.exit(2);
    }
    selected.push(...value.split(',').map((id) => id.trim()).filter((id) => id !== ''));
    i += 1;
  } else {
    process.stderr.write(`unknown argument ${args[i]}\n`);
    process.exit(2);
  }
}
const mode = args.includes('--only') ? 'DIAGNOSTIC' : 'QUALIFICATION';

let inventory;
try {
  inventory = await loadInventory(root);
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exit(2);
}
const MUTATIONS = inventory.mutations;
if (MUTATIONS.length === 0) {
  process.stderr.write('the inventory is empty; an empty inventory qualifies nothing\n');
  process.exit(2);
}
if (mode === 'DIAGNOSTIC') {
  const known = new Set(MUTATIONS.map((mutation) => mutation.id));
  const unknown = selected.filter((id) => !known.has(id));
  if (selected.length === 0 || unknown.length > 0) {
    process.stderr.write(`--only names ${selected.length === 0 ? 'no mutation' : `unknown mutation(s) ${unknown.join(', ')}`}; the inventory has: ${[...known].join(', ')}\n`);
    process.exit(2);
  }
}
const chosen = mode === 'DIAGNOSTIC' ? MUTATIONS.filter((mutation) => selected.includes(mutation.id)) : MUTATIONS;

function run(command, cmdArgs, options = {}) {
  return spawnSync(command, cmdArgs, { encoding: 'utf8', maxBuffer: 256 * 1024 * 1024, shell: process.platform === 'win32' && command === 'npm', ...options });
}

function classify(result) {
  if (result.error?.code === 'ETIMEDOUT' || (result.error !== undefined && result.signal !== null)) return { outcome: 'INFRA_ERROR', detail: `TIMEOUT after ${String(RUN_TIMEOUT_MS)}ms`, timedOut: true };
  if (result.error) return { outcome: 'INFRA_ERROR', detail: String(result.error.message) };
  const out = `${result.stdout ?? ''}${result.stderr ?? ''}`;
  if (/build exited|error TS\d+/u.test(out)) return { outcome: 'DID_NOT_COMPILE', detail: (out.match(/error TS\d+[^\n]*/u) ?? ['tsc failed'])[0] };
  const fail = out.match(/ℹ fail (\d+)/u);
  const pass = out.match(/ℹ pass (\d+)/u);
  if (fail === null || pass === null) return { outcome: 'INFRA_ERROR', detail: 'no test summary in the output' };
  if (Number(fail[1]) > 0) return { outcome: 'KILLED', detail: `${fail[1]} of ${String(Number(fail[1]) + Number(pass[1]))} tests failed` };
  return { outcome: 'SURVIVED', detail: `${pass[1]} tests passed` };
}

function timed(fn) {
  const started = Date.now();
  const value = fn();
  return { ...value, durationMs: Date.now() - started };
}

const suite = () => run(process.execPath, ['tools/run-tests.mjs'], { cwd: copy, timeout: RUN_TIMEOUT_MS, killSignal: 'SIGKILL' });

// What the report binds to, read before anything is copied or built.
const startedAt = new Date().toISOString();
const subject = gitSubject(root);
const producers = producerHashes(root);
const productionFiles = [...new Set(MUTATIONS.map((mutation) => mutation.file))].sort().map((file) => ({ file, sha256: sha256File(join(root, file)) }));
const reportPath = join(root, 'tmp', mode === 'QUALIFICATION' ? 'sabotage-report.json' : 'sabotage-diagnostic.json');
mkdirSync(join(root, 'tmp'), { recursive: true });
// A stale qualification report must not outlive the start of a new run.
if (mode === 'QUALIFICATION') rmSync(reportPath, { force: true });

rmSync(copy, { recursive: true, force: true });
mkdirSync(copy, { recursive: true });
for (const entry of ['src', 'test', 'tools', 'vendor', 'package.json', 'package-lock.json', 'tsconfig.json', '.npmrc']) cpSync(join(root, entry), join(copy, entry), { recursive: true });
// node_modules by junction/symlink: the same dependencies, no reinstall.
run(process.platform === 'win32' ? 'cmd' : 'ln', process.platform === 'win32' ? ['/c', 'mklink', '/J', join(copy, 'node_modules'), join(root, 'node_modules')] : ['-s', join(root, 'node_modules'), join(copy, 'node_modules')]);
if (!existsSync(join(copy, 'node_modules', 'typescript'))) {
  process.stderr.write('could not link node_modules into the sabotage copy\n');
  process.exit(2);
}

const baseline = timed(() => classify(suite()));
if (baseline.outcome !== 'SURVIVED') {
  rmSync(copy, { recursive: true, force: true });
  process.stderr.write(`the baseline does not pass (${baseline.outcome}: ${baseline.detail}); a kill against a broken baseline proves nothing\n`);
  process.exit(1);
}

const results = [];
for (const mutation of chosen) {
  const path = join(copy, mutation.file);
  const original = readFileSync(path, 'utf8');
  const record = { id: mutation.id, inventoryFile: mutation.inventoryFile, file: mutation.file, gate: mutation.gate };
  if (!original.includes(mutation.from)) {
    results.push({ ...record, outcome: 'NOT_REACHED', detail: 'the text to mutate is not in the file; the mutation is stale', durationMs: 0 });
    process.stderr.write(`  ${'NOT_REACHED'.padEnd(15)} ${mutation.id.padEnd(36)} stale\n`);
    continue;
  }
  writeFileSync(path, original.replace(mutation.from, mutation.to));
  const outcome = timed(() => classify(suite()));
  writeFileSync(path, original);
  results.push({ ...record, ...outcome });
  process.stderr.write(`  ${outcome.outcome.padEnd(15)} ${mutation.id.padEnd(36)} ${outcome.detail} (${String(outcome.durationMs)}ms)\n`);
}
rmSync(copy, { recursive: true, force: true });

// Counts over unique reached ids of the whole inventory, in both modes: a
// diagnostic over one id therefore reports the other ids as not reached.
const recomputed = recount(results, MUTATIONS.map((mutation) => mutation.id));
const counts = recomputed.counts;
const passed = qualifies(mode, baseline, counts, recomputed.missing);
const selectionKilled = chosen.length > 0 && chosen.every((mutation) => results.find((result) => result.id === mutation.id)?.outcome === 'KILLED');
const report = {
  gate: SABOTAGE_GATE,
  mode,
  // A diagnostic never qualifies, whatever it killed; a consumer that wants qualification reads this field, not passed.
  qualifies: passed,
  subject,
  node: process.version,
  startedAt,
  finishedAt: new Date().toISOString(),
  inventory: { files: inventory.files, ids: MUTATIONS.map((mutation) => ({ id: mutation.id, inventoryFile: mutation.inventoryFile, file: mutation.file, gate: mutation.gate })) },
  producers,
  productionFiles,
  baseline,
  ...(mode === 'DIAGNOSTIC' ? { selection: { requested: selected, allKilled: selectionKilled } } : {}),
  counts,
  mutations: results,
  passed,
};
writeFileSync(reportPath, `${JSON.stringify(report, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
if (mode === 'QUALIFICATION') {
  process.stderr.write(`\n${SABOTAGE_GATE} = ${passed ? 'PASS' : 'FALSE'}: ${String(counts.killed)} killed of ${String(MUTATIONS.length)} (survived ${String(counts.survived)}, did not compile ${String(counts.didNotCompile)}, infra ${String(counts.infraError)}, not reached ${String(counts.notReached)})${subject.dirty ? '; the tree was dirty' : ''}\n`);
  process.exit(passed ? 0 : 1);
}
process.stderr.write(`\n${SABOTAGE_GATE} DIAGNOSTIC (does not qualify): ${selectionKilled ? 'selection killed' : 'selection not killed'} — ${String(chosen.length)} of ${String(MUTATIONS.length)} run, written to tmp/sabotage-diagnostic.json\n`);
process.exit(selectionKilled ? 0 : 1);
