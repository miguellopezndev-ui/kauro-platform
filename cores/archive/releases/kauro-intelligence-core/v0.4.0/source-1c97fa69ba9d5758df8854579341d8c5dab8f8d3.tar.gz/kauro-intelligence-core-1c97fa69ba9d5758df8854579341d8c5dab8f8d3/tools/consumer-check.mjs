#!/usr/bin/env node
/**
 * The packed Intelligence Core, consumed by a TypeScript strict project
 * outside this tree, offline, with no credential: the host API and its
 * types resolve, a run completes against the frozen Migration Core in a
 * host adapter, and no network is needed or attempted.
 *
 * The temporary project holds the packed kauro-intelligence-core tarball and
 * the vendored Migration Core tarball, installed from bytes; `tsc` runs from
 * this repository's node_modules against the project, so resolution starts
 * at the project and nothing points back here.
 */
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const manifest = JSON.parse(readFileSync(join(root, 'vendor', 'MANIFEST.json'), 'utf8'));
const work = join(tmpdir(), `kauro-ic-consumer-${String(process.pid)}`);
rmSync(work, { recursive: true, force: true });
mkdirSync(work, { recursive: true });
const shell = process.platform === 'win32';
const run = (command, args, options = {}) => spawnSync(command, args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, shell: shell && command === 'npm', ...options });

const CONSUMER = String.raw`
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import {
  SCRATCH_BUDGET_BYTES,
  buildCandidateSet,
  createFilesystemScratchStore,
  loadConfig,
  produceSourceProfile,
  runMigration,
  verifyPackage,
  writePackage,
} from '${manifest.name}';
import type { HashedSourceProfile } from '${manifest.name}';
import {
  BUDGET_LIMITS,
  INTELLIGENCE_CORE_VERSION,
  MODEL_POLICY_VERSION,
  PROMPT_BUNDLE_VERSION,
  MemoryLedgerStore,
  VirtualClock,
  compatibilityMatrix,
  createIntelligenceCore,
  digestOf,
  oracleGateway,
} from 'kauro-intelligence-core';
import type { CandidateConfiguration, ConfigFragmentField, FullDatasetValidationPort, FullDatasetValidationResult, IntelligenceInput, IntelligenceResult } from 'kauro-intelligence-core';

// A directory this program owns: made by it, marked by it, removed by it on every exit.
const work = resolve(mkdtempSync(join(tmpdir(), 'kauro-ic-consumer-run-')));
writeFileSync(join(work, 'OWNER'), JSON.stringify({ owner: 'kauro-intelligence-core consumer check', pid: process.pid }));
try {
  writeFileSync(join(work, 'contacts.csv'), 'Contact ID,First Name,Last Name,Email,Phone,Status\n1,Ada,Lovelace,ada@consumer.test,300 123 4567,Active\n2,Grace,Hopper,grace@consumer.test,+1 415 555 0100,Inactive\n');
  const configText = JSON.stringify({ configVersion: '2.0.0', source: { system: 'consumer', namespace: 'consumer' }, target: { mode: 'CLEAN_ONLY', importMode: 'CREATE_ONLY' }, files: [{ id: 'contacts', path: 'contacts.csv', format: 'CSV' }], records: [{ id: 'contacts', fileId: 'contacts', object: 'CONTACT', sourceRecordIdColumn: { header: 'Contact ID' }, fields: [{ column: { header: 'Email' }, destinationField: 'contact.email', semanticType: 'EMAIL' }] }] });
  const loaded = loadConfig(configText, join(work, 'config.json'));
  const scratch = createFilesystemScratchStore({ root: join(work, 'scratch'), runId: 'profile', quotaBytes: SCRATCH_BUDGET_BYTES });
  const profile: HashedSourceProfile = produceSourceProfile({ inputRoot: work, config: loaded.config, scratch });
  scratch.dispose();
  const candidateSet = buildCandidateSet({ profile, configHash: loaded.configHash });

  // Every authorised element of a fragment field, or the reason the frozen schema cannot take it.
  const translate = (field: ConfigFragmentField): { options: Record<string, unknown> } | { problem: string } => {
    const params = field.typedTransformParams ?? {};
    const unsupported = (why: string): { problem: string } => ({ problem: 'UNSUPPORTED_BY_CORE:' + String(field.transformPrimitive) + ':' + why });
    switch (field.transformPrimitive) {
      case null:
      case 'PRESERVE_AS_IS':
        return { options: {} };
      case 'TRIM_WHITESPACE':
        return { options: { trim: true } };
      case 'NORMALISE_EMAIL_CASE':
        return field.semanticType === 'EMAIL' ? { options: { lowercaseDomain: true } } : unsupported('only for EMAIL');
      case 'PARSE_PHONE_E164':
        return field.semanticType === 'PHONE' && /^[A-Z]{2}$/u.test(params['defaultRegion'] ?? '') ? { options: { phoneCountry: params['defaultRegion'] } } : unsupported('needs PHONE and defaultRegion');
      case 'NORMALISE_NUMBER':
        return field.semanticType === 'NUMBER' && /^[.,]$/u.test(params['decimalSeparator'] ?? '') ? { options: { decimalSeparator: params['decimalSeparator'], thousandsSeparator: 'NONE' } } : unsupported('needs NUMBER and decimalSeparator');
      case 'NORMALISE_BOOLEAN':
        return field.semanticType === 'BOOLEAN' ? { options: {} } : unsupported('only for BOOLEAN');
      default:
        return unsupported('no representation in the frozen configuration schema');
    }
  };
  const columnIndex = (field: ConfigFragmentField): number | null => {
    for (const file of profile.profile.files) {
      if (file.fileId !== field.fileId || file.path !== field.filePath) continue;
      for (const sheet of file.sheets) {
        const column = sheet.columns.find((entry) => entry.columnLocatorId === field.columnLocator);
        if (column !== undefined && (column.headerRaw ?? '') === field.columnHeader) return column.columnIndex;
      }
    }
    return null;
  };

  // One clock for the run and for the receipts it validates: a receipt dated after the run's now is refused.
  const clock = new VirtualClock();

  // The host's validation port: the frozen engine over the whole fixture, every fragment element carried or refused.
  const port: FullDatasetValidationPort = {
    async validate(configuration: CandidateConfiguration): Promise<FullDatasetValidationResult> {
      const bound = { configurationRef: configuration.configurationRef, configurationDigest: digestOf(configuration), profileHash: profile.profileHash, candidateSetHash: configuration.candidateSetHash, targetContractHash: null, rowsInProfile: profile.profile.totals.dataRowCount, validatedAt: clock.now(), coreVersion: '2.0.1' };
      const problems: string[] = [];
      const fields: Record<string, unknown>[] = [];
      let object: string | null = null;
      for (const field of configuration.fields) {
        if (field.filePath !== 'contacts.csv') { problems.push('FILE_UNKNOWN:' + field.fileId); continue; }
        if (object !== null && object !== field.object) { problems.push('MULTIPLE_OBJECTS_FOR_FILE:' + field.filePath); continue; }
        object = field.object;
        const index = columnIndex(field);
        if (index === null) { problems.push('COLUMN_LOCATOR_UNKNOWN:' + field.columnLocator); continue; }
        const translated = translate(field);
        if ('problem' in translated) { problems.push(translated.problem); continue; }
        // An ENUM destination carries the contract's options as the frozen schema's allowedValues.
        if (field.semanticType === 'ENUM' && (field.allowedValues === undefined || field.allowedValues.length === 0)) { problems.push('ENUM_WITHOUT_ALLOWED_VALUES:' + field.destinationField); continue; }
        const options: Record<string, unknown> = { ...translated.options, ...(field.semanticType === 'ENUM' && field.allowedValues !== undefined ? { allowedValues: [...field.allowedValues] } : {}) };
        fields.push({ column: { index }, destinationField: field.destinationField, semanticType: field.semanticType, ...(Object.keys(options).length > 0 ? { options } : {}) });
      }
      if (problems.length > 0 || object === null) return { ...bound, ok: false, rowsValidated: 0, reconciliationHolds: false, packageVerified: false, problems: problems.length > 0 ? problems : ['NO_FIELD_TRANSLATED'], evidence: { packageDigest: null, reportDigest: null, coreConfigHash: null } };
      const text = JSON.stringify({ configVersion: '2.0.0', source: { system: 'consumer', namespace: 'consumer' }, target: { mode: 'CLEAN_ONLY', importMode: 'CREATE_ONLY' }, files: [{ id: 'contacts', path: 'contacts.csv', format: 'CSV' }], records: [{ id: 'contacts', fileId: 'contacts', object, sourceRecordIdColumn: { header: 'Contact ID' }, fields }] });
      const candidate = loadConfig(text, join(work, 'candidate.json'));
      const runStore = createFilesystemScratchStore({ root: join(work, 'scratch-run'), runId: 'run', quotaBytes: SCRATCH_BUDGET_BYTES });
      const verifyStore = createFilesystemScratchStore({ root: join(work, 'scratch-verify'), runId: 'verify', quotaBytes: SCRATCH_BUDGET_BYTES });
      try {
        const result = runMigration({ inputRoot: work, config: candidate.config, configHash: candidate.configHash, scratch: runStore, sourceProfile: profile });
        const written = writePackage({ result, config: candidate.config, normalizedConfig: candidate.normalizedJson, outputDir: join(work, 'package'), force: true });
        const report = verifyPackage(written.stagingDir, { scratch: verifyStore });
        const holds = result.reconciliation.sourceRows.equationHolds;
        const found = [...(holds ? [] : ['RECONCILIATION_EQUATION_FAILED']), ...(report.passed ? [] : report.problems.map((problem) => problem.check))];
        return { ...bound, ok: found.length === 0, rowsValidated: result.reconciliation.sourceRows.total, reconciliationHolds: holds, packageVerified: report.passed, problems: found, evidence: { packageDigest: written.manifestSha256, reportDigest: digestOf({ passed: report.passed, checks: report.checks, problems: report.problems, artifactCount: report.artifactCount, sourceRows: report.sourceRows }), coreConfigHash: candidate.configHash } };
      } finally {
        runStore.dispose();
        verifyStore.dispose();
      }
    },
  };
  const core = createIntelligenceCore({ gateway: oracleGateway(), validationPort: port, ledgerStore: new MemoryLedgerStore(), clock });
  const input: IntelligenceInput = {
    projectRevision: { projectRevisionId: 'rev-1', projectRevisionHash: 'a'.repeat(64), mode: 'CLEAN_ONLY', supportEnvelopeVersion: '2.0.1', declaredObjects: { 'contacts.csv': 'CONTACT' } },
    sourceProfile: profile,
    candidateSet,
    targetContract: null,
    scopedMemorySnapshot: [],
    policyBundle: { modelPolicyVersion: MODEL_POLICY_VERSION, promptBundleVersion: PROMPT_BUNDLE_VERSION },
    resourceProfile: {},
  };
  const result: IntelligenceResult = await core.run(input, { tenant: { agencyId: 'a', clientId: 'c' }, actor: 'consumer-check', auditAttemptId: 'consumer-attempt-1' });
  const matrix = compatibilityMatrix();
  process.stdout.write(JSON.stringify({ version: INTELLIGENCE_CORE_VERSION, state: result.state, draft: result.draft.status, fields: result.draft.configuration?.fields.length ?? 0, rows: result.draft.fullValidation?.rowsValidated ?? 0, calls: result.resourceEvidence.modelCalls, invocations: result.resourceEvidence.providerInvocations, packageDigest: result.draft.fullValidation?.evidence.packageDigest ?? null, maxTasks: BUDGET_LIMITS.MAX_SEMANTIC_TASKS_PER_AUDIT, mcCore: matrix.vendoredMigrationCore.coreVersion, runDir: work }));
} finally {
  // By exact path, success or failure: nothing of this program outlives it.
  rmSync(work, { recursive: true, force: true });
}
`;

const report = { artifactKind: 'INTELLIGENCE_CORE_CONSUMER_CHECK', steps: [], ok: false, observed: null, problems: [] };
try {
  const packed = run('npm', ['pack', '--silent', '--pack-destination', work], { cwd: root });
  if (packed.status !== 0) throw new Error(`npm pack exited ${String(packed.status)}: ${packed.stderr}`);
  const tarball = readdirSync(work).find((name) => name.startsWith('kauro-intelligence-core-') && name.endsWith('.tgz'));
  if (tarball === undefined) throw new Error('npm pack produced no tarball');
  const project = join(work, 'project');
  mkdirSync(project, { recursive: true });
  writeFileSync(join(project, 'package.json'), JSON.stringify({ name: 'kauro-ic-consumer', private: true, type: 'module' }));
  writeFileSync(join(project, 'tsconfig.json'), JSON.stringify({ compilerOptions: { strict: true, target: 'ES2022', module: 'Node16', moduleResolution: 'Node16', types: ['node'], noEmitOnError: true, outDir: 'out', exactOptionalPropertyTypes: true, noUncheckedIndexedAccess: true, skipLibCheck: false }, files: ['consumer.ts'] }));
  writeFileSync(join(project, 'consumer.ts'), CONSUMER);
  // Both tarballs from bytes: the Intelligence Core just packed and the vendored Migration Core release.
  const installed = run('npm', ['install', '--silent', '--no-audit', '--no-fund', '--ignore-scripts', join(work, tarball), join(root, manifest.file)], { cwd: project });
  report.steps.push({ id: 'install', exit: installed.status });
  if (installed.status !== 0) throw new Error(`npm install exited ${String(installed.status)}: ${installed.stderr.slice(-400)}`);
  if (!existsSync(join(project, 'node_modules', 'kauro-intelligence-core', 'dist', 'src', 'index.d.ts'))) throw new Error('the packed core carries no dist/src/index.d.ts');
  const copyDir = (from, to) => run(process.platform === 'win32' ? 'robocopy' : 'cp', process.platform === 'win32' ? [from, to, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP'] : ['-r', from, to]);
  mkdirSync(join(project, 'node_modules', '@types'), { recursive: true });
  copyDir(join(root, 'node_modules', '@types', 'node'), join(project, 'node_modules', '@types', 'node'));
  if (existsSync(join(root, 'node_modules', 'undici-types'))) copyDir(join(root, 'node_modules', 'undici-types'), join(project, 'node_modules', 'undici-types'));
  const compiled = run(process.execPath, [join(root, 'node_modules', 'typescript', 'bin', 'tsc'), '--project', join(project, 'tsconfig.json')], { cwd: project });
  report.steps.push({ id: 'tsc', exit: compiled.status });
  if (compiled.status !== 0) throw new Error(`tsc exited ${String(compiled.status)}: ${(compiled.stdout || compiled.stderr).trim().split('\n').slice(0, 10).join('\n')}`);
  const ran = run(process.execPath, [join(project, 'out', 'consumer.js')], { cwd: project, env: { ...process.env, NODE_OPTIONS: '' } });
  report.steps.push({ id: 'run', exit: ran.status });
  if (ran.status !== 0) throw new Error(`the consumer exited ${String(ran.status)}: ${ran.stderr.trim().slice(0, 1200)}`);
  report.observed = JSON.parse(ran.stdout);
  if (report.observed.state !== 'PROPOSAL_READY' || report.observed.draft !== 'SYSTEM_DRAFT') report.problems.push(`the consumer run ended ${String(report.observed.state)} / ${String(report.observed.draft)}`);
  if (report.observed.rows !== 2) report.problems.push(`validated ${String(report.observed.rows)} rows, expected 2`);
  if (typeof report.observed.packageDigest !== 'string') report.problems.push('the receipt names no package digest');
  // The consumer owns its run directory and must have removed it; a directory left behind fails the check.
  if (typeof report.observed.runDir !== 'string' || !report.observed.runDir.includes('kauro-ic-consumer-run-')) report.problems.push('the consumer did not report a run directory of its own');
  else if (existsSync(report.observed.runDir)) report.problems.push(`the consumer left its run directory behind: ${report.observed.runDir}`);
  report.ok = report.problems.length === 0;
} catch (error) {
  report.problems.push(error instanceof Error ? error.message : String(error));
} finally {
  rmSync(work, { recursive: true, force: true });
}
process.stdout.write(`${report.ok ? 'INTELLIGENCE-CONSUMER-01 = PASS' : 'INTELLIGENCE-CONSUMER-01 = FALSE'}: ${JSON.stringify(report.observed)} ${report.problems.join('; ')}\n`);
process.exit(report.ok ? 0 : 1);
