# IC-2 readiness

What IC-1 hands to IC-2, what IC-2 must produce, and what stays FALSE until it
does. IC-1 spends zero paid inference; every model interaction here is a
scripted, replayed or oracle gateway behind the same `ModelGateway` interface
the real adapter will implement.

## Handed over by IC-1

| item | where | state |
| --- | --- | --- |
| kernel: adapter, resolver, planner, envelope builder, classifier, minimizer, egress, ledger, compiler, memory | `src/` | closed by INTELLIGENCE-ARCHITECTURE-01 |
| `ModelGateway` interface and the transport gateway shape (`buildProviderRequest`, `parseProviderResponse`) | `src/gateway/` | fixed; the provider adapter plugs in behind it |
| `MODEL_POLICY_V1` (claude-opus-5, US multi-region, effort HIGH, tools NONE, logging OFF, cache OFF, batch OFF, failover OFF) | `src/gateway/model-gateway.ts` | pinned; IC-2 must produce the IAM, endpoint and data-control evidence (§72) |
| `PROMPT_BUNDLE_V1` | same | versioned constant; hash exported |
| benchmark format, expected-truth sealing, scorer with hard gates | `src/benchmark/harness.ts` | closed; corpus absent |
| `FullDatasetValidationPort` contract and soundness rules | `src/ports/ports.ts`, `validationIsSound` | closed; the host implements it over its Migration Core |
| host DTO boundary (`IntelligenceInput` / `IntelligenceResult`) | `src/api/intelligence-core.ts` | closed; INTELLIGENCE-CONSUMER-01 proves it from the packed tarball |
| sabotage inventory (25 mutations) | `tools/sabotage.mjs` | all killed; IC-2 extends it for the provider adapter |

## IC-2 must produce

1. Provider adapter behind `ModelGateway` with the pinned policy; evidence for
   IAM, endpoint, region, logging OFF, no training, retention (§72).
2. Benchmark corpus: at least 600 distinct fixtures across the three modes with
   sealed expected truth (§82); three complete, independent OPUS-Q1 runs on the
   same sealed corpus and candidate (§84–§86). Qualification is by thresholds,
   not by equality of scores or of generated text: in every run the eight hard
   gates are zero and every gate was actually observed; ambiguous/abstention
   correctness ≥ 99% in every run; supported-recommendation correctness ≥ 97%
   in every run; the mean supported correctness of the three runs ≥ 98%. A hard
   failure invalidates its run and is never averaged away.
3. AI-BUDGET-01 measured against the real provider with the bounds of §61.
4. Extension of the sabotage inventory to the adapter (timeouts,
   AMBIGUOUS_BILLED against real ids, malformed provider payloads).
5. Threat-model rows T4, T16, T23–T26 measured, not only constructed.

## Flags

| flag | IC-1 | set TRUE by |
| --- | --- | --- |
| INTELLIGENCE_CORE_ARCHITECTURE_CLOSED | computed by `tools/architecture-gate.mjs` | this repository, from evidence |
| INTELLIGENCE_CORE_RELEASE_CANDIDATE | FALSE by construction | IC-2: OPUS-Q1 + AI-BUDGET-01 + provider evidence |
| INTELLIGENCE_CORE_V1_FROZEN | FALSE by construction | IC-3: independent freeze, red team, release provenance |

## Revision 009 (R-IC-PRIVACY) — what changed and what stays open

- Data policy 1.5.0 / masking policy 1.3.0 / core 0.4.0: the compact-token
  eligibility rule (`compactVerdict`) and scoped opaque references
  (`ReferenceScope`). Evidence recorded under the earlier policies is
  invalidated for classification and masking claims; the round-4 probe
  results are historical.
- Revision 009b — data policy 1.5.1 / core 0.4.1, after the independent
  review of 0.4.0 (PRIVACY-009-CASE-BYPASS, PRIVACY-009-LENGTH-BYPASS): a
  single-letter camel hump is no longer a symbol (`nG1`, `wU99`, `yN1` are
  handles), the compact token has no length cap and the handle rule is read
  before the metadata length rule (a 97-character handle is a handle, and
  the column carrying it is withheld). Classification evidence recorded
  under data policy 1.5.0 — the review's `camel-transport` and
  `length-transport` runs among them — describes another contract.
- WO-IC-PRIVACY-20260915-01 — data policy 1.6.0 / core 0.5.0, the
  consolidation of 009/009b (commit c8a5b1c, reused with its ancestry) and
  its independent qualification: the LABEL and IDENTIFIER channels no longer
  admit a token by its case (SMITH was structural, Smith a name) or by the
  shape of a join or the identifier grammar (Okonkwo, OkonkwoNdebele,
  Okonkwo__c). Work record: `docs/work/R_IC_PRIVACY_20260915_01.md` at commit
  d7b3d28 (blob 420b4dd3, sha256 49856823…8706), removed from the tree in
  0.4.0 (see `docs/work/RELEASE_0.4.0.md`).
- Privacy repair of B03 — data policy 1.7.0 / masking policy 1.4.0 / core
  0.3.0 (version unchanged, see the compatibility matrix): the retained
  candidate merged with its history, then the identifier case bypass, the
  suffixed-name availability failure, provider text in the record,
  cross-client agency memory and attempt-unscoped references repaired.
  Record `docs/work/PRIVACY_REPAIR_RECORD.md`, matrix
  `docs/work/PRIVACY_MODE_SURFACE_MATRIX.md`.
- Unresolved gates: provider qualification (IC-2), publication and
  distribution, live-provider egress evidence, full IC-05 option-label
  transport coverage (the adapter discards labels; only the classifier
  guard is tested), full architecture qualification and the
  `tools/consumer-check.mjs` installer conversion — none accepted here.

## Known limits carried forward

- The oracle gateway resolves by canonical field tail; it exists to exercise
  the pipeline end to end, not to stand in for a model's judgement.
- Classification is by shape; measured recall against real PII shapes is an
  IC-2 result.
- The consumer check runs against one CLEAN_ONLY fixture; vendor modes are
  covered by the integration suite with synthetic contracts, not by a packed
  consumer. The benchmark runner surface is on the same index (the package
  exports only `.`): `capturingTransport`, `isTransportBody`, `wireForms`,
  `observeEgress`, `scoreFixture`, `benchmarkReport`, `qualifyThreeRuns`,
  `reportDigestOf`, `REPORT_MODES`, `QUALIFICATION_CORPUS`, `corpusShortfall`
  and their types; `test/benchmark-surface.test` proves each is the harness
  object, not a copy. An IC-2 runner imports them from the tarball and
  reimplements none of the capture.

## Carried forward by the IC-1 correction (2026-09-11)

What the repair of audit findings F01–F07 leaves for IC-2 to decide or
measure against the real provider and the sealed corpus:

- **Request shape acceptance.** The request sends exactly six top-level
  members: `model` (the pinned id), `max_tokens` (the bundle ceiling, 8192,
  or the smaller ask), `system` (the bundle sentences for the task),
  `messages` (one user message: the `<request>` identity block, the `<data>`
  block and the bundle's closing instruction), `output_config` (`format`
  json_schema with the bundle schema, `effort: 'high'`) and `tools: []`.
  It sends no `temperature` (the pinned model accepts only its default
  sampling; a value would be rejected or ignored, and either is a request
  nobody recorded) and no `metadata` (the Messages metadata object defines
  only `user_id`, an opaque end-user id this core has no end user for); the
  ledger correlation reaches the transport beside the request, as
  `TransportCorrelation`, never inside the provider object. Every sentence,
  tag and parameter around the envelope is a member of `PROMPT_BUNDLE_V1`
  (1.1.0), so the bundle hash covers the bytes a model reads and the payload
  parser refuses a request whose text, schema, ceiling or member set is not
  the bundle's. What remains for the first real smoke: that the endpoint
  accepts `output_config.format` json_schema with this schema and
  `output_config.effort` for the pinned model, that the default temperature
  answers the frozen corpus deterministically enough for the benchmark, and
  the actual input/output token cost of the bundle against the eight budget
  bounds; any change to the bytes is a prompt-bundle version bump (the bundle
  hash is part of run identity).
- **Typed non-billing evidence.** HTTP 429/5xx are kept ambiguous at full
  reservation size because the transport has no proof they were not billed.
  IC-2 may add provider evidence that turns specific statuses into typed
  `neverSent`/not-billed proofs; the kernel already consumes the field.
- **Classifier recall and precision.** Names are detected by a compact list
  plus proper-noun shape; headers by a positive vocabulary. Precision costs
  (masked harmless headers) and recall gaps are measured on the corpus;
  neither is tuned by looking at candidate outputs.
- **Lease between live workers.** The kernel recovers a crashed worker and
  bounds a concurrent duplicate; it does not arbitrate two live workers on one
  attempt. The IC-2 host/queue design must deliver one attempt to one worker.
- **Egress evidence for the scorer.** `observeEgress` must be fed the bytes
  captured at the transport boundary (`buildProviderRequest` output), not the
  envelope object, for the secret-egress gate to be evidence of egress.
- **Campaign record.** Every `BenchmarkReport` carries `reportDigest`, the
  digest of its other members (the scores' digest and the mode among them);
  `qualifyThreeRuns` recomputes it and refuses a report that does not match
  before it reads a field. The IC-2 campaign record pins the three digests.
  A correct score without a run id is a report failure; the scorer emits a
  null run id only for a missing result, which is incorrect. A tampered
  configuration under a stale receipt is a scorer failure (`correct: null`,
  never a pass), not `correct: false`; and `allowedExtraDestinations` is a
  destination allowance, not a (source, destination) pair — corpus authors
  enumerate expected candidates rather than allow extras.
- **Weighting.** Thresholds use fixture counts; weighted rates are reported
  only. Confirm the weighting rule before sealing the 600-fixture corpus.
- **Store implementation.** A database or file `LedgerStore` must implement
  compare-and-append under a lock or a unique `(runId, sequence)`; the
  in-process store proves the contract, not a deployment.
