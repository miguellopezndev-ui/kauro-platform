# Compatibility matrix

Every version is declared on its own line in `src/contracts/versions.ts` and
exported through `compatibilityMatrix()`. A combination that is not in this
table fails closed with `INCOMPATIBLE_CONTRACT_VERSION`; nothing negotiates.
`tools/contracts-check.mjs` (CONTRACTS-01) refuses a tree whose declared ranges
do not contain what the vendored Migration Core actually exports.

## Intelligence Core 0.4.0

| contract | version | where | changes |
| --- | --- | --- | --- |
| INTELLIGENCE_CORE_VERSION | 0.4.0 | package.json, package-lock.json, versions.ts | 0.4.0 (amendment A2): the package is `kauro-intelligence-core`; no shape or behaviour change beyond prompt bundle 1.1.1; Migration Core stays 2.0.1 until its renamed release is published (`docs/work/RELEASE_0.4.0.md`). Earlier: the privacy repair of B03 kept the package at 0.3.0: the retained candidate's 0.4.x/0.5.0 were never released; the behaviour moved with data policy 1.7.0 and masking policy 1.4.0, both bound into the run identity and the provenance. History: 0.5.0 (WO-IC-PRIVACY-20260915-01, the consolidation of 009/009b): no shape change — data policy 1.6.0 stops the LABEL and IDENTIFIER channels admitting a token by its case or by the shape of a join; 0.4.1 (revision 009b, after the independent review of 0.4.0): no shape change — data policy 1.5.1 closes the camel-hump and length bypasses of the compact rule; 0.4.0 (revision 009, R-IC-PRIVACY): `BuildEnvelopeInput.tenant` is required (opaque references are scoped), `IntelligenceResult.provenance` carries `dataPolicyVersion` and `maskingPolicyVersion`, the run identity binds both; 0.2.0: host DTOs (`HostContext.auditAttemptId`, `LedgerStore.append(…, expectedLength)`, validation receipt fields, `resourceEvidence` counters, provider request shape); 0.3.0: fenced and renewed lease (`CoreDependencies.ticker`, `LEDGER_FENCED`), `ProjectRevision.recordIdColumns`, `ConfigFragmentField.allowedValues`, `BenchmarkReport.reportDigest`, identity binds resource profile and summaries; round 4b (additive, same version): `DraftMigrationPlan.evidence[]` entries carry `origin` (`DETERMINISTIC` / `PROPOSED`, exported type `DraftEvidence`) |
| IntelligenceEnvelopeV1 | 1.0.0 | `src/contracts/envelope.ts` | unchanged shape; metadata channels may carry masked tokens |
| IntelligenceProposalV1 | 1.0.0 | `src/contracts/proposal.ts` | unchanged |
| prompt bundle | 1.1.1 | `PROMPT_BUNDLE_V1` | 1.1.1: the role sentence names Kauro Intelligence Core (amendment A2), nothing else changed. 1.1.0: the bundle carries the whole request template (system sentences, <request> block, closing instruction, output_config, max_tokens); no temperature, no metadata on the wire |
| model policy | 1.0.0 | `MODEL_POLICY_V1` | unchanged |
| memory contract | 1.0.0 | `src/memory/memory-resolver.ts` | unchanged |
| compiler contract | 1.0.0 | `src/compiler/compiler.ts` | `CompiledItem.evidenceRefs` added (additive) |
| benchmark format | 1.1.0 | `src/benchmark/fixture.ts`, `report.ts`, `harness.ts` | expected decisions, input-hash binding, observed hard gates, three-run qualification |
| run ledger | 1.2.0 | `src/kernel/ledger.ts` | attempt identity, compare-and-append store, per-invocation reservations, `usageKnown`, semantic request key (budget excluded), lease owned per invocation with `ownerId`, renewed during provider and validation calls, every write fenced (`LEDGER_FENCED`), ceiling check after every commit, identity binds resource profile and categorical summaries; round 4b (event order, no shape change): `RESULT` precedes the closing `STATE`, `RESPONSE_STORED` precedes `COMMITTED`, a `RESULT` under an open state or a `CANCELLED` without its `STATE` is closed by the next delivery |
| masking policy / data policy | 1.4.0 / 1.7.0 | `src/envelope/envelope-builder.ts`, `src/classifier/data-classifier.ts` | 1.7.0 / 1.4.0 (privacy repair of B03): no identifier piece admitted by its case, only by the vocabulary or a lower-case concatenation of vocabulary words; joined and suffixed names are personal values, not UNKNOWN; a value its target lists as a person is one; the attempt is in the reference key. 1.6.0 (WO-IC-PRIVACY-20260915-01): on LABEL and IDENTIFIER no shape admits a token on its own — not an acronym of two to six capitals (SMITH, LEE), not a snake/kebab/dotted/camel/Pascal join (OkonkwoNdebele, Okonkwo_Ndebele), not the vendor suffix (Okonkwo__c, on OPTION too), not the identifier grammar (Okonkwo); a piece is known by the closed lists, as a lower-case word on IDENTIFIER only, or as a word in capitals inside a compound constant; a title-case piece outside every vocabulary is POTENTIAL_PII, a bare word in capitals outside every list is UNKNOWN; an ordinal (2nd) is a code; opaque references (`hdr_…`) are structural on the label channels; mundane acronym, type and grammar words added to the label vocabulary. 1.5.1 (revision 009b): a hump of one letter inside a camel run is not a symbol (`nG1`, `wU99`, `yN1` are handles); the compact token has no length cap and the handle rule precedes the metadata length rule (a 97-character handle is POTENTIAL_PII on every channel, never FREE_TEXT). 1.5.0: a digit-bearing token is a code only when every letter run is known (single Latin letter, closed compact prefix, vocabulary word) and a handle otherwise — POTENTIAL_PII on OPTION, LABEL, IDENTIFIER and `classifyValue`, never UNKNOWN by omission; capitals, digit dominance, two-to-three-capital prefixes and attested option lists authorise nothing; a bare ISO code with digits after it is not a code. 1.3.0: mask tokens are keyed by the egress secret bound to agency, client, project revision (id and hash) and profile hash; equal text in equal scope shares a token, any change separates it. Earlier: metadata classified and masked with keyed tokens; whole-column classification before selection; options never widen what may travel; egress re-reads exemplar values |

## Migration Core accepted by this version

| Migration Core contract | accepted | vendored (read from the package) |
| --- | --- | --- |
| CORE_VERSION | 2.0.1 | 2.0.1 |
| PACKAGE_FORMAT_VERSION | 2.0.0 | 2.0.0 |
| CONFIG_SCHEMA_VERSION | 2.0.0 | 2.0.0 |
| SOURCE_PROFILE_VERSION | 1.0.0 | 1.0.0 |
| CANDIDATE_SET_VERSION | 1.0.0 | 1.0.0 |
| TARGET_CONTRACT_VERSION | 1.0.0 | 1.0.0 |
| IDENTITY_RULE_VERSION | 1.0.0 | 1.0.0 |

The vendored release: `miguellopezndev-ui/kauro-migration-core` at
`a2a549031de85d95be8645dd9c5156dfff2050a0`, tag `v2.0.1`, release 387057468
(immutable), package file as named in `vendor/MANIFEST.json`, sha256
`787f0b80a906d31605e3946ad00df86d2a131e3e89d78855c1c4f327b37fa000`
(`vendor/MANIFEST.json`). It is declared as a **peer dependency** pinned to
`2.0.1`: the host supplies the same release it runs its own engine with, and
the consumer check installs both tarballs from bytes to prove the pair works
with no registry. A validation receipt whose `coreVersion` is outside the
accepted set blocks the draft (`VALIDATION_CORE_VERSION_UNSUPPORTED`).

## Rules

- A new Intelligence Core version that changes the envelope or proposal shape
  bumps that contract's version and this matrix; the old row stays readable.
- A new Migration Core release is accepted by adding its versions here, running
  CONTRACTS-01, and re-vendoring; never by widening a range to `^`.
- Runtime: the host passes the `sourceProfile`, `candidateSet` and
  `targetContract` objects the Migration Core produced; the adapter checks their
  declared versions against the accepted set before anything else reads them.
- A run's identity binds the versions above (core, envelope, proposal, prompt
  bundle and model policy with their hashes, and since 0.4.0 the data policy
  and the masking policy): the same `auditAttemptId` redelivered against other
  versions is `IDENTITY_CONFLICT`, never a silent re-run. The result's
  `provenance` names the same two policy versions.
- Evidence invalidation (revision 009): every classification or masking
  observation recorded under data policy ≤ 1.4.0 or masking policy ≤ 1.2.0 —
  the round-4 privacy probes and the 13 September audit records among them —
  describes another contract and is history, not evidence for 0.4.0.
- Evidence invalidation (revision 009b): every classification observation
  recorded under data policy 1.5.0 — the independent review's
  `camel-transport` and `length-transport` runs on 0.4.0 among them —
  describes another contract and is history, not evidence for 0.4.1.
- Evidence invalidation (WO-IC-PRIVACY-20260915-01): every LABEL, IDENTIFIER or
  OPTION classification observation recorded under data policy ≤ 1.5.1 — the
  009/009b replays and the sealed-check stand-ins on c8a5b1c among them —
  describes another contract and is history, not evidence for 0.5.0. Value
  classification (`classifyValue`) and masking (1.3.0) did not change; their
  1.5.1 observations still describe the same rules but were re-run here.
- Evidence invalidation (privacy repair of B03): every classification or
  masking observation recorded under data policy ≤ 1.6.0 or masking policy
  ≤ 1.3.0 — the retained candidate d7b3d28 and its sealed-check replays among
  them — describes another contract and is history. Current evidence:
  `docs/work/PRIVACY_REPAIR_RECORD.md`.
