/**
 * Test fixtures: small synthetic bundles profiled by the frozen Migration
 * Core, target contracts the test constructs and attests, and a host
 * validation adapter that applies a candidate configuration to the whole
 * fixture with the real engine. The core under test never sees a path.
 */
import { generateKeyPairSync, sign as signBytes } from 'node:crypto';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

import {
  ATTESTATION_ALGORITHM,
  CANONICAL_OBJECTS,
  ATTESTATION_CONTRACT_VERSION,
  SCRATCH_BUDGET_BYTES,
  attestationSigningBytes,
  buildCandidateSet,
  createFilesystemScratchStore,
  hashTargetContract,
  loadConfig,
  produceSourceProfile,
  runMigration,
  verifyPackage,
  writePackage,
} from 'kavo-migration-core';
import type { AttestationAuthority, HashedCandidateSet, HashedSourceProfile, HashedTargetContract, TargetAttestation, TargetContract, TargetMode } from 'kavo-migration-core';

import { digestOf } from '../../src/contracts/canonical.js';
import { MemoryLedgerStore, SystemClock, VirtualClock } from '../../src/kernel/ledger.js';
import type { Clock } from '../../src/kernel/ledger.js';
import type { CandidateConfiguration, ConfigFragmentField, CoreDependencies, FullDatasetValidationPort, FullDatasetValidationResult, HostContext, IntelligenceInput } from '../../src/ports/ports.js';
import type { ModelGateway } from '../../src/gateway/model-gateway.js';
import { MODEL_POLICY_VERSION, PROMPT_BUNDLE_VERSION } from '../../src/contracts/versions.js';

export interface Bundle {
  readonly root: string;
  readonly files: readonly { id: string; path: string; idHeader: string; object: string }[];
  readonly dispose: () => void;
}

const DEFAULT_CONTACTS = 'Contact ID,First Name,Last Name,Email,Phone,Status\n1,Ada,Lovelace,ada@kauro-fixture.test,+57 300 123 4567,Active\n2,Grace,Hopper,grace@kauro-fixture.test,,Inactive\n3,Alan,Turing,alan@kauro-fixture.test,+1 415 555 0100,Active\n4,Alan,Turing,ALAN@kauro-fixture.test,,Active\n';
const DEFAULT_COMPANIES = 'Company ID,Name,Website\nC1,Analytical Engines,https://analytical.test\nC2,COBOL Works,https://cobol.test\n';

export function makeBundle(name: string, options: { contacts?: string; companies?: string; extraColumns?: number; extraRows?: number } = {}): Bundle {
  const root = resolve(join(tmpdir(), `kauro-ic-${name}-${String(process.pid)}-${String(Date.now())}`));
  mkdirSync(root, { recursive: true });
  let contacts = options.contacts ?? DEFAULT_CONTACTS;
  if (options.extraColumns !== undefined && options.extraColumns > 0) {
    const lines = contacts.trimEnd().split('\n');
    const header = lines[0] as string;
    const extraHeaders = Array.from({ length: options.extraColumns }, (unused, index) => `Mystery ${String(index + 1)}`);
    contacts = `${[header, ...extraHeaders].join(',')}\n${lines
      .slice(1)
      .map((line, row) => [line, ...extraHeaders.map((unused, index) => `x${String(index)}-${String(row)}`)].join(','))
      .join('\n')}\n`;
  }
  if (options.extraRows !== undefined && options.extraRows > 0) {
    const lines = contacts.trimEnd().split('\n');
    const header = lines[0] as string;
    const columns = header.split(',').length;
    const extra = Array.from({ length: options.extraRows }, (unused, index) => [String(100 + index), `Name${String(index)}`, 'Row', `row${String(index)}@kauro-fixture.test`, '', index % 2 === 0 ? 'Active' : 'Inactive', ...Array.from({ length: Math.max(0, columns - 6) }, () => 'v')].slice(0, columns).join(','));
    contacts = `${[...lines, ...extra].join('\n')}\n`;
  }
  writeFileSync(join(root, 'contacts.csv'), contacts);
  writeFileSync(join(root, 'companies.csv'), options.companies ?? DEFAULT_COMPANIES);
  return {
    root,
    files: [
      { id: 'contacts', path: 'contacts.csv', idHeader: 'Contact ID', object: 'CONTACT' },
      { id: 'companies', path: 'companies.csv', idHeader: 'Company ID', object: 'COMPANY' },
    ],
    dispose: () => rmSync(root, { recursive: true, force: true }),
  };
}

/** The read configuration the profile is produced under: files only, no field mappings yet. */
export function profileConfig(bundle: Bundle, mode: TargetMode): string {
  return JSON.stringify({
    configVersion: '2.0.0',
    source: { system: 'fixture', namespace: `fixture-${mode.toLowerCase()}` },
    target: { mode, importMode: 'CREATE_ONLY' },
    files: bundle.files.map((file) => ({ id: file.id, path: file.path, format: 'CSV' })),
    records: bundle.files.map((file) => ({
      id: file.id,
      fileId: file.id,
      object: file.object,
      sourceRecordIdColumn: { header: file.idHeader },
      fields: file.object === 'CONTACT' ? [{ column: { header: 'Email' }, destinationField: 'contact.email', semanticType: 'EMAIL' }] : [{ column: { header: 'Name' }, destinationField: 'company.name', semanticType: 'TEXT' }],
    })),
  });
}

export function profileBundle(bundle: Bundle, mode: TargetMode): { profile: HashedSourceProfile; candidateSet: HashedCandidateSet; configHash: string } {
  const text = profileConfig(bundle, mode);
  const loaded = loadConfig(text, join(bundle.root, 'profile-config.json'));
  const scratch = createFilesystemScratchStore({ root: join(bundle.root, 'scratch-profile'), runId: 'profile', quotaBytes: SCRATCH_BUDGET_BYTES });
  try {
    const profile = produceSourceProfile({ inputRoot: bundle.root, config: loaded.config, scratch });
    const candidateSet = buildCandidateSet({ profile, configHash: loaded.configHash });
    return { profile, candidateSet, configHash: loaded.configHash };
  } finally {
    scratch.dispose();
  }
}

const issuer = generateKeyPairSync('ed25519');
export const AUTHORITY: AttestationAuthority = {
  issuerId: 'fixture:issuer',
  keyId: 'k1',
  algorithm: ATTESTATION_ALGORITHM,
  publicKeyPem: issuer.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
};

const field = (apiName: string, label: string, type: string, extra: Partial<TargetContract['objects'][number]['fields'][number]> = {}): TargetContract['objects'][number]['fields'][number] => ({
  apiName,
  label,
  type,
  createable: 'TRUE',
  updateable: 'TRUE',
  nillable: 'TRUE',
  length: 255,
  precision: null,
  scale: null,
  unique: 'FALSE',
  externalId: 'FALSE',
  idLookup: 'FALSE',
  calculated: 'FALSE',
  autoNumber: 'FALSE',
  defaultedOnCreate: 'FALSE',
  restrictedPicklist: 'FALSE',
  picklistValues: [],
  referenceTo: [],
  relationshipName: null,
  evidence: 'ARTIFACT',
  ...extra,
});

export function vendorContract(mode: 'HUBSPOT' | 'SALESFORCE', options: { withStatusPicklist?: boolean; readOnlyEmail?: boolean } = {}): HashedTargetContract {
  const hs = mode === 'HUBSPOT';
  return hashTargetContract({
    contractVersion: '1.0.0',
    parserVersion: '1.0.0',
    capturedAt: '2026-09-01T00:00:00Z',
    instance: { mode, instanceId: hs ? '00000001' : '00D000000000001', instanceLabel: `fixture ${mode}`, evidence: 'ARTIFACT' },
    artifacts: [{ path: 'export/schema.json', sha256: 'a'.repeat(64), byteLength: 4096, kind: 'DESCRIBE' }],
    objects: [
      {
        apiName: hs ? 'contact' : 'Contact',
        label: 'Contact',
        createable: 'TRUE',
        updateable: 'TRUE',
        recordTypes: [],
        fields: [
          field(hs ? 'email' : 'Email', 'Email', hs ? 'string' : 'email', { unique: 'TRUE', idLookup: 'TRUE', ...(options.readOnlyEmail ? { createable: 'FALSE', updateable: 'FALSE' } : {}) }),
          field(hs ? 'firstname' : 'FirstName', 'First Name', 'string'),
          field(hs ? 'lastname' : 'LastName', 'Last Name', 'string'),
          field(hs ? 'phone' : 'Phone', 'Phone', hs ? 'string' : 'phone'),
          ...(options.withStatusPicklist ? [field(hs ? 'lifecyclestage' : 'Title', 'Lifecycle Stage', hs ? 'enumeration' : 'string', hs ? { picklistValues: [{ value: 'lead', label: 'Lead', active: true, defaultValue: false }, { value: 'OPEN', label: 'Open', active: true, defaultValue: false }] } : {})] : []),
          field(hs ? 'internal_score' : 'Internal_Score__c', 'Internal Score', 'number'),
        ],
      },
      {
        apiName: hs ? 'company' : 'Account',
        label: 'Company',
        createable: 'TRUE',
        updateable: 'TRUE',
        recordTypes: [],
        fields: [field(hs ? 'name' : 'Name', 'Name', 'string'), field(hs ? 'website' : 'Website', 'Website', 'string')],
      },
    ],
    pipelines: [],
  });
}

export function attestationFor(contract: HashedTargetContract, overrides: Partial<Omit<TargetAttestation, 'signature'>> = {}): TargetAttestation {
  const body: Omit<TargetAttestation, 'signature'> = {
    attestationVersion: ATTESTATION_CONTRACT_VERSION,
    issuer: { id: 'fixture:issuer', name: 'Fixture Issuer', keyId: 'k1' },
    subject: { mode: contract.contract.instance.mode, instanceId: contract.contract.instance.instanceId, instanceLabel: contract.contract.instance.instanceLabel },
    artifacts: [{ path: 'export/schema.json', sha256: 'a'.repeat(64), byteLength: 4096 }],
    contractHash: contract.contractHash,
    schemaVersion: '1.0.0',
    toolVersion: 'fixture/1.0.0',
    capturedAt: '2026-09-01T00:00:00Z',
    expiresAt: '2026-12-01T00:00:00Z',
    nonce: null,
    ...overrides,
  };
  const candidate: TargetAttestation = { ...body, signature: { algorithm: ATTESTATION_ALGORITHM, value: '' } };
  const value = signBytes(null, Buffer.from(attestationSigningBytes(candidate), 'utf8'), issuer.privateKey).toString('base64');
  return { ...body, signature: { algorithm: ATTESTATION_ALGORITHM, value } };
}

/**
 * How one authorised fragment element becomes Migration Core's field options,
 * or why the frozen configuration schema cannot express it. Every primitive
 * of the proposal catalogue is named here: a primitive that has no
 * representation is reported as UNSUPPORTED_BY_CORE:<primitive>, never
 * dropped on the way into the engine. The rules are read off the vendored
 * schema (mapping/config-schema, load-config OPTION_APPLICABILITY), which
 * is the authority; nothing here changes what the engine does.
 */
export function translatePrimitive(field: ConfigFragmentField): { readonly options: Record<string, unknown> } | { readonly problem: string } {
  const params = field.typedTransformParams ?? {};
  const unsupported = (why: string): { readonly problem: string } => ({ problem: `UNSUPPORTED_BY_CORE:${String(field.transformPrimitive)}:${why}` });
  switch (field.transformPrimitive) {
    case null:
    case 'PRESERVE_AS_IS':
      return { options: {} };
    case 'TRIM_WHITESPACE':
      return { options: { trim: true } };
    case 'NORMALISE_EMAIL_CASE':
      // The engine lowercases the domain and never the local part; that is the whole of what this primitive may mean.
      return field.semanticType === 'EMAIL' ? { options: { lowercaseDomain: true } } : unsupported('only for EMAIL');
    case 'PARSE_PHONE_E164':
      return field.semanticType === 'PHONE' && /^[A-Z]{2}$/u.test(params['defaultRegion'] ?? '') ? { options: { phoneCountry: params['defaultRegion'] } } : unsupported('needs PHONE and defaultRegion');
    case 'NORMALISE_NUMBER':
      return field.semanticType === 'NUMBER' && /^[.,]$/u.test(params['decimalSeparator'] ?? '') ? { options: { decimalSeparator: params['decimalSeparator'], thousandsSeparator: 'NONE' } } : unsupported('needs NUMBER and decimalSeparator');
    case 'NORMALISE_BOOLEAN':
      return field.semanticType === 'BOOLEAN' ? { options: {} } : unsupported('only for BOOLEAN');
    case 'PARSE_DATE_ISO':
      // dayFirst does not name the separator; the schema wants one of its DATE_FORMATS.
      return unsupported('dayFirst names no DATE_FORMAT of the schema');
    case 'MAP_ENUM_VALUE':
      // A value map on an ENUM: the pair the compiler admitted (`to` is a target option) becomes one valueMap entry; the options themselves travel below as allowedValues.
      return field.semanticType === 'ENUM' && field.allowedValues !== undefined && (params['from'] ?? '') !== '' && field.allowedValues.includes(params['to'] ?? '') ? { options: { valueMap: [{ from: params['from'], to: params['to'] }] } } : unsupported('an ENUM value map needs allowedValues and a `to` among them');
    case 'CLEAR_VALUE':
      return unsupported('clearing needs destructiveAuthorization the agency never gave');
    default:
      return unsupported('unknown primitive');
  }
}

/** A Migration Core column ref from the profile's locator: the physical index the profile recorded, checked against the header the fragment names. */
function columnRefFor(profile: HashedSourceProfile, field: ConfigFragmentField): { readonly column: { index: number } } | { readonly problem: string } {
  for (const file of profile.profile.files) {
    // The fragment names the file by the id the profile minted for it and by the path it profiled; both must agree.
    if (file.fileId !== field.fileId || file.path !== field.filePath) continue;
    for (const sheet of file.sheets) {
      const column = sheet.columns.find((entry) => entry.columnLocatorId === field.columnLocator);
      if (column === undefined) continue;
      if ((column.headerRaw ?? '') !== field.columnHeader) return { problem: `COLUMN_LOCATOR_HEADER_MISMATCH:${field.columnLocator}` };
      return { column: { index: column.columnIndex } };
    }
  }
  return { problem: `COLUMN_LOCATOR_UNKNOWN:${field.columnLocator}` };
}

export interface PortTranslation {
  readonly records: readonly Record<string, unknown>[];
  readonly problems: readonly string[];
}

/**
 * The whole authorised fragment into Migration Core's configuration: one
 * record per profiled file with the object the candidate assigns it and the
 * file's identity column, and every field with its column by index,
 * destination, semantic type and the options its primitive translates to.
 * Anything that cannot be expressed is a problem the receipt carries, and a
 * configuration with a problem is not run at all.
 */
export function translateConfiguration(bundle: Bundle, profile: HashedSourceProfile, configuration: CandidateConfiguration): PortTranslation {
  const problems: string[] = [];
  const byFile = new Map<string, { object: string; fields: Record<string, unknown>[] }>();
  for (const item of configuration.fields) {
    const file = bundle.files.find((entry) => entry.path === item.filePath);
    if (file === undefined) {
      problems.push(`FILE_UNKNOWN:${item.fileId}`);
      continue;
    }
    if (!CANONICAL_OBJECTS.includes(item.object as (typeof CANONICAL_OBJECTS)[number]) || !item.destinationField.startsWith(`${item.object.toLowerCase()}.`)) {
      problems.push(`OBJECT_MISMATCH:${item.destinationField}`);
      continue;
    }
    // One file is one object in a record mapping; a candidate that splits a file across two is not expressible as one run.
    const record = byFile.get(file.id) ?? { object: item.object, fields: [] };
    if (record.object !== item.object) {
      problems.push(`MULTIPLE_OBJECTS_FOR_FILE:${item.filePath}`);
      continue;
    }
    const column = columnRefFor(profile, item);
    if ('problem' in column) {
      problems.push(column.problem);
      continue;
    }
    const translated = translatePrimitive(item);
    if ('problem' in translated) {
      problems.push(translated.problem);
      continue;
    }
    // An ENUM destination carries the contract's options as the frozen schema's allowedValues; an ENUM without them is refused by the engine, never accepted silently.
    if (item.semanticType === 'ENUM' && (item.allowedValues === undefined || item.allowedValues.length === 0)) {
      problems.push(`ENUM_WITHOUT_ALLOWED_VALUES:${item.destinationField}`);
      continue;
    }
    const options = { ...translated.options, ...(item.semanticType === 'ENUM' && item.allowedValues !== undefined ? { allowedValues: [...item.allowedValues] } : {}) };
    record.fields.push({ column: column.column, destinationField: item.destinationField, semanticType: item.semanticType, ...(Object.keys(options).length > 0 ? { options } : {}) });
    byFile.set(file.id, record);
  }
  const records = bundle.files.filter((file) => byFile.has(file.id)).map((file) => ({ id: file.id, fileId: file.id, object: byFile.get(file.id)?.object ?? file.object, sourceRecordIdColumn: { header: file.idHeader }, fields: byFile.get(file.id)?.fields ?? [] }));
  return { records, problems };
}

export interface FixtureValidationPort extends FullDatasetValidationPort {
  calls: number;
  lastPackage: { stagingDir: string; artifacts: readonly { path: string }[] } | null;
  /**
   * The clock the receipts are dated by. A host shares one clock discipline
   * with the core it calls, so the port made without one is bound to the
   * run's clock by `depsFor`; a port used on its own dates by the system.
   */
  clock: Clock | null;
}

/**
 * The host's validation adapter: the candidate configuration becomes a
 * MigrationConfig, the frozen engine runs it over the whole fixture bundle,
 * the package is written and verified, and the result is typed and bound to
 * the hashes it validated against, the exact configuration bytes it
 * received, and the digests of what the engine produced. The core never
 * sees the bundle.
 */
export function realValidationPort(bundle: Bundle, profile: HashedSourceProfile, contract: HashedTargetContract | null, options: { readonly clock?: Clock } = {}): FixtureValidationPort {
  const port: FixtureValidationPort = {
    calls: 0,
    lastPackage: null,
    clock: options.clock ?? null,
    async validate(configuration: CandidateConfiguration): Promise<FullDatasetValidationResult> {
      port.calls += 1;
      const clock = port.clock ?? new SystemClock();
      const bound = { configurationRef: configuration.configurationRef, configurationDigest: digestOf(configuration), profileHash: profile.profileHash, candidateSetHash: configuration.candidateSetHash, targetContractHash: contract?.contractHash ?? null, rowsInProfile: profile.profile.totals.dataRowCount, validatedAt: clock.now(), coreVersion: '2.0.1' };
      const translation = translateConfiguration(bundle, profile, configuration);
      if (translation.problems.length > 0) {
        // Nothing ran: a configuration the engine cannot take as authorised is refused whole.
        return { ...bound, ok: false, rowsValidated: 0, reconciliationHolds: false, packageVerified: false, problems: translation.problems, evidence: { packageDigest: null, reportDigest: null, coreConfigHash: null } };
      }
      const text = JSON.stringify({ configVersion: '2.0.0', source: { system: 'fixture', namespace: `fixture-${configuration.mode.toLowerCase()}` }, target: { mode: configuration.mode, importMode: 'CREATE_ONLY' }, files: bundle.files.map((file) => ({ id: file.id, path: file.path, format: 'CSV' })), records: translation.records });
      const loaded = loadConfig(text, join(bundle.root, 'candidate-config.json'));
      const runStore = createFilesystemScratchStore({ root: join(bundle.root, `scratch-run-${String(port.calls)}`), runId: `run${String(port.calls)}`, quotaBytes: SCRATCH_BUDGET_BYTES });
      const verifyStore = createFilesystemScratchStore({ root: join(bundle.root, `scratch-verify-${String(port.calls)}`), runId: `verify${String(port.calls)}`, quotaBytes: SCRATCH_BUDGET_BYTES });
      try {
        const result = runMigration({
          inputRoot: bundle.root,
          config: loaded.config,
          configHash: loaded.configHash,
          scratch: runStore,
          sourceProfile: profile,
          ...(contract === null ? {} : { targetContract: contract, targetAttestation: attestationFor(contract), attestationAuthorities: [AUTHORITY], attestationInstant: '2026-09-15T00:00:00Z' }),
        });
        const written = writePackage({ result, config: loaded.config, normalizedConfig: loaded.normalizedJson, outputDir: join(bundle.root, `package-${String(port.calls)}`), force: true });
        const report = verifyPackage(written.stagingDir, { scratch: verifyStore });
        port.lastPackage = { stagingDir: written.stagingDir, artifacts: written.artifacts };
        const holds = result.reconciliation.sourceRows.equationHolds;
        const problems = [...(holds ? [] : ['RECONCILIATION_EQUATION_FAILED']), ...(report.passed ? [] : report.problems.map((problem) => problem.check))];
        return {
          ...bound,
          ok: problems.length === 0,
          rowsValidated: result.reconciliation.sourceRows.total,
          reconciliationHolds: holds,
          packageVerified: report.passed,
          problems,
          evidence: { packageDigest: written.manifestSha256, reportDigest: digestOf({ passed: report.passed, checks: report.checks, problems: report.problems, artifactCount: report.artifactCount, sourceRows: report.sourceRows }), coreConfigHash: loaded.configHash },
        };
      } finally {
        runStore.dispose();
        verifyStore.dispose();
      }
    },
  };
  return port;
}

export const CONTEXT: HostContext = { tenant: { agencyId: 'agency-a', clientId: 'client-1' }, actor: 'test', auditAttemptId: 'attempt-0001' };

export function inputFor(mode: TargetMode, profiled: { profile: HashedSourceProfile; candidateSet: HashedCandidateSet }, contract: HashedTargetContract | null, extra: Partial<IntelligenceInput> = {}): IntelligenceInput {
  return {
    projectRevision: { projectRevisionId: 'rev-1', projectRevisionHash: digestOf(['rev-1', profiled.profile.profileHash]), mode, supportEnvelopeVersion: '2.0.1' },
    sourceProfile: profiled.profile,
    candidateSet: profiled.candidateSet,
    targetContract: contract,
    scopedMemorySnapshot: [],
    policyBundle: { modelPolicyVersion: MODEL_POLICY_VERSION, promptBundleVersion: PROMPT_BUNDLE_VERSION },
    resourceProfile: {},
    ...extra,
  };
}

/** The core's lease-renewal timer, fired by hand: `tick()` runs every tick the core has registered and not yet stopped; `advance(ms)` moves the virtual clock in renewal-sized steps, ticking after each, as a live worker's timer would while it waits. */
export interface ManualTicker {
  readonly ticker: NonNullable<CoreDependencies['ticker']>;
  tick(): void;
  advance(ms: number): void;
  /** How many ticks the core registered (one per long await it kept the lease through). */
  readonly registered: number;
}

export function manualTicker(clock: VirtualClock): ManualTicker {
  const ticks = new Map<number, { intervalMs: number; onTick: () => void }>();
  let next = 0;
  let registered = 0;
  return {
    ticker(intervalMs, onTick) {
      const id = next;
      next += 1;
      registered += 1;
      ticks.set(id, { intervalMs, onTick });
      return () => {
        ticks.delete(id);
      };
    },
    tick() {
      for (const entry of [...ticks.values()]) entry.onTick();
    },
    advance(ms) {
      const step = [...ticks.values()][0]?.intervalMs ?? ms;
      let moved = 0;
      while (moved < ms) {
        const slice = Math.min(step, ms - moved);
        clock.advance(slice);
        moved += slice;
        this.tick();
      }
    },
    get registered() {
      return registered;
    },
  };
}

export function depsFor(gateway: ModelGateway, validationPort: FullDatasetValidationPort, clock = new VirtualClock()): CoreDependencies & { store: MemoryLedgerStore; clock: VirtualClock; timer: ManualTicker } {
  const store = new MemoryLedgerStore();
  // Retries wait on the virtual clock, never on the wall.
  const sleep = async (ms: number): Promise<void> => {
    clock.advance(ms);
  };
  // The lease-renewal timer fires only when a test fires it: a test that moves the clock past the lease without ticking models a worker whose timer never ran.
  const timer = manualTicker(clock);
  // The host's adapter dates its receipts by the clock the run is given: one clock discipline across the boundary.
  if ('clock' in validationPort && validationPort.clock === null) (validationPort as FixtureValidationPort).clock = clock;
  return { gateway, validationPort, ledgerStore: store, clock, store, egressSecret: Buffer.alloc(32, 7), sleep, ticker: timer.ticker, timer };
}
