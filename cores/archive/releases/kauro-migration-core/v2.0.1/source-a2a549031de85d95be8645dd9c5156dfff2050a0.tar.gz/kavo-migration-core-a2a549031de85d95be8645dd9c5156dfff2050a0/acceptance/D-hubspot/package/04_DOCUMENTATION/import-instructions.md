# Import instructions — HUBSPOT

Run `run_c8ba8430347b864411bee565`, core 2.0.1, package format 2.0.0.

Import the files under `01_IMPORT/` and nothing else. Every other directory is evidence:
`02_EXCEPTIONS/` is what did not go and why, `03_TRACEABILITY/` is the record of what this run
did, and `04_DOCUMENTATION/` is this file and the audit. None of them is import input.

## What to import, in this order

### COMPANY — `01_IMPORT/hubspot/companies.csv`

- Object: COMPANY
- Import mode: CREATE_ONLY
- Matching field: none. Nothing in this file is matched against a record you already hold.
- Do not map `Association Key`. It exists only so this import can associate records with each other, it is not a property, and it means nothing outside this package.
- Expect 4 records.

### CONTACT — `01_IMPORT/hubspot/contacts.csv`

- Object: CONTACT
- Import mode: CREATE_ONLY
- Matching field: none. Nothing in this file is matched against a record you already hold.
- Do not map `Association Key`. It exists only so this import can associate records with each other, it is not a property, and it means nothing outside this package.
- Expect 5 records.

### DEAL — `01_IMPORT/hubspot/deals.csv`

- Object: DEAL
- Import mode: CREATE_ONLY
- Matching field: none. Nothing in this file is matched against a record you already hold.
- Do not map `Association Key`. It exists only so this import can associate records with each other, it is not a property, and it means nothing outside this package.
- Expect 3 records.

## Associations

- `01_IMPORT/hubspot/associations/company_to_deal.csv` — COMPANY to DEAL. Each row pairs the `Association Key` value from the COMPANY file with the `Associated Association Key` value from the DEAL file.
- `01_IMPORT/hubspot/associations/contact_to_company.csv` — CONTACT to COMPANY. Each row pairs the `Association Key` value from the CONTACT file with the `Associated Association Key` value from the COMPANY file.
- `01_IMPORT/hubspot/associations/contact_to_deal.csv` — CONTACT to DEAL. Each row pairs the `Association Key` value from the CONTACT file with the `Associated Association Key` value from the DEAL file.

Strategy: run a multiple-object import. Add the association key column from the association file to both object files as a common column, then select it under "Common column headers found in your files". The column is a join key for this import only; do not map it to a property.

Expect 12 relationships to be created. 0 could not be resolved and are listed in `02_EXCEPTIONS/unresolved-associations.csv` with the reason for each.

## What to expect afterwards

- 16 source rows were read.
- 12 records are delivered across all files.
- 0 rows were set aside; each one has a reason in `02_EXCEPTIONS/isolated.csv`.
- 5 cell values differ from the source; every one of them is in `03_TRACEABILITY/changes.csv` with what it was and why it changed.
- A destination that reports a different number of created records than this file states means the import did not do what the package describes. Stop and reconcile before running anything else.

## What this run was shaped against

- Configuration hash: `ab96e82239971bde1e67721d973f92a91fc6c7f33732e0b79c13531cd937cf85`
- Source bundle: `B-56cc789fa965680a`
- Source profile: none supplied
- Target contract: `tc_be7373af0c666e6bf2720ec9f8ccaff28f7bd6c9dbaad83a251e78dcad5aa9d0`

If any of those differ from what you were expecting, this package is not the one you meant to import.
