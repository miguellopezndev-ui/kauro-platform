# Import instructions — CLEAN_ONLY

Run `run_6a9866a5bb447c39a492ba6d`, core 2.0.1, package format 2.0.0.

Import the files under `01_IMPORT/` and nothing else. Every other directory is evidence:
`02_EXCEPTIONS/` is what did not go and why, `03_TRACEABILITY/` is the record of what this run
did, and `04_DOCUMENTATION/` is this file and the audit. None of them is import input.

## What to import, in this order

### CONTACT — `01_IMPORT/clean-only/contacts.csv`

- Object: CONTACT
- Import mode: CREATE_ONLY
- Matching field: none. Nothing in this file is matched against a record you already hold.
- Every column in this file is a destination field. There is nothing here not to map.
- Expect 8 records.

## Associations

This plan declares no relationships, so there is nothing to associate.

## What to expect afterwards

- 8 source rows were read.
- 8 records are delivered across all files.
- 0 rows were set aside; each one has a reason in `02_EXCEPTIONS/isolated.csv`.
- 10 cell values differ from the source; every one of them is in `03_TRACEABILITY/changes.csv` with what it was and why it changed.
- A destination that reports a different number of created records than this file states means the import did not do what the package describes. Stop and reconcile before running anything else.

## What this run was shaped against

- Configuration hash: `b7169ea55e53c2fd34b8dbbd5168a78c8a69bc8ca062ca8f0fcb6c5034306f3c`
- Source bundle: `B-4d0d2a15e1ade00c`
- Source profile: none supplied
- Target contract: none captured

If any of those differ from what you were expecting, this package is not the one you meant to import.
