import { strict as assert } from 'node:assert';
import { describe, it } from 'node:test';
import { applyFieldTransform } from '../../src/transform/apply.js';
import { makeTransformResult } from '../../src/domain/transform.js';
import { CoreInvariantError } from '../../src/util/assert.js';
import {
  serialToDate,
  transformBoolean,
  transformDate,
  transformDateTime,
  transformEmail,
  transformEnum,
  transformNumber,
  transformPhone,
} from '../../src/transform/transformations.js';
import { DEFAULT_FIELD_OPTIONS, DEFAULT_LOCALE_EVIDENCE, DEFAULT_POLICIES } from '../../src/domain/config.js';
import type { FieldMappingConfig, FieldOptions } from '../../src/domain/config.js';
import type { SemanticType } from '../../src/domain/canonical.js';
import type { SourceCell } from '../../src/domain/source-cell.js';

function field(semanticType: SemanticType, options: Partial<FieldOptions> = {}): FieldMappingConfig {
  return {
    column: { header: 'X', occurrence: null, index: null },
    destinationField: 'contact.description',
    semanticType,
    semanticsClass: null,
    required: false,
    onAmbiguous: 'PRESERVE',
    onInvalid: 'PRESERVE',
    options: { ...DEFAULT_FIELD_OPTIONS, ...options },
  };
}

function cell(raw: string | null, overrides: Partial<SourceCell> = {}): SourceCell {
  return { columnIndex: 0, raw, kind: 'CSV_TEXT', formula: null, numberFormat: null, dateSystem: null, ...overrides };
}

function apply(
  raw: string | null,
  semanticType: SemanticType,
  options: Partial<FieldOptions> = {},
  extra: { countryEvidence?: string | null; cell?: Partial<SourceCell>; policies?: typeof DEFAULT_POLICIES } = {},
) {
  return applyFieldTransform({
    cell: cell(raw, extra.cell ?? {}),
    field: field(semanticType, options),
    locale: DEFAULT_LOCALE_EVIDENCE,
    policies: extra.policies ?? DEFAULT_POLICIES,
    countryEvidence: extra.countryEvidence ?? null,
    countryEvidenceSource: 'test',
  });
}

describe('the transformation chokepoint', () => {
  it('refuses to build an outcome that empties a populated value', () => {
    assert.throws(
      () =>
        makeTransformResult({
          kind: 'CHANGED_SAFE',
          original: 'something',
          final: '',
          reasonCode: 'TRANSFORM_UNCHANGED',
          transformationId: 'test',
          transformationVersion: '1',
        }),
      (error: unknown) =>
        error instanceof CoreInvariantError && error.invariant === 'NO_SILENT_CELL_DESTRUCTION',
    );
  });

  it('refuses an ambiguous outcome that changed the value', () => {
    assert.throws(
      () =>
        makeTransformResult({
          kind: 'AMBIGUOUS',
          original: 'a',
          final: 'b',
          reasonCode: 'TRANSFORM_UNCHANGED',
          transformationId: 'test',
          transformationVersion: '1',
        }),
      (error: unknown) =>
        error instanceof CoreInvariantError &&
        error.invariant === 'TRANSFORM_NON_COMMITTAL_PRESERVES_ORIGINAL',
    );
  });

  it('refuses to clear without the destructive safety class', () => {
    assert.throws(
      () =>
        makeTransformResult({
          kind: 'CLEAR_EXPLICIT',
          original: 'a',
          final: null,
          reasonCode: 'TRANSFORM_CLEARED_BY_EXPLICIT_AUTHORIZATION',
          transformationId: 'test',
          transformationVersion: '1',
          safetyClass: 'NON_DESTRUCTIVE',
        }),
      (error: unknown) => error instanceof CoreInvariantError,
    );
  });
});

describe('whitespace', () => {
  it('trims surrounding whitespace', () => {
    const result = apply('  padded  ', 'TEXT');
    assert.equal(result.final, 'padded');
    assert.equal(result.reasonCode, 'TRANSFORM_WHITESPACE_TRIMMED');
  });

  it('does not trim a cell that holds only whitespace, because that would empty it', () => {
    const result = apply('   ', 'TEXT');
    assert.equal(result.final, '   ');
    assert.equal(result.kind, 'UNCHANGED');
  });

  it('clears a value only when the configuration authorises exactly that value', () => {
    const result = apply('N/A', 'TEXT', { clearWhenMatches: ['n/a'], destructiveAuthorization: true });
    assert.equal(result.final, null);
    assert.equal(result.kind, 'CLEAR_EXPLICIT');
    assert.equal(result.safetyClass, 'DESTRUCTIVE_EXPLICITLY_AUTHORIZED');
    assert.equal(result.reasonCode, 'TRANSFORM_CLEARED_BY_EXPLICIT_AUTHORIZATION');
  });

  it('leaves an unlisted value alone even when clearing is authorised', () => {
    const result = apply('unknown', 'TEXT', { clearWhenMatches: ['n/a'], destructiveAuthorization: true });
    assert.equal(result.final, 'unknown');
  });
});

describe('email', () => {
  it('lowercases the domain and never the local part', () => {
    const outcome = transformEmail('Ada.Lovelace@Example.COM', true);
    assert.equal(outcome.value, 'Ada.Lovelace@example.com');
  });

  it('does not collapse a plus alias or remove dots', () => {
    const outcome = transformEmail('ada.love+crm@example.com', true);
    assert.equal(outcome.value, 'ada.love+crm@example.com');
    assert.equal(outcome.kind, 'UNCHANGED');
  });

  it('preserves a syntactically invalid address', () => {
    const outcome = transformEmail('not an address', true);
    assert.equal(outcome.kind, 'INVALID');
    assert.equal(outcome.value, 'not an address');
    assert.equal(outcome.reasonCode, 'TRANSFORM_EMAIL_INVALID_SYNTAX');
  });
});

describe('phone numbers', () => {
  const options = { countryEvidence: null, countryEvidenceSource: 'test', extensionDestinationField: null };

  it('uses the international prefix in preference to a configured country', () => {
    const outcome = transformPhone('+44 20 7946 0958', { ...options, countryEvidence: 'US' });
    assert.equal(outcome.value, '+442079460958');
    assert.equal(outcome.reasonCode, 'TRANSFORM_PHONE_E164');
  });

  it('uses the configured country for a national number', () => {
    const outcome = transformPhone('3001234567', { ...options, countryEvidence: 'CO' });
    assert.equal(outcome.value, '+573001234567');
  });

  it('preserves a national number when no country was established', () => {
    const outcome = transformPhone('3001234567', options);
    assert.equal(outcome.kind, 'AMBIGUOUS');
    assert.equal(outcome.value, '3001234567');
    assert.equal(outcome.reasonCode, 'TRANSFORM_PHONE_NO_COUNTRY_EVIDENCE');
  });

  it('preserves a number carrying an extension when there is nowhere to put it', () => {
    const outcome = transformPhone('212-555-0147 ext. 44', { ...options, countryEvidence: 'US' });
    assert.equal(outcome.kind, 'UNSUPPORTED');
    assert.equal(outcome.value, '212-555-0147 ext. 44');
    assert.equal(outcome.reasonCode, 'TRANSFORM_PHONE_EXTENSION_NO_DESTINATION_FIELD');
  });

  it('separates the extension when a destination field is configured', () => {
    const outcome = transformPhone('212-555-0147 ext. 44', {
      ...options,
      countryEvidence: 'US',
      extensionDestinationField: 'contact.phoneExtension',
    });
    assert.equal(outcome.value, '+12125550147');
    assert.equal(outcome.derived['extension'], '44');
  });

  it('preserves a number that is not valid for the established country', () => {
    const outcome = transformPhone('12345', { ...options, countryEvidence: 'US' });
    assert.equal(outcome.kind, 'INVALID');
    assert.equal(outcome.value, '12345');
  });
});

describe('dates', () => {
  it('accepts an ISO date with no declared format', () => {
    const outcome = transformDate('2026-03-04', { declaredFormat: null, spreadsheetDateSystem: null, numberFormat: null });
    assert.equal(outcome.kind, 'UNCHANGED');
    assert.equal(outcome.reasonCode, 'TRANSFORM_DATE_ISO_ACCEPTED');
  });

  it('refuses to interpret a slash date with no declared format', () => {
    const outcome = transformDate('03/04/2026', { declaredFormat: null, spreadsheetDateSystem: null, numberFormat: null });
    assert.equal(outcome.kind, 'AMBIGUOUS');
    assert.equal(outcome.value, '03/04/2026');
  });

  it('reads the same value differently under two declared formats, and says so', () => {
    const american = transformDate('03/04/2026', {
      declaredFormat: 'MM/DD/YYYY',
      spreadsheetDateSystem: null,
      numberFormat: null,
    });
    const european = transformDate('03/04/2026', {
      declaredFormat: 'DD/MM/YYYY',
      spreadsheetDateSystem: null,
      numberFormat: null,
    });
    assert.equal(american.value, '2026-03-04');
    assert.equal(european.value, '2026-04-03');
  });

  it('rejects a date-shaped value that is not a real calendar date', () => {
    const outcome = transformDate('2026-02-30', { declaredFormat: null, spreadsheetDateSystem: null, numberFormat: null });
    assert.equal(outcome.kind, 'INVALID');
    assert.equal(outcome.value, '2026-02-30');
  });

  it('converts spreadsheet serials in both date systems', () => {
    assert.deepEqual(serialToDate(44927, 'DATE_1900'), { year: 2023, month: 1, day: 1 });
    assert.deepEqual(serialToDate(45001, 'DATE_1900'), { year: 2023, month: 3, day: 16 });
    assert.deepEqual(serialToDate(1, 'DATE_1900'), { year: 1900, month: 1, day: 1 });
    assert.deepEqual(serialToDate(0, 'DATE_1904'), { year: 1904, month: 1, day: 1 });
  });

  it('refuses serial 60, the day the 1900 system invents', () => {
    assert.equal(serialToDate(60, 'DATE_1900'), null);
  });
});

describe('timestamps', () => {
  it('preserves a timestamp with no zone and no declared offset', () => {
    const outcome = transformDateTime('2026-03-04T10:30:00', null);
    assert.equal(outcome.kind, 'AMBIGUOUS');
    assert.equal(outcome.reasonCode, 'TRANSFORM_DATETIME_NO_TIMEZONE_EVIDENCE');
  });

  it('normalises to UTC when the source carries an offset', () => {
    const outcome = transformDateTime('2026-03-04T10:30:00+02:00', null);
    assert.equal(outcome.value, '2026-03-04T08:30:00Z');
  });

  it('uses a declared offset when the source has none', () => {
    const outcome = transformDateTime('2026-03-04T10:30:00', '-05:00');
    assert.equal(outcome.value, '2026-03-04T15:30:00Z');
  });
});

describe('numbers', () => {
  it('accepts plain digits with no declared separators', () => {
    assert.equal(transformNumber('1234.56', null, null).kind, 'UNCHANGED');
  });

  it('refuses to guess a separator convention', () => {
    const outcome = transformNumber('1.234', null, null);
    assert.equal(outcome.kind, 'UNCHANGED');
    const grouped = transformNumber('1.234,56', null, null);
    assert.equal(grouped.kind, 'AMBIGUOUS');
    assert.equal(grouped.value, '1.234,56');
  });

  it('reads a European convention when it is declared', () => {
    const outcome = transformNumber('1.234,56', ',', '.');
    assert.equal(outcome.value, '1234.56');
    assert.equal(outcome.reasonCode, 'TRANSFORM_NUMBER_PARSED');
  });
});

describe('booleans and enumerations', () => {
  it('uses the declared vocabulary', () => {
    assert.equal(transformBoolean('YES', ['yes'], ['no']).value, 'true');
    assert.equal(transformBoolean('maybe', ['yes'], ['no']).kind, 'INVALID');
  });

  it('preserves an option outside the declared set', () => {
    const outcome = transformEnum('Platinum', ['Gold', 'Silver']);
    assert.equal(outcome.kind, 'INVALID');
    assert.equal(outcome.value, 'Platinum');
  });
});

describe('identifiers', () => {
  it('keeps leading zeros', () => {
    assert.equal(apply('01730', 'IDENTIFIER').final, '01730');
  });

  it('flags an identifier the spreadsheet had already stored as a number', () => {
    const result = apply('1730', 'IDENTIFIER', {}, { cell: { kind: 'XLSX_NUMBER' } });
    assert.equal(result.reasonCode, 'TRANSFORM_IDENTIFIER_NUMERIC_IN_SOURCE');
  });
});

describe('spreadsheet formulas', () => {
  it('does not deliver a cached formula result by default', () => {
    const result = apply('Ada Lovelace', 'TEXT', {}, { cell: { formula: 'CONCATENATE(A1,B1)' } });
    assert.equal(result.kind, 'UNSUPPORTED');
    assert.equal(result.final, 'Ada Lovelace');
    assert.equal(result.reasonCode, 'TRANSFORM_FORMULA_CACHED_VALUE_NOT_AUTHORIZED');
    assert.ok(result.evidence.some((item) => item.detail.includes('CONCATENATE')));
  });

  it('delivers it with provenance when the configuration authorises it', () => {
    const result = apply(
      'Ada Lovelace',
      'TEXT',
      {},
      {
        cell: { formula: 'CONCATENATE(A1,B1)' },
        policies: { ...DEFAULT_POLICIES, formulaCachedValues: 'ACCEPT_WITH_PROVENANCE' },
      },
    );
    assert.equal(result.final, 'Ada Lovelace');
    assert.equal(result.reasonCode, 'TRANSFORM_FORMULA_CACHED_VALUE_ACCEPTED');
  });

  it('never treats a spreadsheet error value as data worth clearing', () => {
    const result = apply('#REF!', 'TEXT', {}, { cell: { kind: 'XLSX_ERROR' } });
    assert.equal(result.kind, 'INVALID');
    assert.equal(result.final, '#REF!');
  });
});

describe('the configured normalization primitives', () => {
  it('changes nothing at all by default', () => {
    const result = apply(' MIGUEL LOPEZ ', 'TEXT');
    assert.equal(result.final, 'MIGUEL LOPEZ');
    assert.equal(result.reasonCode, 'TRANSFORM_WHITESPACE_TRIMMED');
  });

  it('composes to NFC only when the plan asks for it', () => {
    const decomposed = 'Dise\u00f1adora S\u00e9nior'.normalize('NFD');
    const composed = 'Dise\u00f1adora S\u00e9nior'.normalize('NFC');
    assert.notEqual(decomposed, composed);

    assert.equal(apply(decomposed, 'TEXT').final, decomposed);

    const result = apply(decomposed, 'TEXT', { unicodeNormalization: 'NFC' });
    assert.equal(result.final, composed);
    assert.equal(result.kind, 'CHANGED_SAFE');
    assert.equal(result.reasonCode, 'TRANSFORM_CONFIGURED_NORMALIZATION_APPLIED');
    assert.ok(result.evidence.some((item) => item.kind === 'UNICODE_NORMALIZATION' && item.detail === 'NFC'));
  });

  it('composing twice is composing once', () => {
    const once = apply('Diseñadora', 'TEXT', { unicodeNormalization: 'NFC' }).final ?? '';
    assert.equal(apply(once, 'TEXT', { unicodeNormalization: 'NFC' }).final, once);
  });

  it('cases mechanically, exactly as the contract states', () => {
    const title = (input: string): string | null =>
      apply(input, 'TEXT', { caseTransform: 'TITLE_SIMPLE' }).final;
    assert.equal(title('MIGUEL LOPEZ'), 'Miguel Lopez');
    assert.equal(title('ANNA-MARIE'), 'Anna-Marie');
    assert.equal(title("O'NEILL"), "O'Neill");
    assert.equal(title('O’NEILL'), 'O’Neill');

    // Stated plainly rather than promised away: a mechanical rule cannot know
    // these, which is what valueMap is for.
    assert.equal(title('MCNAMARA'), 'Mcnamara');
    assert.equal(title('eBay'), 'Ebay');
  });

  it('lowercases and uppercases without consulting the operating system locale', () => {
    assert.equal(apply('İstanbul Ltd', 'TEXT', { caseTransform: 'LOWER' }).final, 'İstanbul Ltd'.toLowerCase());
    assert.equal(apply('Diseñadora', 'TEXT', { caseTransform: 'UPPER' }).final, 'DISEÑADORA');
  });

  it('walks code points rather than code units', () => {
    // A letter outside the Basic Multilingual Plane is two code units. Casing
    // it by unit would cut the surrogate pair in half.
    const result = apply('\u{1d49c}da lovelace', 'TEXT', { caseTransform: 'TITLE_SIMPLE' });
    assert.equal(result.final, '\u{1d49c}da Lovelace');
  });

  it('gives an exact mapping the last word, and skips the case rule for it', () => {
    const result = apply(' MCDONALD ', 'TEXT', {
      caseTransform: 'TITLE_SIMPLE',
      valueMap: [{ from: 'MCDONALD', to: 'McDonald' }],
    });
    assert.equal(result.final, 'McDonald');
    assert.equal(result.reasonCode, 'TRANSFORM_CONFIGURED_NORMALIZATION_APPLIED');
    assert.ok(result.evidence.some((item) => item.kind === 'VALUE_MAP'));
    assert.ok(!result.evidence.some((item) => item.kind === 'CASE_TRANSFORM'));
  });

  it('still cases a value no mapping claimed', () => {
    const result = apply('RONALD', 'TEXT', {
      caseTransform: 'TITLE_SIMPLE',
      valueMap: [{ from: 'MCDONALD', to: 'McDonald' }],
    });
    assert.equal(result.final, 'Ronald');
    assert.ok(result.evidence.some((item) => item.kind === 'CASE_TRANSFORM' && item.detail === 'TITLE_SIMPLE'));
  });

  it('does not turn a mapped column into a closed vocabulary', () => {
    // A value that matches nothing is carried through, not rejected. Closing a
    // vocabulary is semanticType ENUM with allowedValues.
    const result = apply('reseller', 'TEXT', {
      valueMap: [{ from: 'cliente', to: 'Customer' }],
    });
    assert.equal(result.final, 'reseller');
    assert.equal(result.kind, 'UNCHANGED');
  });

  it('maps categories the plan declares', () => {
    const options = {
      valueMap: [
        { from: 'cliente', to: 'Customer' },
        { from: 'cliente viejo', to: 'Customer' },
        { from: 'prospecto', to: 'Lead' },
        { from: 'partner', to: 'Partner' },
      ],
    };
    assert.equal(apply('cliente', 'TEXT', options).final, 'Customer');
    assert.equal(apply('cliente viejo', 'TEXT', options).final, 'Customer');
    assert.equal(apply('prospecto', 'TEXT', options).final, 'Lead');
    assert.equal(apply('partner', 'TEXT', options).final, 'Partner');
  });

  it('compares a mapping in the same form the value reaches it in', () => {
    const decomposedFrom = 'S\u00e9nior'.normalize('NFD');
    const result = apply(` ${'S\u00e9nior'.normalize('NFC')} `, 'TEXT', {
      unicodeNormalization: 'NFC',
      valueMap: [{ from: decomposedFrom, to: 'Senior Designer' }],
    });
    assert.equal(result.final, 'Senior Designer');
  });

  it('preserves the raw cell exactly when the semantic transform will not accept the result', () => {
    // The mapped value is what ENUM was asked to validate, and it is not in the
    // declared set. The delivered value is the untouched source cell, including
    // its whitespace; the work done on the way in stays in the evidence.
    const result = apply('  cliente  ', 'ENUM', {
      allowedValues: ['Customer', 'Lead'],
      valueMap: [{ from: 'cliente', to: 'Prospect' }],
    });
    assert.equal(result.kind, 'INVALID');
    assert.equal(result.final, '  cliente  ');
    assert.equal(result.reasonCode, 'TRANSFORM_ENUM_VALUE_NOT_IN_DECLARED_SET');
    assert.ok(result.evidence.some((item) => item.kind === 'VALUE_MAP'));
  });

  it('lets a mapping put a value into the declared set', () => {
    const result = apply('  cliente  ', 'ENUM', {
      allowedValues: ['Customer', 'Lead'],
      valueMap: [{ from: 'cliente', to: 'Customer' }],
    });
    assert.equal(result.kind, 'CHANGED_SAFE');
    assert.equal(result.final, 'Customer');
  });

  it('never empties a populated cell, whatever the plan configures', () => {
    // The only populated-to-empty path is clearWhenMatches with
    // destructiveAuthorization, so a whitespace-only cell survives the case
    // rule intact.
    const result = apply('   ', 'TEXT', { caseTransform: 'UPPER', unicodeNormalization: 'NFC' });
    assert.equal(result.final, '   ');
    assert.equal(result.kind, 'UNCHANGED');
  });
});
