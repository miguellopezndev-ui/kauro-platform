import { strict as assert } from 'node:assert';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import { repoRoot } from '../support/harness.js';

/**
 * The public package, used by somebody who is not this repository.
 *
 * Everything else in the suite imports from `src/`. That proves the modules
 * work; it proves nothing about what a consumer installing the built package
 * can reach. Intelligence Core will install the tarball and import from
 * `kavo-migration-core`, and only what `src/index.ts` exports exists for it.
 *
 * So this packs the tree with `npm pack`, installs the tarball into a temporary
 * project outside the repository, and runs a consumer that uses only the public
 * entry point: profiles a bundle, builds a candidate set, runs a migration under
 * a plan bound to the profile, writes the package, verifies it, and then feeds
 * the loaders a tampered profile and a tampered candidate set. Nothing in the
 * consumer names a path under `dist/`.
 */

const root = repoRoot();

const CONSUMER = String.raw`
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import {
  CORE_VERSION,
  PACKAGE_FORMAT_VERSION,
  SOURCE_PROFILE_VERSION,
  CANDIDATE_SET_VERSION,
  SCRATCH_BUDGET_BYTES,
  createFilesystemScratchStore,
  loadConfig,
  produceSourceProfile,
  serializeSourceProfile,
  loadSourceProfile,
  buildCandidateSet,
  serializeCandidateSet,
  loadCandidateSet,
  assertCandidateSetMatches,
  runMigration,
  writePackage,
  promotePackage,
  verifyPackage,
  packageDigest,
  MigrationError,
} from 'kavo-migration-core';

const work = process.argv[2];
const input = join(work, 'input');
mkdirSync(input, { recursive: true });
writeFileSync(join(input, 'contacts.csv'), 'Contact ID,First Name,Last Name,Email\n1,Ada,Lovelace,ada@kavo-consumer.test\n2,Grace,Hopper,grace@kavo-consumer.test\n3,Alan,Turing,alan@kavo-consumer.test\n');
const configText = JSON.stringify({
  configVersion: '2.0.0',
  source: { system: 'consumer', namespace: 'consumer' },
  target: { mode: 'CLEAN_ONLY', importMode: 'CREATE_ONLY' },
  files: [{ id: 'contacts', path: 'contacts.csv', format: 'CSV' }],
  records: [{
    id: 'contacts', fileId: 'contacts', object: 'CONTACT',
    sourceRecordIdColumn: { header: 'Contact ID' },
    fields: [
      { column: { header: 'First Name' }, destinationField: 'contact.firstName', semanticType: 'TEXT' },
      { column: { header: 'Last Name' }, destinationField: 'contact.lastName', semanticType: 'TEXT' },
      { column: { header: 'Email' }, destinationField: 'contact.email', semanticType: 'EMAIL' },
    ],
  }],
});
const configPath = join(work, 'config.json');
writeFileSync(configPath, configText);
const loaded = loadConfig(configText, configPath);

const scratch = (name) => createFilesystemScratchStore({ root: join(work, 'scratch-' + name), runId: name, quotaBytes: SCRATCH_BUDGET_BYTES });
const out = {};
let store = scratch('profile');
try {
  const profiled = produceSourceProfile({ inputRoot: input, config: loaded.config, scratch: store });
  out.profileHash = profiled.profileHash;
  out.profileVersion = profiled.profile.profileVersion;
  const text = serializeSourceProfile(profiled);
  out.profileReloads = loadSourceProfile(text, 'profile.json').profileHash === profiled.profileHash;
  try { loadSourceProfile(text.replace(profiled.profileHash, '0'.repeat(63) + '1'), 'profile.json'); out.tamperedProfile = 'ACCEPTED'; }
  catch (error) { out.tamperedProfile = error instanceof MigrationError ? error.code : 'OTHER'; }
  try { loadSourceProfile('{"profileVersion":"1.0.0"}', 'profile.json'); out.bareProfile = 'ACCEPTED'; }
  catch (error) { out.bareProfile = error instanceof MigrationError ? error.code : 'OTHER'; }

  const candidates = buildCandidateSet({ profile: profiled, configHash: loaded.configHash });
  out.candidateCount = candidates.candidateSet.candidates.length;
  out.candidateSetVersion = candidates.candidateSet.candidateSetVersion;
  const setText = serializeCandidateSet(candidates);
  out.candidateSetReloads = loadCandidateSet(setText, 'set.json').candidateSetHash === candidates.candidateSetHash;
  try { loadCandidateSet(setText.replace(candidates.candidateSetHash, '0'.repeat(63) + '1'), 'set.json'); out.tamperedSet = 'ACCEPTED'; }
  catch (error) { out.tamperedSet = error instanceof MigrationError ? error.code : 'OTHER'; }
  try { assertCandidateSetMatches(candidates, { bundleId: 'B-0000000000000000', profileHash: profiled.profileHash }); out.foreignSet = 'ACCEPTED'; }
  catch (error) { out.foreignSet = error instanceof MigrationError ? error.details.reason : 'OTHER'; }

  const run = runMigration({ inputRoot: input, config: loaded.config, configHash: loaded.configHash, scratch: scratch('run'), sourceProfile: profiled });
  out.rows = run.reconciliation.sourceRows.total;
  out.equationHolds = run.reconciliation.sourceRows.equationHolds;
  out.boundProfile = run.truth.sourceProfileHash === profiled.profileHash;
  const written = writePackage({ result: run, config: loaded.config, normalizedConfig: loaded.normalizedJson, outputDir: join(work, 'package'), force: true });
  out.artifacts = written.artifacts.length;
  // Staged, verified where it was staged, published only if it verifies — the
  // order the contract asks for, done here through public exports alone.
  const verifyStore = scratch('verify');
  try {
    const report = verifyPackage(written.stagingDir, { scratch: verifyStore });
    out.verified = report.passed;
    out.checks = report.checks.length;
  } finally { verifyStore.dispose(); }
  out.published = promotePackage(written, { force: true });
  out.digest = packageDigest(join(work, 'package')).digest;
  out.versions = { CORE_VERSION, PACKAGE_FORMAT_VERSION, SOURCE_PROFILE_VERSION, CANDIDATE_SET_VERSION };
} finally { store.dispose(); }
process.stdout.write(JSON.stringify(out));
`;

describe('the built package, consumed through its public entry point', () => {
  it('profiles, proposes, runs, verifies and refuses tampering with only public exports', { timeout: 300_000 }, () => {
    const work = join(tmpdir(), `kavo-consumer-${String(process.pid)}`);
    rmSync(work, { recursive: true, force: true });
    mkdirSync(work, { recursive: true });
    try {
      const packed = spawnSync('npm', ['pack', '--silent', '--pack-destination', work], {
        cwd: root,
        encoding: 'utf8',
        shell: process.platform === 'win32',
      });
      assert.equal(packed.status, 0, `npm pack failed: ${packed.stderr}`);
      const tarball = readdirSync(work).find((name) => name.endsWith('.tgz'));
      assert.ok(tarball !== undefined, 'npm pack produced a tarball');

      const project = join(work, 'project');
      mkdirSync(project, { recursive: true });
      writeFileSync(join(project, 'package.json'), JSON.stringify({ name: 'kavo-consumer', private: true, type: 'module' }));
      const installed = spawnSync('npm', ['install', '--silent', '--no-audit', '--no-fund', '--ignore-scripts', join(work, tarball)], {
        cwd: project,
        encoding: 'utf8',
        shell: process.platform === 'win32',
      });
      assert.equal(installed.status, 0, `npm install failed: ${installed.stderr}`);
      assert.ok(existsSync(join(project, 'node_modules', 'kavo-migration-core', 'dist', 'src', 'index.js')));

      writeFileSync(join(project, 'consumer.mjs'), CONSUMER);
      const ran = spawnSync(process.execPath, [join(project, 'consumer.mjs'), join(work, 'run')], { cwd: project, encoding: 'utf8' });
      assert.equal(ran.status, 0, `the consumer failed: ${ran.stderr}`);
      const out = JSON.parse(ran.stdout) as Record<string, unknown>;
      assert.equal(out['profileVersion'], '1.0.0');
      assert.equal(out['profileReloads'], true);
      assert.equal(out['tamperedProfile'], 'SOURCE_PROFILE_INVALID');
      assert.equal(out['bareProfile'], 'SOURCE_PROFILE_INVALID');
      assert.equal(out['candidateSetVersion'], '1.0.0');
      assert.ok(Number(out['candidateCount']) >= 1);
      assert.equal(out['candidateSetReloads'], true);
      assert.equal(out['tamperedSet'], 'CANDIDATE_SET_INVALID');
      assert.equal(out['foreignSet'], 'REFS_MISMATCH');
      assert.equal(out['rows'], 3);
      assert.equal(out['equationHolds'], true);
      assert.equal(out['boundProfile'], true);
      assert.equal(out['verified'], true);
      assert.equal(out['checks'], 55);
      assert.match(String(out['digest']), /^[0-9a-f]{64}$/u);
    } finally {
      rmSync(work, { recursive: true, force: true });
    }
  });
});
