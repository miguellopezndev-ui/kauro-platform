import { strict as assert } from 'node:assert';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, it } from 'node:test';
import fc from 'fast-check';

// A fixed seed, so a green run means the same corpus passed and not a lucky
// sample. The seed is arbitrary; what matters is that it does not move between
// runs, platforms or machines.
fc.configureGlobal({ seed: 20260829, verbose: 1 });
import { applyPermutation, contactSheet, materialize } from '../support/generate.js';
import { GOLDEN_ROOT, caseScratch, collect, listCases, readTable, runFixture, scratchDir } from '../support/harness.js';
import { loadConfig } from '../../src/mapping/load-config.js';
import { runMigration } from '../../src/run/run-migration.js';
import { writeAndPromotePackage } from '../../src/artifacts/write-package.js';
import { applyFieldTransform } from '../../src/transform/apply.js';
import { DEFAULT_FIELD_OPTIONS, DEFAULT_LOCALE_EVIDENCE, DEFAULT_POLICIES } from '../../src/domain/config.js';
import type { FieldMappingConfig } from '../../src/domain/config.js';
import { SEMANTIC_TYPES } from '../../src/domain/canonical.js';
import type { SemanticType } from '../../src/domain/canonical.js';
import { isSentinelIdentifier, renderIdentityKey } from '../../src/domain/identity.js';

const RUNS = 200;

function runGenerated(name: string, sheet: Parameters<typeof materialize>[1], overrides = {}) {
  const { inputDir, configPath } = materialize(name, sheet, overrides);
  const loaded = loadConfig(readFileSync(configPath, 'utf8'), configPath);
  return {
    loaded,
    result: runMigration({
      scratch: caseScratch('invariants1'), inputRoot: inputDir, config: loaded.config, configHash: loaded.configHash }),
  };
}

describe('P01 row conservation', () => {
  it('never loses a source row, whatever the sheet contains', () => {
    fc.assert(
      fc.property(contactSheet(), (sheet) => {
        const { result } = runGenerated('p01', sheet);
        const rows = result.reconciliation.sourceRows;
        // The number this test knows for itself: how many data rows it wrote.
        // Comparing the lineage against the reconciliation alone would be an
        // identity that no lost row could break.
        assert.equal(rows.ingested, sheet.rows.length, 'rows read');
        assert.equal(rows.total, sheet.rows.length, 'rows in the lineage');
        assert.equal(rows.accountedFor, sheet.rows.length, 'dispositions assigned');
        assert.equal(rows.withoutDisposition, 0);
        assert.equal(rows.equationHolds, true);
        assert.equal(new Set(collect(result.truth.lineage).map((entry) => entry.address.rowLocatorId)).size, rows.total);
      }),
      { numRuns: 60 },
    );
  });
});

describe('P02 no silent destruction', () => {
  const semanticType = fc.constantFrom(...SEMANTIC_TYPES);
  const value = fc.string({ minLength: 1, maxLength: 24 });

  it('an outcome that cannot commit always returns the source value', () => {
    fc.assert(
      fc.property(value, semanticType, fc.boolean(), (raw, type, trim) => {
        const field: FieldMappingConfig = {
          column: { header: 'X', occurrence: null, index: null },
          destinationField: 'contact.description',
          semanticType: type as SemanticType,
    semanticsClass: null,
          required: false,
          onAmbiguous: 'PRESERVE',
          onInvalid: 'PRESERVE',
          options: { ...DEFAULT_FIELD_OPTIONS, trim, allowedValues: type === 'ENUM' ? ['only'] : null },
        };

        const result = applyFieldTransform({
          cell: { columnIndex: 0, raw, kind: 'CSV_TEXT', formula: null, numberFormat: null, dateSystem: null },
          field,
          locale: DEFAULT_LOCALE_EVIDENCE,
          policies: DEFAULT_POLICIES,
          countryEvidence: null,
          countryEvidenceSource: 'none',
        });

        // The prime invariant: a populated cell never becomes empty without an
        // explicit destructive authorisation, which this field does not carry.
        assert.notEqual(result.final, null, `${type} emptied ${JSON.stringify(raw)}`);
        assert.notEqual(result.final, '', `${type} emptied ${JSON.stringify(raw)}`);
        assert.notEqual(result.safetyClass, 'DESTRUCTIVE_EXPLICITLY_AUTHORIZED');

        if (result.kind === 'AMBIGUOUS' || result.kind === 'INVALID' || result.kind === 'UNSUPPORTED') {
          assert.equal(result.final, raw, `${type} changed a value it could not interpret`);
        }
      }),
      { numRuns: RUNS },
    );
  });
});

describe('P03 determinism', () => {
  for (const caseId of listCases(GOLDEN_ROOT)) {
    it(`${caseId} produces identical artifacts twice`, () => {
      const first = runFixture(GOLDEN_ROOT, caseId, { scratchName: `det-a-${caseId}` });
      const second = runFixture(GOLDEN_ROOT, caseId, { scratchName: `det-b-${caseId}` });

      assert.equal(first.result.truth.runId, second.result.truth.runId, 'run id');
      assert.equal(first.written.manifestSha256, second.written.manifestSha256, 'manifest hash');
      assert.deepEqual(
        first.written.artifacts.map((artifact) => `${artifact.path}:${artifact.sha256}`),
        second.written.artifacts.map((artifact) => `${artifact.path}:${artifact.sha256}`),
        'artifact hashes',
      );
    });
  }
});

describe('P04 safe normalisation is idempotent', () => {
  const field = (type: SemanticType): FieldMappingConfig => ({
    column: { header: 'X', occurrence: null, index: null },
    destinationField: 'contact.description',
    semanticType: type,
    semanticsClass: null,
    required: false,
    onAmbiguous: 'PRESERVE',
    onInvalid: 'PRESERVE',
    options: { ...DEFAULT_FIELD_OPTIONS, phoneCountry: type === 'PHONE' ? 'US' : null },
  });

  const apply = (raw: string, type: SemanticType) =>
    applyFieldTransform({
      cell: { columnIndex: 0, raw, kind: 'CSV_TEXT', formula: null, numberFormat: null, dateSystem: null },
      field: field(type),
      locale: DEFAULT_LOCALE_EVIDENCE,
      policies: DEFAULT_POLICIES,
      countryEvidence: type === 'PHONE' ? 'US' : null,
      countryEvidenceSource: 'test',
    });

  it('applying a transformation to its own output changes nothing further', () => {
    fc.assert(
      fc.property(
        fc.string({ minLength: 1, maxLength: 24 }),
        fc.constantFrom<SemanticType>('TEXT', 'EMAIL', 'PHONE', 'DATE', 'IDENTIFIER'),
        (raw, type) => {
          const once = apply(raw, type);
          if (once.final === null) return;
          const twice = apply(once.final, type);
          assert.equal(twice.final, once.final, `${type} kept changing ${JSON.stringify(raw)}`);
        },
      ),
      { numRuns: RUNS },
    );
  });
});

describe('P05 namespaced identity', () => {
  const key = (overrides: Partial<Parameters<typeof renderIdentityKey>[0]>): string =>
    renderIdentityKey({
      sourceSystem: 'crm',
      sourceNamespace: 'acme',
      identitySpace: 'contacts',
      objectType: 'CONTACT',
      keyKind: 'SOURCE_RECORD_ID',
      keyColumn: '',
      keyColumnAddress: '',
      sourceRecordId: '1',
      ...overrides,
    });

  it('the same raw id under different namespaces is a different key', () => {
    fc.assert(
      fc.property(
        fc.string({ minLength: 1, maxLength: 10 }),
        fc.string({ minLength: 1, maxLength: 8 }),
        fc.string({ minLength: 1, maxLength: 8 }),
        (id, namespaceA, namespaceB) => {
          fc.pre(namespaceA !== namespaceB);
          assert.notEqual(
            key({ sourceNamespace: namespaceA, sourceRecordId: id }),
            key({ sourceNamespace: namespaceB, sourceRecordId: id }),
          );
        },
      ),
      { numRuns: RUNS },
    );
  });

  it('the same raw id in two id spaces is a different key', () => {
    // Contacts numbered from 1 and leads numbered from 1 are the ordinary case.
    assert.notEqual(key({ identitySpace: 'contacts' }), key({ identitySpace: 'leads' }));
  });

  it('the same raw id on two objects is a different key', () => {
    // A lead and a contact both numbered 1 are two records, not one, and a
    // lead is not a contact under another name.
    assert.notEqual(key({ objectType: 'CONTACT' }), key({ objectType: 'LEAD' }));
  });

  it('no pair of different key descriptions renders the same string', () => {
    // The forgery this guards against: a plain record id spelled to look like
    // an external-id key used to render byte-identically to one.
    const parts = ['', 'a', 'b', '|', String.fromCharCode(92), ':', 'ext', 'ext:', 'SAP ID', '900', 'ext:SAP ID:900'];
    fc.assert(
      fc.property(
        fc.constantFrom(...parts),
        fc.constantFrom(...parts),
        fc.constantFrom<'SOURCE_RECORD_ID' | 'EXTERNAL_ID'>('SOURCE_RECORD_ID', 'EXTERNAL_ID'),
        fc.constantFrom(...parts),
        fc.constantFrom(...parts),
        fc.constantFrom<'SOURCE_RECORD_ID' | 'EXTERNAL_ID'>('SOURCE_RECORD_ID', 'EXTERNAL_ID'),
        (columnA, idA, kindA, columnB, idB, kindB) => {
          const a = key({ keyColumn: columnA, sourceRecordId: idA, keyKind: kindA });
          const b = key({ keyColumn: columnB, sourceRecordId: idB, keyKind: kindB });
          const same = columnA === columnB && idA === idB && kindA === kindB;
          assert.equal(a === b, same, `${JSON.stringify([columnA, idA, kindA])} vs ${JSON.stringify([columnB, idB, kindB])}`);
        },
      ),
      { numRuns: 500 },
    );
  });

  it('a separator inside a value cannot forge another namespace', () => {
    assert.notEqual(key({ sourceNamespace: 'one|contacts' }), key({ sourceNamespace: 'one' }));
  });

  it('export placeholders are not identifiers', () => {
    for (const sentinel of ['undefined', 'NULL', 'null', '#N/A', 'N/A', ' (null) ', '#REF!']) {
      assert.equal(isSentinelIdentifier(sentinel), true, sentinel);
    }
    for (const real of ['0', '1', 'C-1', 'nullify', '00123']) {
      assert.equal(isSentinelIdentifier(real), false, real);
    }
  });

  it('leaves ordinary short codes alone', () => {
    // NA, NONE and NIL were treated as placeholders and are not. They are
    // ordinary primary keys in division, region and segment tables, and
    // suppressing them made the engine report that no source record matched a
    // relationship endpoint whose record was delivered in the same package.
    for (const real of ['NA', 'na', 'NONE', 'none', 'NIL', 'nil', 'None']) {
      assert.equal(isSentinelIdentifier(real), false, real);
    }
  });
});

describe('P06 order invariance', () => {
  it('shuffling rows does not change which records are delivered', () => {
    fc.assert(
      fc.property(
        contactSheet({ minRows: 2, maxRows: 8 }),
        fc.array(fc.integer({ min: 0, max: 1000 }), { minLength: 8, maxLength: 8 }),
        (sheet, permutation) => {
          const shuffled = { headers: sheet.headers, rows: applyPermutation(sheet.rows, permutation) };
          const base = runGenerated('p06-base', sheet);
          const other = runGenerated('p06-shuffled', shuffled);

          const summarise = (result: typeof base.result): string[] =>
            collect(result.truth.deliveredRecords)
              .map((record) => `${String(record.sourceRecordId)}|${JSON.stringify(record.values)}`)
              .sort();

          assert.deepEqual(summarise(other.result), summarise(base.result), 'delivered records');
          assert.equal(
            other.result.reconciliation.sourceRows.total,
            base.result.reconciliation.sourceRows.total,
          );
          assert.equal(other.result.reconciliation.cells.changed, base.result.reconciliation.cells.changed);
        },
      ),
      { numRuns: 40 },
    );
  });
});

describe('P07 blank values never form a duplicate cluster', () => {
  it('any number of blank emails stays any number of records', () => {
    fc.assert(
      fc.property(fc.integer({ min: 2, max: 25 }), (count) => {
        const rows = Array.from({ length: count }, (_, index) => [
          String(index + 1),
          `First${String(index)}`,
          `Last${String(index)}`,
          '',
        ]);
        const { result } = runGenerated('p07', {
          headers: ['Contact ID', 'First Name', 'Last Name', 'Email'],
          rows,
        });
        assert.equal(result.reconciliation.identity.duplicateCandidateClusters, 0);
        assert.equal(result.reconciliation.identity.provenMerges, 0);
        assert.equal(result.reconciliation.records.byObject.CONTACT, count);
      }),
      { numRuns: 25 },
    );
  });
});

describe('P08 association conservation', () => {
  for (const caseId of listCases(GOLDEN_ROOT)) {
    it(`${caseId} gives every source relationship exactly one disposition`, () => {
      const run = runFixture(GOLDEN_ROOT, caseId, { scratchName: `p08-${caseId}` });
      const associations = run.result.reconciliation.associations;

      // The number this property is about comes from the package on disk, not
      // from the array the dispositions are tallied out of. Comparing
      // `truth.edges.count` against `sourceEdges` was an identity — a
      // relationship could vanish between being built and being counted and
      // every assertion here still held. The manifest records how many
      // candidates were built, which is the one number a lost relationship
      // cannot take with it.
      const manifest = JSON.parse(readFileSync(join(run.packageDir, 'manifest.json'), 'utf8')) as {
        relationshipCandidates: number;
      };
      const ledger = readTable(run.packageDir, 'associations.csv').rows.length;
      assert.equal(associations.withoutDisposition, 0);
      assert.equal(associations.equationHolds, true);
      assert.equal(manifest.relationshipCandidates, ledger, 'the ledger holds every candidate');
      assert.equal(manifest.relationshipCandidates, associations.sourceEdges);
      assert.equal(
        Object.values(associations.byDisposition).reduce((sum, value) => sum + value, 0),
        manifest.relationshipCandidates,
        'the dispositions account for every candidate',
      );
      assert.equal(
        new Set(collect(run.result.truth.edges).map((edge) => edge.sourceEdgeId)).size,
        run.result.truth.edges.count,
        'edge ids are unique',
      );
      for (const edge of run.result.truth.edges) {
        assert.ok(edge.reasonCode.length > 0, 'every relationship carries a reason code');
      }
    });
  }
});

describe('generated packages still verify', () => {
  it('a randomly generated sheet produces a package that verifies', () => {
    fc.assert(
      fc.property(contactSheet({ minRows: 1, maxRows: 6 }), (sheet) => {
        const { inputDir, configPath } = materialize('verify-generated', sheet);
        const loaded = loadConfig(readFileSync(configPath, 'utf8'), configPath);
        const result = runMigration({
      scratch: caseScratch('invariants2'),
          inputRoot: inputDir,
          config: loaded.config,
          configHash: loaded.configHash,
        });
        const outputDir = scratchDir('generated-package');
        writeAndPromotePackage({
          result,
          config: loaded.config,
          normalizedConfig: loaded.normalizedJson,
          outputDir,
          force: true,
        });
      }),
      { numRuns: 25 },
    );
  });
});
