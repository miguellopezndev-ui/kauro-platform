import { strict as assert } from 'node:assert';
import { describe, it } from 'node:test';
import { renderIdentityKey, permitsAutomaticMerge } from '../../src/domain/identity.js';
import type { SourceIdentityKey } from '../../src/domain/identity.js';
import type { IdentityEvidence } from '../../src/domain/identity.js';

/**
 * The identity key, tested at the level where the forgeries were found.
 *
 * An independent review broke this twice. First by concatenating an external
 * identifier into the id segment; that was fixed by giving every part its own
 * escaped segment. Then by the same trick one field to the left: the column
 * segment was header text, so two columns sharing a header rendered one key,
 * and a headerless column rendered synthesized text that a real header could
 * spell. These cases pin both.
 */

function key(overrides: Partial<SourceIdentityKey> = {}): string {
  return renderIdentityKey({
    sourceSystem: 'generic_csv',
    sourceNamespace: 'acme',
    identitySpace: 'contacts',
    objectType: 'CONTACT',
    keyKind: 'EXTERNAL_ID',
    keyColumn: 'Legacy ID',
    keyColumnAddress: 'occurrence:1',
    sourceRecordId: '500',
    ...overrides,
  });
}

describe('an identity key names one column, not one column name', () => {
  it('separates two columns that share a header', () => {
    assert.notEqual(key({ keyColumnAddress: 'occurrence:1' }), key({ keyColumnAddress: 'occurrence:2' }));
  });

  it('separates a headerless column from a column whose header spells its position', () => {
    // The headerless column at index 1 used to render "#1", which is a header
    // a file may genuinely carry.
    const headerless = key({ keyColumn: '', keyColumnAddress: 'index:1' });
    const spelled = key({ keyColumn: '#1', keyColumnAddress: 'occurrence:1' });
    const literal = key({ keyColumn: 'index:1', keyColumnAddress: 'occurrence:1' });
    assert.equal(new Set([headerless, spelled, literal]).size, 3);
  });

  it('separates a lead from a contact the export numbered the same', () => {
    // A Lead and a Contact are two records, so the object type is its own
    // segment: one sequence numbering both from 1 — the most ordinary CRM
    // export there is — must not render one key for row 500 of each.
    assert.notEqual(key({ objectType: 'CONTACT' }), key({ objectType: 'LEAD' }));
  });

  it('keeps the same column in two files as one key', () => {
    // The address is where the column sits in its sheet, not which file it came
    // from: two halves of one export still merge on a shared external id.
    assert.equal(key(), key());
  });

  it('cannot be forged by spelling a separator into any segment', () => {
    const parts: (keyof SourceIdentityKey)[] = [
      'sourceSystem',
      'sourceNamespace',
      'identitySpace',
      'keyColumn',
      'keyColumnAddress',
      'sourceRecordId',
    ];
    const rendered = new Set<string>();
    for (const part of parts) {
      for (const value of ['a|b', 'a\\|b', 'a\\b', 'a', 'b']) {
        rendered.add(key({ [part]: value } as Partial<SourceIdentityKey>));
      }
    }
    assert.equal(rendered.size, parts.length * 5, 'two different keys rendered the same string');
  });
});

describe('a merge cites the key that joined it', () => {
  const evidence = (heldByMembers: number): IdentityEvidence => ({
    kind: 'SOURCE_RECORD_ID',
    authority: heldByMembers > 1 ? 'PROVING' : 'SUPPORTING',
    heldByMembers,
    value: key(),
    reasonCode: heldByMembers > 1 ? 'IDENTITY_PROVEN_SOURCE_RECORD_ID' : 'IDENTITY_MEMBER_KEY_NOT_SHARED',
  });

  it('does not accept a merge whose every key is held by one row', () => {
    // Two rows with two different record ids in one identity space are, by the
    // engine's own definition, two records. Listing both as PROVING made a
    // merge cite the evidence that it should not have happened.
    assert.equal(permitsAutomaticMerge([evidence(1), evidence(1)]), false);
  });

  it('accepts a merge with a key two rows share', () => {
    assert.equal(permitsAutomaticMerge([evidence(2), evidence(1)]), true);
  });
});
