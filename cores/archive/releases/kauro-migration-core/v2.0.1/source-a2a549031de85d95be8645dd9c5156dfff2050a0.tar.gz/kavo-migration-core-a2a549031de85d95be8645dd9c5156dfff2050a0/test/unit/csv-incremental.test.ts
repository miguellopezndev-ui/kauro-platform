import { strict as assert } from 'node:assert';
import { describe, it } from 'node:test';
import { createCsvScanner } from '../../src/ingest/csv-reader.js';
import { countCsvRecords, createCsvCensus } from '../../src/ingest/row-census.js';

const options = {
  delimiter: ',',
  filePath: 'incremental.csv',
  maxCellLength: 1_000,
  maxColumns: 100,
  maxRows: 1_000,
};

/**
 * The reason the incremental reader exists, stated as behaviour.
 *
 * It once carried every piece and parsed nothing until the last one. The output
 * was identical, so every agreement test passed — while the carry grew until it
 * held the whole file and the parse became quadratic in its size. A 28 MB
 * artifact took thirty seconds instead of a third of one, and because a slice
 * keeps its source alive, any caller that kept a single cell kept the file it
 * came from.
 *
 * Identical output is therefore not enough to state. What has to hold is that a
 * record completed inside a piece is handed over when that piece arrives, and
 * that what survives a piece is the record it was in the middle of and nothing
 * earlier.
 */
describe('the CSV reader reads incrementally', () => {
  it('hands out the records a piece completes, before the file ends', () => {
    const seen: number[] = [];
    const scanner = createCsvScanner(options, (recordNumber) => {
      seen.push(recordNumber);
    });

    scanner.push('a,b\n1,2\n3,4\n');
    // The last two characters of a piece are held back deliberately: a CRLF
    // can fall across the boundary, and deciding what a lone carriage return
    // means before the next byte arrives would make the line terminator depend
    // on the block size. So a piece hands over every record that finishes more
    // than two characters before its end.
    assert.deepEqual(seen, [1, 2], 'the complete records were not handed over when their piece arrived');

    scanner.push('5,6\n');
    assert.deepEqual(seen, [1, 2, 3], 'the next complete record was not handed over when its piece arrived');

    scanner.end();
    assert.deepEqual(seen, [1, 2, 3, 4], 'the last record was not finished by ending the file');
  });

  it('carries only the record it is in the middle of', () => {
    const seen: string[] = [];
    const scanner = createCsvScanner(options, (_recordNumber, fields) => {
      seen.push(fields.join('|'));
    });

    scanner.push('a,b\n1,2\n3,');
    assert.deepEqual(seen, ['a|b', '1|2'], 'the finished records were held back');

    scanner.push('4\n5,6\n');
    scanner.end();
    assert.deepEqual(
      seen,
      ['a|b', '1|2', '3|4', '5|6'],
      'a record was handed over twice, so more than the unfinished record was carried',
    );
  });

  it('does not wait for a terminator that will never come', () => {
    // A file whose last record has no line terminator is finished by `end()`,
    // and the records before it were handed over long before that.
    const seen: string[] = [];
    const scanner = createCsvScanner(options, (_recordNumber, fields) => {
      seen.push(fields.join('|'));
    });
    scanner.push('a,b\n1,2\n');
    assert.deepEqual(seen, ['a|b']);
    scanner.push('3,4');
    scanner.end();
    assert.deepEqual(seen, ['a|b', '1|2', '3|4']);
  });
});

/**
 * The independent count, over a file that arrives in pieces.
 *
 * The census exists so that "rows read" is not the reader agreeing with itself.
 * A census that needed the whole file would put the file back in memory to
 * check that the reader did not have to, so it counts a piece at a time — and
 * has to reach the same number however the pieces fall, including when a CRLF
 * or an escaped quote is split between two of them.
 */
describe('the row census counts in pieces', () => {
  const CASES = [
    ['plain rows', 'a,b\n1,2\n3,4\n'],
    ['an escaped quote', 'a\n"x""y"\n'],
    ['CRLF terminators', 'a,b\r\n1,2\r\n'],
    ['a quoted line break', 'a,b\n1,"two\nlines"\n5,6'],
    ['blank lines', '\n\n'],
    ['no terminator at all', 'a'],
    ['nothing', ''],
  ] as const;

  for (const [label, text] of CASES) {
    it(`agrees with the whole-text count on ${label}`, () => {
      const whole = countCsvRecords(text, ',');
      for (let size = 1; size <= Math.max(1, text.length + 2); size += 1) {
        const census = createCsvCensus();
        for (let at = 0; at < text.length; at += size) census.push(text.slice(at, at + size));
        assert.equal(census.total(), whole, `${label} disagreed at chunk size ${String(size)}`);
      }
    });
  }
});
