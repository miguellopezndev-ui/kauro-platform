# Migration Core — provenance

What this release is, what established it, and what it does not claim. Generated
by `node tools/provenance.mjs` from the evidence on disk, so it cannot drift
from the repository it describes. Every gate state below is read from the
evidence that gate wrote; none is asserted here.

- Core version `2.0.1`, package `2.0.1`, package format `2.0.0`
- Source registry reviewed `2026-09-06`
- Campaign `c_53d6b2453fe15386`, sealed 2026-09-11T02:18:41Z, over subject `535b44e033e1630b`
- `MIGRATION_CORE_IMPLEMENTATION_FROZEN` is decided by `tools/freeze-verdict.mjs`, outside this tree

## Support envelope

Three commercial modes and nothing else: `HUBSPOT`, `SALESFORCE`,
`CLEAN_ONLY`. HubSpot carries Contact, Company and Deal. Salesforce carries
Account, Contact, Lead and Opportunity, with Lead first-class rather than a
renamed Contact. **Activities are out of the envelope and are refused**, before
a file is written, rather than attempted and lost.

## Gates

| Gate | State | Established by |
| --- | --- | --- |
| `CORE-CONSTITUTION-01` | **PASS** | the offline universe ran it (exit 0); CORE-CONSTITUTION-01 = PASS |
| `TARGET-CONTRACT-01` | **PASS** | the offline universe ran it (exit 0); TARGET-CONTRACT-01 = PASS |
| `EVIDENCE-RULES-01` | **PASS** | the offline universe ran it (exit 0); EVIDENCE-RULES-01 = PASS |
| `SABOTAGE` | **PASS** | the offline universe ran the whole corpus (exit 0); outcomes: KILLED 98 |
| `SABOTAGE-LEFT-NO-TRACE` | **PASS** | no tracked change, no untracked file, no mode change, and nothing undeclared under tmp/ |
| `FINAL-ADV-01` | **PASS** | 8 attacks |
| `HSP-TARGET-01 (target contract)` | **PASS** | 42 checks against 51872453 |
| `HSP-TARGET-01 (import)` | **PASS** | 27 expectations against 51872453 |
| `SF-TARGET-01 (target contract)` | **PASS** | 11 checks against 00Dak000018tvSeEAI |
| `SF-TARGET-01 (Data Loader)` | **PASS** | 29 expectations against 00Dak000018tvSeEAI |
| `SF-OCR-01` | **PASS** | 13 expectations, real org, real Data Loader |
| `CAPACITY-FOUNDING` | **PASS** | a million representative source rows in each of CLEAN_ONLY, HUBSPOT, SALESFORCE, inside the founding budgets in bytes |

## Capacity

The resource contract, in bytes: memory budget 6,012,954,214
against a hard ceiling of 8,589,934,592, scratch budget
51,539,607,552, wall clock 28,800,000 ms.

| Mode | Source rows | Peak RSS | Peak scratch | Package | Wall clock | Result |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `CLEAN_ONLY` | 1,003,000 | 1,700,073,472 | 10,798,835,609 | 1,607,222,375 | 1,103,646 ms | PASS |
| `HUBSPOT` | 1,003,750 | 1,653,944,320 | 12,219,445,584 | 1,859,274,353 | 1,260,985 ms | PASS |
| `SALESFORCE` | 1,003,000 | 1,587,810,304 | 10,797,818,282 | 1,716,646,645 | 1,110,007 ms | PASS |

Every figure is an integer count of bytes or milliseconds, read from the
founding evidence. There is no mebibyte in this record and none in the files it
reads: the evidence that shipped with V1 computed a field called `peakMb` as
bytes divided by 1024 twice and compared it against a budget written the other
way.

## Evidence

| Artifact | Required | Present | SHA-256 |
| --- | --- | --- | --- |
| `qualification/evidence/final-adversarial.json` | yes | yes | `98f875a6b140a28e` |
| `qualification/evidence/hs-target-contract.json` | yes | yes | `e081f3c55a9c0079` |
| `qualification/evidence/hs-import.json` | yes | yes | `0126cbe47224f1fa` |
| `qualification/evidence/sf-target-contract.json` | yes | yes | `8c43d4edf3aa2cfe` |
| `qualification/evidence/sf-dataloader.json` | yes | yes | `cf43459293b3ce87` |
| `qualification/evidence/sf-ocr.json` | yes | yes | `aebc20b4dee9e0f6` |
| `qualification/capacity/clean-only.json` | yes | yes | `75407d8bc0044378` |
| `qualification/capacity/hubspot.json` | yes | yes | `e0d5ae974711856d` |
| `qualification/capacity/salesforce.json` | yes | yes | `c9f09cd71ac143b6` |
| `qualification/capacity/matrix.json` | yes | yes | `0f9bfbf65d861617` |
| `qualification/candidate/manifest.json` | yes | yes | `a1e79648d1dfdc57` |
| `qualification/candidate/provenance.json` | yes | yes | `4083d7ad7904416f` |
| `qualification/candidate/preflight.json` | yes | yes | `289455fa3a6307a2` |
| `qualification/candidate/universe.json` | yes | yes | `010d11935da263d9` |
| `qualification/candidate/campaign.json` | yes | yes | `873f56a7be451ef6` |
| `qualification/evidence/HUBSPOT_SCOPE_BLOCKER.md` | yes | yes | `3095f9c8692281b9` |
| `qualification/evidence/SF_DATALOADER_AUTH.md` | yes | yes | `685a4ff5511ffa1d` |
| `qualification/evidence/TENANT_SAFETY.md` | yes | yes | `794addfaee4ca990` |
| `docs/work/GATES.md` | yes | yes | `40366d218c968e16` |
| `qualification/evidence/hs-custom-property.json` | no | yes | `c1d3a8973660cab1` |

## What this release does not claim

- That the committed acceptance packages have been imported anywhere. They are reproducibility evidence. What was imported was built from the qualification corpora, into the developer-test portal and the Developer Edition org named in the vendor evidence.
- That either qualification tenant is a production account. Neither is: one is an isolated HubSpot developer test account, the other a disposable Salesforce Developer Edition org, and qualification/evidence/TENANT_SAFETY.md records how each was established before anything was written.
- That an attestation issued from outside this repository has ever been verified here. Every attestation this engine has verified is a genuine Ed25519 signature over a contract naming an instance nobody owns; the seam is real and the external issuer is not yet.
- That the capacity figures hold on a smaller machine. They are one host's measurements — win32 — and every capacity record carries the environment it was taken on.
- That this record establishes which commit it describes. It cannot: a file inside a tree cannot name the tree that contains it. The commit, the git tree and the cross-platform result are the external CI receipt’s, and tools/receipt-verify.mjs is what checks them.
