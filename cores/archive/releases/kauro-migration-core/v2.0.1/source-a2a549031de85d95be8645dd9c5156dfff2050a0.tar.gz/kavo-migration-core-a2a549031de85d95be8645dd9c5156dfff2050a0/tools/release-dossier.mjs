#!/usr/bin/env node
/**
 * The release dossier: what a release of this core must carry, built outside
 * the tree it describes and verified byte by byte after download.
 *
 * ---- why the inventory is declared here and not derived from the release ----
 *
 * `release_assets_verified` in the freeze verdict used to read whatever assets
 * the release happened to carry, require each to be named in SHA256SUMS,
 * download it and hash it. That is a proof that the sums match the files. It
 * is not a proof that the files are this candidate's: a release carrying
 * `unrelated.txt` and a matching SHA256SUMS satisfied it, and so did a release
 * whose `immutable` flag was false. The expected inventory is written down
 * here, versioned, with the role and origin of every asset, and the verdict
 * compares against it. Nothing in the inventory is read from the release.
 *
 * ---- what binds the dossier to the candidate ----
 *
 * `dossier-manifest.json` names the repository, the commit, its tree, the
 * versions, the candidate's code and manifest digests, the campaign, the
 * per-producer fingerprints, and every other asset with its size and digest.
 * It is generated after the assets it lists, outside the tree, and it does not
 * hash itself. SHA256SUMS covers every asset including the dossier manifest
 * and does not contain its own hash. The verdict checks the manifest's claims
 * against what it measured in the clean checkout and against the receipt it
 * was handed — a sum uploaded beside a file proves nothing about where the
 * file came from.
 *
 * The final freeze verdict is not an asset. It is decided after publication,
 * about the published release, and an immutable release cannot receive it
 * afterwards; putting it inside would either be a draft verdict masquerading
 * as the final one or a cycle in which the verdict vouches for itself.
 *
 *   node tools/release-dossier.mjs --build --out <dir> --receipt <path> [--tag v2.0.1]
 *   node tools/release-dossier.mjs --verify <dir> --receipt <path> [--sha <sha>] [--tag v2.0.1]
 *   node tools/release-dossier.mjs --verify-remote --tag v2.0.1 --receipt <path> [--allow-draft]
 *
 * `--verify-remote` with `--allow-draft` is the preparation check: it downloads
 * a draft's assets and runs the same verification, and it reports
 * `draft_ready`. It never emits a freeze flag; only the freeze verdict does,
 * and only over a published, immutable release.
 */
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync, rmSync, copyFileSync } from 'node:fs';
import { isAbsolute, join, relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { gunzipSync, gzipSync } from 'node:zlib';

import { measureTree, repoRoot, versions } from './candidate-provenance.mjs';
import { measureProducers } from './producer-closure.mjs';
import { githubToken, liveCandidate, normaliseRepository } from './receipt-verify.mjs';
import { measureSubject } from './execution-subject.mjs';
import { readCampaign } from '../qualification/campaign.mjs';

export const DOSSIER_INVENTORY_VERSION = '1.0.0';
export const DOSSIER_MANIFEST_KIND = 'MIGRATION_CORE_RELEASE_DOSSIER';
export const DOSSIER_MANIFEST_NAME = 'dossier-manifest.json';
export const SUMS_NAME = 'SHA256SUMS';
const API_TIMEOUT_MS = 60_000;
const PAGE = 100;

export const sha256 = (buffer) => createHash('sha256').update(buffer).digest('hex');

/**
 * Every asset a release of this core carries, by name, with what it is and
 * where it comes from. The names that depend on the candidate take the core
 * version and the commit; nothing else varies.
 *
 * @param {{coreVersion: string, sha: string}} candidate
 * @returns {ReadonlyArray<{name: string, role: string, kind: string, origin: string}>}
 */
export function dossierInventory({ coreVersion, sha }) {
  if (typeof coreVersion !== 'string' || !/^\d+\.\d+\.\d+$/u.test(coreVersion)) throw new Error(`a core version is x.y.z, got ${String(coreVersion)}`);
  if (typeof sha !== 'string' || !/^[0-9a-f]{40}$/u.test(sha)) throw new Error(`a commit is 40 hex characters, got ${String(sha)}`);
  return Object.freeze([
    { name: `kavo-migration-core-${coreVersion}.tgz`, role: 'PACKAGE', kind: 'application/gzip', origin: 'npm pack from the clean checkout at the commit' },
    { name: `source-${sha}.tar.gz`, role: 'SOURCE', kind: 'application/gzip', origin: 'git archive of the commit' },
    { name: 'sbom.cdx.json', role: 'SBOM', kind: 'application/json', origin: 'npm sbom --sbom-format cyclonedx over the lockfile' },
    { name: 'manifest.json', role: 'CANDIDATE_MANIFEST', kind: 'application/json', origin: 'qualification/candidate/manifest.json at the commit' },
    { name: 'provenance.json', role: 'CANDIDATE_PROVENANCE', kind: 'application/json', origin: 'qualification/candidate/provenance.json at the commit' },
    { name: 'preflight.json', role: 'PREFLIGHT', kind: 'application/json', origin: 'qualification/candidate/preflight.json at the commit' },
    { name: 'universe.json', role: 'UNIVERSE', kind: 'application/json', origin: 'qualification/candidate/universe.json at the commit' },
    { name: 'campaign.json', role: 'CAMPAIGN', kind: 'application/json', origin: 'qualification/candidate/campaign.json at the commit' },
    { name: 'migration-core-provenance.json', role: 'RELEASE_PROVENANCE', kind: 'application/json', origin: 'migration-core-provenance.json at the commit' },
    { name: 'ci-receipt.json', role: 'CI_RECEIPT', kind: 'application/json', origin: "downloaded from the merged commit's workflow run, observer-verified" },
    { name: 'evidence.tar.gz', role: 'EVIDENCE', kind: 'application/gzip', origin: 'qualification/evidence and qualification/capacity at the commit' },
    { name: DOSSIER_MANIFEST_NAME, role: 'DELIVERY_MANIFEST', kind: 'application/json', origin: 'written by tools/release-dossier.mjs outside the tree, after the assets it lists' },
    { name: SUMS_NAME, role: 'SUMS', kind: 'text/plain', origin: 'sha256 of every other asset, the delivery manifest included, never itself' },
  ]);
}

/**
 * A strict reader for SHA256SUMS.
 *
 * Every line is `<64 hex>  <name>` with exactly two spaces, one line per name,
 * LF line endings, a final newline, no blank lines, no paths, no binary
 * marker, no duplicate names and no entry for the sums file itself. Anything
 * else is a problem, named; nothing is skipped.
 *
 * @param {string} text
 * @returns {{entries: Map<string, string>, problems: string[]}}
 */
export function parseSums(text) {
  const problems = [];
  const entries = new Map();
  if (typeof text !== 'string') return { entries, problems: ['SHA256SUMS is not text'] };
  if (text === '') return { entries, problems: ['SHA256SUMS is empty'] };
  if (text.includes('\r')) problems.push('SHA256SUMS contains a carriage return');
  if (!text.endsWith('\n')) problems.push('SHA256SUMS does not end with a newline');
  const lines = text.endsWith('\n') ? text.slice(0, -1).split('\n') : text.split('\n');
  lines.forEach((line, index) => {
    const at = `line ${String(index + 1)}`;
    if (line === '') {
      problems.push(`${at} is blank`);
      return;
    }
    const match = /^([0-9a-f]{64})  (.+)$/u.exec(line);
    if (match === null) {
      problems.push(`${at} is not "<sha256>  <name>": ${line.slice(0, 80)}`);
      return;
    }
    const [, digest, name] = match;
    if (name !== name.trim()) problems.push(`${at} names "${name}" with surrounding whitespace`);
    if (/[/\\]/u.test(name)) problems.push(`${at} names a path, not a file: ${name}`);
    if (name.startsWith('*') || name.startsWith('-')) problems.push(`${at} carries a marker or option prefix: ${name}`);
    if (name === SUMS_NAME) problems.push(`${at} names ${SUMS_NAME} itself`);
    if (entries.has(name)) problems.push(`${at} names ${name} a second time`);
    entries.set(name, digest);
  });
  return { entries, problems };
}

/**
 * The delivery manifest, from measurements taken in the clean checkout and
 * from the assets already written. It lists the other assets, never itself and
 * never the sums.
 */
export function buildDossierManifest({ repository, sha, gitTree, tag, coreVersion, packageFormatVersion, codeDigest, manifestDigest, subjectDigest, campaignId, producers, assets, builtAt, controlFlowTestOnly = false }) {
  const listed = assets
    .filter((asset) => asset.name !== DOSSIER_MANIFEST_NAME && asset.name !== SUMS_NAME)
    .map((asset) => ({ name: asset.name, role: asset.role, bytes: asset.bytes, sha256: asset.sha256 }))
    .sort((a, b) => (a.name < b.name ? -1 : 1));
  return {
    artifactKind: DOSSIER_MANIFEST_KIND,
    dossierInventoryVersion: DOSSIER_INVENTORY_VERSION,
    repository,
    sha,
    gitTree,
    tag,
    versions: { coreVersion, packageFormatVersion },
    codeDigest,
    manifestDigest,
    subjectDigest,
    campaignId,
    producers,
    assets: listed,
    builtAt,
    builtBy: 'tools/release-dossier.mjs',
    // A dossier built from stand-in records in a rehearsal says so in its own
    // manifest, and the verifier refuses it outside a rehearsal.
    ...(controlFlowTestOnly ? { controlFlowTestOnly: true } : {}),
  };
}

/**
 * Minimal tar directory: member names and bytes, from a gzip'd tar. Enough to
 * find package/package.json in an npm tarball without a dependency.
 */
export function tarMembers(gzBytes) {
  const tar = gunzipSync(gzBytes);
  const members = new Map();
  let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every((byte) => byte === 0)) break;
    const name = header.subarray(0, 100).toString('utf8').replace(/\0.*$/su, '');
    const prefix = header.subarray(345, 500).toString('utf8').replace(/\0.*$/su, '');
    const size = parseInt(header.subarray(124, 136).toString('utf8').replace(/\0.*$/su, '').trim() || '0', 8);
    const type = String.fromCharCode(header[156]);
    const full = prefix === '' ? name : `${prefix}/${name}`;
    offset += 512;
    if (type === '0' || type === '\0' || type === '') members.set(full, tar.subarray(offset, offset + size));
    offset += Math.ceil(size / 512) * 512;
  }
  return members;
}

/**
 * A gzip'd ustar archive of the given files, written here rather than by
 * whichever `tar` is first on the PATH: GNU tar reads `C:\\…` as a remote
 * host, bsdtar and GNU tar disagree on defaults, and an archive whose bytes
 * depend on the machine cannot be reproduced. Entries are sorted by path,
 * mtime is zero, mode is 0644, owner is nobody.
 *
 * @param {ReadonlyArray<{path: string, bytes: Buffer}>} files
 */
export function writeTarGz(files) {
  const blocks = [];
  const sorted = [...files].sort((a, b) => (a.path < b.path ? -1 : 1));
  for (const file of sorted) {
    const header = Buffer.alloc(512, 0);
    let name = file.path;
    let prefix = '';
    if (Buffer.byteLength(name) > 100) {
      const cut = name.lastIndexOf('/', 100);
      if (cut === -1 || Buffer.byteLength(name.slice(cut + 1)) > 100 || Buffer.byteLength(name.slice(0, cut)) > 155) throw new Error(`${name} does not fit a ustar header`);
      prefix = name.slice(0, cut);
      name = name.slice(cut + 1);
    }
    header.write(name, 0, 100, 'utf8');
    header.write('0000644\0', 100, 8, 'utf8');
    header.write('0000000\0', 108, 8, 'utf8');
    header.write('0000000\0', 116, 8, 'utf8');
    header.write(`${file.bytes.length.toString(8).padStart(11, '0')}\0`, 124, 12, 'utf8');
    header.write('00000000000\0', 136, 12, 'utf8');
    header.write('        ', 148, 8, 'utf8');
    header.write('0', 156, 1, 'utf8');
    header.write('ustar\0', 257, 6, 'utf8');
    header.write('00', 263, 2, 'utf8');
    header.write(prefix, 345, 155, 'utf8');
    let sum = 0;
    for (const byte of header) sum += byte;
    header.write(`${sum.toString(8).padStart(6, '0')}\0 `, 148, 8, 'utf8');
    blocks.push(header, file.bytes, Buffer.alloc((512 - (file.bytes.length % 512)) % 512, 0));
  }
  blocks.push(Buffer.alloc(1024, 0));
  return gzipSync(Buffer.concat(blocks), { level: 9 });
}

function filesUnder(root, relativeDir) {
  const out = [];
  const walk = (dir) => {
    for (const entry of readdirSync(join(root, dir), { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = `${dir}/${entry.name}`;
      if (entry.isDirectory()) walk(rel);
      else out.push({ path: rel, bytes: readFileSync(join(root, rel)) });
    }
  };
  walk(relativeDir);
  return out;
}

/**
 * Every way a dossier can fail to be this candidate's, as a list of problems.
 * Pure: the caller supplies the bytes, however it obtained them.
 *
 * @param {{
 *   inventory: ReadonlyArray<{name: string, role: string}>,
 *   assets: ReadonlyArray<{name: string, bytes: Buffer}>,
 *   expected: {repository: string, sha: string, tag: string, coreVersion: string, packageFormatVersion: string,
 *              codeDigest: string, manifestDigest: string, campaignId: string,
 *              producers: Record<string, string>, receiptSha256: string|null},
 * }} input
 * @returns {string[]}
 */
export function dossierProblems({ inventory, assets, expected }) {
  const problems = [];
  const byName = new Map();
  for (const asset of assets) {
    if (byName.has(asset.name)) problems.push(`${asset.name} appears more than once`);
    byName.set(asset.name, asset);
  }
  const wanted = new Set(inventory.map((entry) => entry.name));
  for (const name of wanted) if (!byName.has(name)) problems.push(`${name} is missing`);
  for (const name of byName.keys()) if (!wanted.has(name)) problems.push(`${name} is not in the dossier inventory ${DOSSIER_INVENTORY_VERSION}`);
  for (const asset of assets) if (asset.bytes.length === 0) problems.push(`${asset.name} is empty`);

  // The sums, strictly, and against the bytes.
  const sumsAsset = byName.get(SUMS_NAME);
  if (sumsAsset !== undefined) {
    const sums = parseSums(sumsAsset.bytes.toString('utf8'));
    problems.push(...sums.problems);
    for (const asset of assets) {
      if (asset.name === SUMS_NAME) continue;
      const declared = sums.entries.get(asset.name);
      if (declared === undefined) {
        problems.push(`${SUMS_NAME} does not name ${asset.name}`);
        continue;
      }
      const actual = sha256(asset.bytes);
      if (actual !== declared) problems.push(`${asset.name} hashes ${actual.slice(0, 16)} and ${SUMS_NAME} says ${declared.slice(0, 16)}`);
    }
    for (const name of sums.entries.keys()) if (!byName.has(name)) problems.push(`${SUMS_NAME} names ${name}, which is not here`);
  }

  const json = (name) => {
    const asset = byName.get(name);
    if (asset === undefined) return null;
    try {
      return JSON.parse(asset.bytes.toString('utf8'));
    } catch (error) {
      problems.push(`${name} is not JSON: ${String(error.message)}`);
      return null;
    }
  };

  // The delivery manifest: the candidate it names is the one measured, and
  // the assets it lists are the ones here, byte for byte.
  const manifest = json(DOSSIER_MANIFEST_NAME);
  if (manifest !== null) {
    if (manifest.artifactKind !== DOSSIER_MANIFEST_KIND) problems.push(`${DOSSIER_MANIFEST_NAME} is a ${String(manifest.artifactKind)}, not a ${DOSSIER_MANIFEST_KIND}`);
    if (manifest.dossierInventoryVersion !== DOSSIER_INVENTORY_VERSION) problems.push(`${DOSSIER_MANIFEST_NAME} follows inventory ${String(manifest.dossierInventoryVersion)}, this verifier ${DOSSIER_INVENTORY_VERSION}`);
    if (manifest.controlFlowTestOnly === true && expected.controlFlowTestOnly !== true) problems.push(`${DOSSIER_MANIFEST_NAME} is marked CONTROL_FLOW_TEST_ONLY: a rehearsal dossier is never a release`);
    if (manifest.controlFlowTestOnly !== true && expected.controlFlowTestOnly === true) problems.push(`${DOSSIER_MANIFEST_NAME} is not marked CONTROL_FLOW_TEST_ONLY and this is a rehearsal`);
    const same = (field, value, label = field) => {
      if (manifest[field] !== value) problems.push(`${DOSSIER_MANIFEST_NAME} says ${label} ${String(manifest[field]).slice(0, 40)}, the candidate is ${String(value).slice(0, 40)}`);
    };
    same('repository', expected.repository);
    same('sha', expected.sha);
    same('tag', expected.tag);
    same('codeDigest', expected.codeDigest);
    same('manifestDigest', expected.manifestDigest);
    same('campaignId', expected.campaignId);
    if (manifest.versions?.coreVersion !== expected.coreVersion) problems.push(`${DOSSIER_MANIFEST_NAME} says core ${String(manifest.versions?.coreVersion)}, the candidate is ${expected.coreVersion}`);
    if (manifest.versions?.packageFormatVersion !== expected.packageFormatVersion) problems.push(`${DOSSIER_MANIFEST_NAME} says package format ${String(manifest.versions?.packageFormatVersion)}, the candidate is ${expected.packageFormatVersion}`);
    const declaredProducers = manifest.producers ?? {};
    for (const [producer, fingerprint] of Object.entries(expected.producers)) {
      if (declaredProducers[producer] !== fingerprint) problems.push(`${DOSSIER_MANIFEST_NAME} records ${producer} at ${String(declaredProducers[producer]).slice(0, 16)}, the candidate measures ${fingerprint.slice(0, 16)}`);
    }
    for (const producer of Object.keys(declaredProducers)) {
      if (!(producer in expected.producers)) problems.push(`${DOSSIER_MANIFEST_NAME} records a producer the candidate does not declare: ${producer}`);
    }
    const listed = Array.isArray(manifest.assets) ? manifest.assets : [];
    const listedNames = new Set(listed.map((entry) => entry.name));
    for (const entry of listed) {
      if (entry.name === DOSSIER_MANIFEST_NAME || entry.name === SUMS_NAME) {
        problems.push(`${DOSSIER_MANIFEST_NAME} lists ${entry.name}, which it must not`);
        continue;
      }
      const asset = byName.get(entry.name);
      if (asset === undefined) {
        problems.push(`${DOSSIER_MANIFEST_NAME} lists ${String(entry.name)}, which is not here`);
        continue;
      }
      if (asset.bytes.length !== entry.bytes) problems.push(`${entry.name} is ${String(asset.bytes.length)} bytes, ${DOSSIER_MANIFEST_NAME} says ${String(entry.bytes)}`);
      if (sha256(asset.bytes) !== entry.sha256) problems.push(`${entry.name} hashes differently from what ${DOSSIER_MANIFEST_NAME} records`);
      const role = inventory.find((item) => item.name === entry.name)?.role;
      if (role !== undefined && entry.role !== role) problems.push(`${entry.name} is listed as ${String(entry.role)}, the inventory says ${role}`);
    }
    for (const name of wanted) {
      if (name === DOSSIER_MANIFEST_NAME || name === SUMS_NAME) continue;
      if (!listedNames.has(name)) problems.push(`${DOSSIER_MANIFEST_NAME} does not list ${name}`);
    }
  }

  // Each record binds to the same candidate, in its own field.
  const candidateManifest = json('manifest.json');
  if (candidateManifest !== null && candidateManifest.codeDigest !== expected.codeDigest) problems.push(`manifest.json is for code digest ${String(candidateManifest.codeDigest).slice(0, 16)}, not ${expected.codeDigest.slice(0, 16)}`);
  if (candidateManifest !== null && candidateManifest.manifestDigest !== expected.manifestDigest) problems.push(`manifest.json carries manifest digest ${String(candidateManifest.manifestDigest).slice(0, 16)}, not ${expected.manifestDigest.slice(0, 16)}`);
  const candidateProvenance = json('provenance.json');
  if (candidateProvenance !== null && candidateProvenance.codeDigest !== expected.codeDigest) problems.push(`provenance.json is for code digest ${String(candidateProvenance.codeDigest).slice(0, 16)}`);
  const preflight = json('preflight.json');
  if (preflight !== null) {
    if (preflight.codeDigest !== expected.codeDigest) problems.push(`preflight.json is for code digest ${String(preflight.codeDigest).slice(0, 16)}`);
    if (preflight.MIGRATION_CORE_CANDIDATE_PREFLIGHT !== 'TRUE') problems.push(`preflight.json is ${String(preflight.MIGRATION_CORE_CANDIDATE_PREFLIGHT)}`);
  }
  const universe = json('universe.json');
  if (universe !== null) {
    if (universe.candidate?.codeDigest !== expected.codeDigest) problems.push(`universe.json is for code digest ${String(universe.candidate?.codeDigest).slice(0, 16)}`);
    if (universe.passed !== true) problems.push('universe.json did not pass');
  }
  const campaign = json('campaign.json');
  if (campaign !== null && campaign.campaignId !== expected.campaignId) problems.push(`campaign.json is campaign ${String(campaign.campaignId)}, not ${expected.campaignId}`);
  const receipt = json('ci-receipt.json');
  if (receipt !== null) {
    if (receipt.sha !== expected.sha) problems.push(`ci-receipt.json attests ${String(receipt.sha).slice(0, 12)}, not ${expected.sha.slice(0, 12)}`);
    if (receipt.repository !== expected.repository) problems.push(`ci-receipt.json is for ${String(receipt.repository)}, not ${expected.repository}`);
    if (receipt.codeDigest !== expected.codeDigest) problems.push(`ci-receipt.json is for code digest ${String(receipt.codeDigest).slice(0, 16)}`);
    const receiptAsset = byName.get('ci-receipt.json');
    if (expected.receiptSha256 !== null && receiptAsset !== undefined && sha256(receiptAsset.bytes) !== expected.receiptSha256) {
      problems.push('ci-receipt.json is not byte-identical to the receipt this verification was given');
    }
  }
  const releaseProvenance = json('migration-core-provenance.json');
  if (releaseProvenance !== null && releaseProvenance.coreVersion !== expected.coreVersion) problems.push(`migration-core-provenance.json is for core ${String(releaseProvenance.coreVersion)}`);
  const sbom = json('sbom.cdx.json');
  if (sbom !== null && sbom.bomFormat !== 'CycloneDX') problems.push(`sbom.cdx.json is ${String(sbom.bomFormat)}, not CycloneDX`);

  // The installable package is this core at this version.
  const pkg = byName.get(`kavo-migration-core-${expected.coreVersion}.tgz`);
  if (pkg !== undefined) {
    try {
      const members = tarMembers(pkg.bytes);
      const manifestBytes = members.get('package/package.json');
      if (manifestBytes === undefined) problems.push('the package tarball carries no package/package.json');
      else {
        const pkgJson = JSON.parse(manifestBytes.toString('utf8'));
        if (pkgJson.name !== 'kavo-migration-core') problems.push(`the package tarball is ${String(pkgJson.name)}`);
        if (pkgJson.version !== expected.coreVersion) problems.push(`the package tarball is version ${String(pkgJson.version)}, not ${expected.coreVersion}`);
        if (!members.has('package/dist/src/index.js')) problems.push('the package tarball carries no dist/src/index.js');
        if (!members.has('package/dist/src/index.d.ts')) problems.push('the package tarball carries no dist/src/index.d.ts');
      }
    } catch (error) {
      problems.push(`the package tarball could not be read: ${String(error.message)}`);
    }
  }
  return problems;
}

// ----------------------------------------------------------------- building

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { encoding: 'utf8', maxBuffer: 256 * 1024 * 1024, shell: process.platform === 'win32' && /^(npm|npx)$/u.test(command), ...options });
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} exited ${String(result.status)}: ${String(result.stderr ?? '').trim().slice(-400)}`);
  return result.stdout;
}

/**
 * What the clean checkout says about itself, measured — the values every
 * dossier claim is compared against.
 */
export async function candidateFacts({ repository, tag }) {
  const live = liveCandidate();
  const measured = measureTree();
  const subject = await measureSubject();
  const producers = await measureProducers();
  const campaign = readCampaign();
  const problems = [...live.problems, ...producers.problems];
  if (live.treeClean !== true) problems.push('the working tree is not clean');
  if (campaign === null) problems.push('no campaign is sealed');
  return {
    repository: repository ?? live.repository ?? normaliseRepository(process.env.GITHUB_REPOSITORY ?? ''),
    sha: live.sha,
    gitTree: live.gitTree,
    tag: tag ?? `v${versions.coreVersion}`,
    coreVersion: versions.coreVersion,
    packageFormatVersion: versions.packageFormatVersion,
    codeDigest: measured.codeDigest,
    manifestDigest: measured.manifestDigest,
    subjectDigest: subject?.subjectDigest ?? null,
    campaignId: campaign?.campaignId ?? null,
    producers: producers.fingerprints,
    problems,
  };
}

/**
 * Build the dossier into `out`, outside the tree, from this clean checkout.
 * The receipt is copied from where CI's artifact was downloaded to. The
 * delivery manifest is written after everything it lists; the sums last.
 */
export async function buildDossier({ out, receiptPath, repository, tag, now = () => new Date(), recordsDir = null }) {
  // Stand-in records are a rehearsal device: the candidate records are the
  // universe's and the gates' outputs, and a rehearsal has not run them. The
  // option is refused outside CONTROL_FLOW_TEST_ONLY, and a dossier built with
  // it is marked in its own manifest.
  const controlFlowTestOnly = recordsDir !== null;
  if (controlFlowTestOnly && process.env.KAVO_CONTROL_FLOW_TEST_ONLY !== '1') throw new Error('--records is CONTROL_FLOW_TEST_ONLY and KAVO_CONTROL_FLOW_TEST_ONLY is not 1');
  const facts = await candidateFacts({ repository, tag });
  if (facts.problems.length > 0) throw new Error(`the checkout cannot be dossiered:\n${facts.problems.map((p) => `  - ${p}`).join('\n')}`);
  const outDir = resolve(out);
  // By path segments, not by string prefix: a sibling directory whose name
  // begins with the repository's name is outside it.
  const inside = relative(repoRoot, outDir);
  if (inside === '' || (!inside.startsWith('..') && !isAbsolute(inside))) throw new Error(`the dossier is built outside the tree it describes; ${outDir} is inside ${repoRoot}`);
  if (!existsSync(receiptPath)) throw new Error(`no receipt at ${receiptPath}`);
  rmSync(outDir, { recursive: true, force: true });
  mkdirSync(outDir, { recursive: true });
  const inventory = dossierInventory({ coreVersion: facts.coreVersion, sha: facts.sha });
  const assets = [];
  const record = (name) => {
    const bytes = readFileSync(join(outDir, name));
    assets.push({ name, role: inventory.find((entry) => entry.name === name)?.role ?? null, bytes: bytes.length, sha256: sha256(bytes) });
  };

  // The package, from this checkout, into the dossier directory.
  const packed = JSON.parse(run('npm', ['pack', '--json', '--pack-destination', outDir], { cwd: repoRoot }));
  const packedName = packed[0]?.filename;
  const packageName = `kavo-migration-core-${facts.coreVersion}.tgz`;
  if (packedName !== packageName) throw new Error(`npm pack wrote ${String(packedName)}, the inventory expects ${packageName}`);
  record(packageName);

  const sourceName = `source-${facts.sha}.tar.gz`;
  run('git', ['archive', '--format=tar.gz', `--prefix=kavo-migration-core-${facts.sha}/`, '-o', join(outDir, sourceName), facts.sha], { cwd: repoRoot });
  record(sourceName);

  writeFileSync(join(outDir, 'sbom.cdx.json'), run('npm', ['sbom', '--sbom-format', 'cyclonedx', '--omit', 'dev'], { cwd: repoRoot }));
  record('sbom.cdx.json');

  const copies = [
    ['qualification/candidate/manifest.json', 'manifest.json'],
    ['qualification/candidate/provenance.json', 'provenance.json'],
    ['qualification/candidate/preflight.json', 'preflight.json'],
    ['qualification/candidate/universe.json', 'universe.json'],
    ['qualification/candidate/campaign.json', 'campaign.json'],
    ['migration-core-provenance.json', 'migration-core-provenance.json'],
  ];
  for (const [from, to] of copies) {
    const source = controlFlowTestOnly && to !== 'campaign.json' ? join(recordsDir, to) : join(repoRoot, ...from.split('/'));
    if (!existsSync(source)) throw new Error(`${controlFlowTestOnly ? source : from} is not ${controlFlowTestOnly ? 'in the records directory' : 'in the checkout'}`);
    copyFileSync(source, join(outDir, to));
    record(to);
  }
  copyFileSync(receiptPath, join(outDir, 'ci-receipt.json'));
  record('ci-receipt.json');

  writeFileSync(join(outDir, 'evidence.tar.gz'), writeTarGz([...filesUnder(repoRoot, 'qualification/evidence'), ...filesUnder(repoRoot, 'qualification/capacity')]));
  record('evidence.tar.gz');

  const builtAt = `${now().toISOString().slice(0, 19)}Z`;
  const manifest = buildDossierManifest({ ...facts, assets, builtAt, controlFlowTestOnly });
  writeFileSync(join(outDir, DOSSIER_MANIFEST_NAME), `${JSON.stringify(manifest, null, 2)}\n`);
  record(DOSSIER_MANIFEST_NAME);

  const sums = assets
    .filter((asset) => asset.name !== SUMS_NAME)
    .sort((a, b) => (a.name < b.name ? -1 : 1))
    .map((asset) => `${asset.sha256}  ${asset.name}\n`)
    .join('');
  writeFileSync(join(outDir, SUMS_NAME), sums);

  const problems = verifyLocalDossier({ dir: outDir, facts: { ...facts, controlFlowTestOnly }, receiptPath });
  return { outDir, inventory, assets: assets.map(({ name, role, bytes, sha256: digest }) => ({ name, role, bytes, sha256: digest })), problems, controlFlowTestOnly };
}

/** Read every file in a directory as a dossier asset. Subdirectories are a problem, not ignored. */
export function readDossierDir(dir) {
  const assets = [];
  const problems = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) {
      problems.push(`${name}/ is a directory; a dossier is flat`);
      continue;
    }
    assets.push({ name, bytes: readFileSync(full) });
  }
  return { assets, problems };
}

export function verifyLocalDossier({ dir, facts, receiptPath }) {
  const { assets, problems } = readDossierDir(dir);
  const receiptSha256 = receiptPath !== null && existsSync(receiptPath) ? sha256(readFileSync(receiptPath)) : null;
  const inventory = dossierInventory({ coreVersion: facts.coreVersion, sha: facts.sha });
  return [...problems, ...dossierProblems({ inventory, assets, expected: { ...facts, receiptSha256 } })];
}

// ------------------------------------------------------------------ remote

/**
 * A GitHub transport: `(path, accept) => Response`. The real one below; the
 * self-test injects one that serves a release from memory. Nothing in the
 * verification below knows which it has.
 */
export function githubTransport(token) {
  return async (path, accept = 'application/vnd.github+json') => {
    const response = await fetch(`https://api.github.com${path}`, {
      headers: {
        accept,
        'x-github-api-version': '2022-11-28',
        'user-agent': 'kavo-release-dossier',
        ...(token === null || token === '' ? {} : { authorization: `Bearer ${token}` }),
      },
      signal: AbortSignal.timeout(API_TIMEOUT_MS),
    });
    if (!response.ok) throw new Error(`GET ${path} returned ${String(response.status)} ${response.statusText}`);
    return response;
  };
}

/**
 * Read a release and every asset through the transport; the asset list is
 * paginated and its length compared with what the release object said, and
 * every asset's bytes are compared with the size the API declared.
 */
export async function readRemoteRelease({ api, repository, tagName, releaseId = null }) {
  // By tag for a published release; by id for a draft, which GitHub does not
  // serve under its tag until it is published.
  const release = await (await api(releaseId === null ? `/repos/${repository}/releases/tags/${encodeURIComponent(tagName)}` : `/repos/${repository}/releases/${String(releaseId)}`)).json();
  const listed = [];
  for (let page = 1; ; page += 1) {
    const chunk = await (await api(`/repos/${repository}/releases/${String(release.id)}/assets?per_page=${String(PAGE)}&page=${String(page)}`)).json();
    if (!Array.isArray(chunk)) throw new Error('the asset list is not an array');
    listed.push(...chunk);
    if (chunk.length < PAGE) break;
  }
  const problems = [];
  const inline = Array.isArray(release.assets) ? release.assets.length : null;
  if (inline !== listed.length) problems.push(`the release object lists ${String(inline)} assets and the paginated list ${String(listed.length)}`);
  const assets = [];
  for (const asset of listed) {
    const bytes = Buffer.from(await (await api(`/repos/${repository}/releases/assets/${String(asset.id)}`, 'application/octet-stream')).arrayBuffer());
    if (typeof asset.size === 'number' && asset.size !== bytes.length) problems.push(`${String(asset.name)} downloaded as ${String(bytes.length)} bytes and the API declares ${String(asset.size)}`);
    assets.push({ name: String(asset.name), bytes });
  }
  return { release, assets, problems };
}

/**
 * The two release conditions of the freeze, as the verdict records them.
 * Separate on purpose: a draft with a perfect dossier is `draft_ready`, not
 * frozen, and a published release with a foreign dossier is neither.
 *
 * @returns {Promise<{published: {value: boolean, observed: string}, assets: {value: boolean, observed: string}, draft: boolean}>}
 */
export async function verifyPublishedRelease({ api, repository, tagName, expectedSha, facts, receiptSha256, allowDraft = false, releaseId = null }) {
  let remote;
  try {
    remote = await readRemoteRelease({ api, repository, tagName, releaseId: allowDraft ? releaseId : null });
  } catch (error) {
    const observed = `the release could not be read: ${String(error.message)}`;
    return { published: { value: false, observed }, assets: { value: false, observed }, draft: null };
  }
  const { release, assets } = remote;
  const publishedProblems = [];
  if (release.tag_name !== tagName) publishedProblems.push(`the release is on ${String(release.tag_name)}, not ${tagName}`);
  if (release.draft !== false) publishedProblems.push(release.draft === true ? 'the release is a draft' : 'the API did not say whether the release is a draft');
  if (release.prerelease === true) publishedProblems.push('the release is marked a prerelease');
  if (release.immutable !== true) publishedProblems.push(release.immutable === false ? 'the release is not immutable' : 'the API did not report immutability; not verified');
  const inventory = dossierInventory({ coreVersion: facts.coreVersion, sha: expectedSha });
  const assetProblems = [...remote.problems, ...dossierProblems({ inventory, assets, expected: { ...facts, sha: expectedSha, tag: tagName, receiptSha256 } })];
  const draftReady = release.draft === true && allowDraft && assetProblems.length === 0;
  return {
    published: {
      value: publishedProblems.length === 0,
      observed: publishedProblems.length === 0 ? `${tagName} is published, immutable, on this tag (release ${String(release.id)})` : publishedProblems.join('; '),
    },
    assets: {
      value: assetProblems.length === 0,
      observed:
        assetProblems.length === 0
          ? `${String(assets.length)} assets downloaded, hashed against ${SUMS_NAME}, matched to inventory ${DOSSIER_INVENTORY_VERSION} and bound to ${expectedSha.slice(0, 12)}`
          : `${String(assetProblems.length)} problem(s): ${assetProblems.slice(0, 6).join('; ')}${assetProblems.length > 6 ? '; …' : ''}`,
    },
    draft: release.draft === true,
    draftReady,
    problems: { published: publishedProblems, assets: assetProblems },
  };
}

// --------------------------------------------------------------------- cli

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = process.argv.slice(2);
  const valueOf = (name) => {
    const at = args.indexOf(name);
    if (at === -1) return null;
    const value = args[at + 1];
    if (value === undefined || value.startsWith('--')) {
      process.stderr.write(`${name} needs a value\n`);
      process.exit(64);
    }
    return value;
  };
  const controlFlow = process.env.KAVO_CONTROL_FLOW_TEST_ONLY === '1';
  const mode = ['--build', '--verify', '--verify-remote'].filter((flag) => args.includes(flag));
  if (mode.length !== 1) {
    process.stderr.write('usage: node tools/release-dossier.mjs (--build --out <dir> | --verify <dir> | --verify-remote) --receipt <path> [--tag <tag>] [--repository <owner/name>] [--allow-draft]\n');
    process.exit(64);
  }
  const receiptPath = valueOf('--receipt');
  const tag = valueOf('--tag');
  const repository = valueOf('--repository');
  try {
    if (mode[0] === '--build') {
      const out = valueOf('--out');
      if (out === null || receiptPath === null) throw new Error('--build needs --out <dir> and --receipt <path>');
      const built = await buildDossier({ out, receiptPath, repository, tag, recordsDir: valueOf('--records') });
      process.stdout.write(`${JSON.stringify({ dossier: built.outDir, inventoryVersion: DOSSIER_INVENTORY_VERSION, assets: built.assets, problems: built.problems }, null, 2)}\n`);
      process.exit(built.problems.length === 0 ? 0 : 1);
    }
    if (mode[0] === '--verify') {
      const dir = valueOf('--verify');
      const facts = await candidateFacts({ repository, tag });
      if (facts.problems.length > 0) throw new Error(facts.problems.join('; '));
      const problems = verifyLocalDossier({ dir: resolve(dir), facts: { ...facts, controlFlowTestOnly: controlFlow }, receiptPath });
      process.stdout.write(`${JSON.stringify({ dossier: resolve(dir), sha: facts.sha, problems, ok: problems.length === 0 }, null, 2)}\n`);
      process.exit(problems.length === 0 ? 0 : 1);
    }
    const facts = await candidateFacts({ repository, tag });
    if (facts.problems.length > 0) throw new Error(facts.problems.join('; '));
    const token = githubToken();
    if (token === null) throw new Error('no GitHub token is available');
    const receiptSha256 = receiptPath !== null && existsSync(receiptPath) ? sha256(readFileSync(receiptPath)) : null;
    const result = await verifyPublishedRelease({ api: githubTransport(token), repository: facts.repository, tagName: facts.tag, expectedSha: facts.sha, facts: { ...facts, controlFlowTestOnly: controlFlow }, receiptSha256, allowDraft: args.includes('--allow-draft'), releaseId: valueOf('--release-id') });
    const report = { repository: facts.repository, tag: facts.tag, sha: facts.sha, draft: result.draft, draft_ready: result.draftReady === true, release_published_immutable: result.published, release_assets_verified: result.assets, problems: result.problems };
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    // Preparation never says frozen. It says whether the draft is ready.
    process.exit(result.assets.value && (result.draftReady === true || result.published.value) ? 0 : 1);
  } catch (error) {
    process.stderr.write(`${String(error.message)}\n`);
    process.exit(1);
  }
}
