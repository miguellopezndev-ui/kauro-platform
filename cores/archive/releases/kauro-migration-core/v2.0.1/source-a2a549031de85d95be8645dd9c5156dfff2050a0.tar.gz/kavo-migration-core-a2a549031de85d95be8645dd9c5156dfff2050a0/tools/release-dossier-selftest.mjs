#!/usr/bin/env node
/**
 * RELEASE-DOSSIER-01: the dossier verifier refuses every way a release can
 * fail to be this candidate's, and accepts the one way it can be.
 *
 * A synthetic candidate, a synthetic dossier built the way the real one is,
 * and a GitHub served from memory. Each case changes one thing and the
 * verifier must name it; the positive case must come back clean. The freeze
 * verdict calls the same function with the real transport, so what is proved
 * here is what the verdict does.
 *
 * No network, no token, no tree measured: the facts are fixtures. The rules
 * about the *real* tree — that the checkout is clean, that the digests
 * reproduce — are the verdict's other conditions and EVIDENCE-RULES-01's.
 */
import { gzipSync } from 'node:zlib';

import { DOSSIER_INVENTORY_VERSION, DOSSIER_MANIFEST_NAME, SUMS_NAME, buildDossierManifest, dossierInventory, dossierProblems, parseSums, sha256, verifyPublishedRelease } from './release-dossier.mjs';

const SHA = 'a'.repeat(40);
const OTHER_SHA = 'b'.repeat(40);
const TAG = 'v2.0.1';
const REPOSITORY = 'owner/kavo-migration-core';
const FACTS = Object.freeze({
  repository: REPOSITORY,
  sha: SHA,
  gitTree: 'c'.repeat(40),
  tag: TAG,
  coreVersion: '2.0.1',
  packageFormatVersion: '2.0.0',
  codeDigest: 'd'.repeat(64),
  manifestDigest: 'e'.repeat(64),
  subjectDigest: 'f'.repeat(64),
  campaignId: 'c_0123456789abcdef',
  producers: { 'tools/capacity.mjs': '1'.repeat(64), 'tools/universe.mjs': '2'.repeat(64) },
});

// ------------------------------------------------------------ synthetic tar

function tarOf(members) {
  const blocks = [];
  for (const [name, content] of Object.entries(members)) {
    const body = Buffer.from(content, 'utf8');
    const header = Buffer.alloc(512, 0);
    header.write(name, 0, 100, 'utf8');
    header.write('0000644\0', 100, 8, 'utf8');
    header.write('0000000\0', 108, 8, 'utf8');
    header.write('0000000\0', 116, 8, 'utf8');
    header.write(`${body.length.toString(8).padStart(11, '0')}\0`, 124, 12, 'utf8');
    header.write('00000000000\0', 136, 12, 'utf8');
    header.write('        ', 148, 8, 'utf8');
    header.write('0', 156, 1, 'utf8');
    header.write('ustar\0', 257, 6, 'utf8');
    header.write('00', 263, 2, 'utf8');
    let sum = 0;
    for (const byte of header) sum += byte;
    header.write(`${sum.toString(8).padStart(6, '0')}\0 `, 148, 8, 'utf8');
    blocks.push(header, body, Buffer.alloc((512 - (body.length % 512)) % 512, 0));
  }
  blocks.push(Buffer.alloc(1024, 0));
  return gzipSync(Buffer.concat(blocks));
}

const packageTgz = (version = FACTS.coreVersion, withEntry = true) =>
  tarOf({
    'package/package.json': JSON.stringify({ name: 'kavo-migration-core', version }),
    ...(withEntry ? { 'package/dist/src/index.js': 'export {};\n', 'package/dist/src/index.d.ts': 'export {};\n' } : {}),
  });

// --------------------------------------------------------- synthetic dossier

const json = (value) => Buffer.from(`${JSON.stringify(value, null, 2)}\n`, 'utf8');
const receiptBytes = json({ artifactKind: 'MIGRATION_CORE_CI_RECEIPT', repository: REPOSITORY, sha: SHA, codeDigest: FACTS.codeDigest, runId: '1' });

/**
 * The dossier as tools/release-dossier.mjs --build writes it, in memory.
 * `mutate` edits the raw assets before the delivery manifest and the sums are
 * written over them, so a mutation there is "a dossier honestly built over
 * the wrong thing"; `after` edits the finished dossier, so a mutation there
 * is "a dossier tampered with after it was sealed".
 */
function dossier({ facts = FACTS, mutate = () => {}, after = () => {}, receipt = receiptBytes } = {}) {
  const inventory = dossierInventory({ coreVersion: facts.coreVersion, sha: facts.sha });
  const raw = new Map([
    [`kavo-migration-core-${facts.coreVersion}.tgz`, packageTgz(facts.coreVersion)],
    [`source-${facts.sha}.tar.gz`, tarOf({ 'src/index.ts': 'export {};\n' })],
    ['sbom.cdx.json', json({ bomFormat: 'CycloneDX', specVersion: '1.5', components: [] })],
    ['manifest.json', json({ codeDigest: facts.codeDigest, manifestDigest: facts.manifestDigest })],
    ['provenance.json', json({ codeDigest: facts.codeDigest, manifestDigest: facts.manifestDigest })],
    ['preflight.json', json({ codeDigest: facts.codeDigest, MIGRATION_CORE_CANDIDATE_PREFLIGHT: 'TRUE', facts: {} })],
    ['universe.json', json({ candidate: { codeDigest: facts.codeDigest }, passed: true, steps: [] })],
    ['campaign.json', json({ campaignId: facts.campaignId, producers: facts.producers })],
    ['migration-core-provenance.json', json({ coreVersion: facts.coreVersion, packageFormatVersion: facts.packageFormatVersion })],
    ['ci-receipt.json', receipt],
    ['evidence.tar.gz', tarOf({ 'qualification/evidence/x.json': '{}\n' })],
  ]);
  mutate(raw);
  const assets = [...raw.entries()].map(([name, bytes]) => ({ name, role: inventory.find((entry) => entry.name === name)?.role ?? 'UNKNOWN', bytes: bytes.length, sha256: sha256(bytes) }));
  const manifest = buildDossierManifest({ ...facts, assets, builtAt: '2026-09-11T00:00:00Z' });
  raw.set(DOSSIER_MANIFEST_NAME, json(manifest));
  const sums = [...raw.entries()]
    .filter(([name]) => name !== SUMS_NAME)
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([name, bytes]) => `${sha256(bytes)}  ${name}\n`)
    .join('');
  raw.set(SUMS_NAME, Buffer.from(sums, 'utf8'));
  after(raw);
  return raw;
}

/** GitHub, from memory. `release` overrides fields; `failOn` makes one asset's download throw. */
function fakeGithub(assets, { release = {}, failOn = null, inlineCount = null } = {}) {
  const list = [...assets.entries()].map(([name, bytes], index) => ({ id: index + 1, name, size: bytes.length }));
  const body = { id: 77, tag_name: TAG, draft: false, prerelease: false, immutable: true, assets: inlineCount === null ? list : list.slice(0, inlineCount), ...release };
  const respond = (value) => ({ json: async () => value, text: async () => JSON.stringify(value), arrayBuffer: async () => value });
  const calls = [];
  const api = async (path) => {
    calls.push(path);
    if (path === `/repos/${REPOSITORY}/releases/tags/${encodeURIComponent(TAG)}`) return respond(body);
    const page = /\/releases\/77\/assets\?per_page=(\d+)&page=(\d+)$/u.exec(path);
    if (page !== null) {
      const per = Number(page[1]);
      const at = Number(page[2]);
      return respond(list.slice((at - 1) * per, at * per));
    }
    const asset = /\/releases\/assets\/(\d+)$/u.exec(path);
    if (asset !== null) {
      const entry = list[Number(asset[1]) - 1];
      if (entry === undefined) throw new Error(`GET ${path} returned 404 Not Found`);
      if (entry.name === failOn) throw new Error(`GET ${path} returned 502 Bad Gateway`);
      const bytes = assets.get(entry.name);
      return respond(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
    }
    throw new Error(`GET ${path} returned 404 Not Found`);
  };
  return { api, calls };
}

async function verify(assets, options = {}, { receipt = receiptBytes, allowDraft = false, facts = FACTS } = {}) {
  const { api } = fakeGithub(assets, options);
  return verifyPublishedRelease({ api, repository: REPOSITORY, tagName: TAG, expectedSha: SHA, facts, receiptSha256: sha256(receipt), allowDraft });
}

// ------------------------------------------------------------------- cases

const cases = [];
const record = (id, ok, expected, observed) => cases.push({ id, ok, expected, observed });

/** A negative: the release must be refused, and the refusal must mention `mentions`. */
async function refuses(id, expected, run, mentions, { publishedToo = false } = {}) {
  const result = await run();
  const text = `${result.published.observed} ${result.assets.observed} ${(result.problems?.assets ?? []).join(' ')} ${(result.problems?.published ?? []).join(' ')}`;
  const refused = publishedToo ? result.published.value === false : result.assets.value === false;
  const named = mentions === null || text.includes(mentions);
  record(id, refused && named, expected, refused ? (named ? `refused: ${text.slice(0, 160)}` : `refused, but without naming "${mentions}": ${text.slice(0, 160)}`) : `ACCEPTED: ${text.slice(0, 160)}`);
}

{
  const result = await verify(dossier());
  record('dossier.positive', result.published.value && result.assets.value && result.draft === false, 'a published, immutable release carrying exactly this candidate\'s dossier is accepted on both conditions', `${result.published.observed} | ${result.assets.observed}`);
}
await refuses('dossier.foreignWithCorrectSums', 'a dossier built honestly over another commit, sums correct, is refused', () => verify(dossier({ facts: { ...FACTS, sha: OTHER_SHA, codeDigest: '9'.repeat(64) } })), 'code digest');
await refuses('dossier.foreignReceipt', 'a receipt for another commit is refused even though the sums cover it', () => verify(dossier({ receipt: json({ repository: REPOSITORY, sha: OTHER_SHA, codeDigest: FACTS.codeDigest }) })), 'ci-receipt.json attests');
await refuses('dossier.receiptNotTheOneHanded', 'a receipt that is not byte-identical to the one the verdict was given is refused', () => verify(dossier(), {}, { receipt: json({ repository: REPOSITORY, sha: SHA, codeDigest: FACTS.codeDigest, runId: '2' }) }), 'byte-identical');
await refuses('dossier.oldManifest', 'a candidate manifest from an earlier tree is refused', () => verify(dossier({ mutate: (raw) => raw.set('manifest.json', json({ codeDigest: '3'.repeat(64), manifestDigest: FACTS.manifestDigest })) })), 'manifest.json is for code digest');
await refuses('dossier.tamperedPackageSumsUpdated', 'a package replaced after the delivery manifest was written is refused even when the sums were rewritten to match', () =>
  verify(
    dossier({
      after: (raw) => {
        raw.set(`kavo-migration-core-${FACTS.coreVersion}.tgz`, packageTgz('2.0.1', false));
        const sums = [...raw.entries()].filter(([name]) => name !== SUMS_NAME).sort(([a], [b]) => (a < b ? -1 : 1)).map(([name, bytes]) => `${sha256(bytes)}  ${name}\n`).join('');
        raw.set(SUMS_NAME, Buffer.from(sums, 'utf8'));
      },
    }),
  ), 'hashes differently');
await refuses('dossier.tamperedPackageSumsStale', 'a package changed after the sums were written is refused by the sums', () => verify(dossier({ after: (raw) => raw.set(`kavo-migration-core-${FACTS.coreVersion}.tgz`, packageTgz('2.0.1', false)) })), 'SHA256SUMS says');
await refuses('dossier.wrongPackageVersion', 'a package tarball of another version is refused', () => verify(dossier({ mutate: (raw) => raw.set(`kavo-migration-core-${FACTS.coreVersion}.tgz`, packageTgz('2.0.0')) })), 'version 2.0.0');
await refuses('dossier.packageWithoutEntry', 'a package tarball without dist/src/index.js is refused', () => verify(dossier({ mutate: (raw) => raw.set(`kavo-migration-core-${FACTS.coreVersion}.tgz`, packageTgz('2.0.1', false)) })), 'dist/src/index.js');
await refuses('dossier.missingAsset', 'a release missing one inventory asset is refused', () => verify(dossier({ after: (raw) => raw.delete('universe.json') })), 'universe.json is missing');
await refuses('dossier.extraAssetWithCorrectSum', 'an asset outside the inventory is refused even when the sums name it', () =>
  verify(
    dossier({
      after: (raw) => {
        const extra = Buffer.from('not part of any candidate\n');
        raw.set('unrelated.txt', extra);
        raw.set(SUMS_NAME, Buffer.concat([raw.get(SUMS_NAME), Buffer.from(`${sha256(extra)}  unrelated.txt\n`)]));
      },
    }),
  ), 'not in the dossier inventory');
await refuses('dossier.duplicateNames', 'two assets with the same name are refused', async () => {
  const assets = dossier();
  const { api: inner } = fakeGithub(assets);
  const dup = { id: 99, name: 'preflight.json', size: assets.get('preflight.json').length };
  const api = async (path) => {
    if (path.endsWith(`/releases/tags/${TAG}`)) {
      const release = await (await inner(path)).json();
      return { json: async () => ({ ...release, assets: [...release.assets, dup] }) };
    }
    if (/\/assets\?per_page=/u.test(path)) {
      const list = await (await inner(path)).json();
      return { json: async () => [...list, dup] };
    }
    if (path.endsWith('/assets/99')) return inner(path.replace('/99', `/${String([...assets.keys()].indexOf('preflight.json') + 1)}`));
    return inner(path);
  };
  return verifyPublishedRelease({ api, repository: REPOSITORY, tagName: TAG, expectedSha: SHA, facts: FACTS, receiptSha256: sha256(receiptBytes) });
}, 'more than once');
await refuses('dossier.downloadError', 'a failed download refuses both conditions rather than skipping the asset', () => verify(dossier(), { failOn: 'campaign.json' }), '502', { publishedToo: true });
await refuses('dossier.paginationDisagrees', 'a release object listing fewer assets than the paginated list is refused', () => verify(dossier(), { inlineCount: 3 }), 'paginated list');
await refuses('dossier.mutable', 'immutable:false is refused on the published condition', () => verify(dossier(), { release: { immutable: false } }), 'not immutable', { publishedToo: true });
await refuses('dossier.immutabilityNotReported', 'a release object without an immutable field is not verified, so refused', () => verify(dossier(), { release: { immutable: undefined } }), 'not verified', { publishedToo: true });
await refuses('dossier.wrongTag', 'a release on another tag is refused', () => verify(dossier(), { release: { tag_name: 'v2.0.0' } }), 'not v2.0.1', { publishedToo: true });
await refuses('dossier.draftIsNotPublished', 'a draft is refused on the published condition', () => verify(dossier(), { release: { draft: true } }), 'draft', { publishedToo: true });
{
  const result = await verify(dossier(), { release: { draft: true } }, { allowDraft: true });
  record('dossier.draftReadyIsNotFrozen', result.draftReady === true && result.published.value === false && result.assets.value === true, 'a draft with a complete dossier is draft_ready and still not published', `draftReady=${String(result.draftReady)} published=${String(result.published.value)} assets=${String(result.assets.value)}`);
}
await refuses('dossier.campaignMismatch', 'a campaign.json for another campaign is refused', () => verify(dossier({ mutate: (raw) => raw.set('campaign.json', json({ campaignId: 'c_fedcba9876543210' })) })), 'campaign.json is campaign');
await refuses('dossier.producerMoved', 'a delivery manifest recording a producer fingerprint the candidate does not measure is refused', () => verify(dossier(), {}, { facts: { ...FACTS, producers: { ...FACTS.producers, 'tools/capacity.mjs': '4'.repeat(64) } } }), 'records tools/capacity.mjs');
await refuses('dossier.manifestListsItself', 'a delivery manifest that lists itself is refused', () =>
  verify(
    dossier({
      after: (raw) => {
        const manifest = JSON.parse(raw.get(DOSSIER_MANIFEST_NAME).toString('utf8'));
        manifest.assets.push({ name: DOSSIER_MANIFEST_NAME, role: 'DELIVERY_MANIFEST', bytes: 1, sha256: '0'.repeat(64) });
        raw.set(DOSSIER_MANIFEST_NAME, json(manifest));
        const sums = [...raw.entries()].filter(([name]) => name !== SUMS_NAME).sort(([a], [b]) => (a < b ? -1 : 1)).map(([name, bytes]) => `${sha256(bytes)}  ${name}\n`).join('');
        raw.set(SUMS_NAME, Buffer.from(sums, 'utf8'));
      },
    }),
  ), 'which it must not');
await refuses('dossier.universeFailed', 'a universe report that did not pass is refused', () => verify(dossier({ mutate: (raw) => raw.set('universe.json', json({ candidate: { codeDigest: FACTS.codeDigest }, passed: false })) })), 'did not pass');
await refuses('dossier.releaseUnreadable', 'an unreadable release refuses both conditions', async () => verifyPublishedRelease({ api: async () => { throw new Error('GET returned 500'); }, repository: REPOSITORY, tagName: TAG, expectedSha: SHA, facts: FACTS, receiptSha256: null }), 'could not be read', { publishedToo: true });

// The sums parser, line by line.
const sumsCases = [
  ['sums.crlf', `${'a'.repeat(64)}  x.json\r\n`, 'carriage return'],
  ['sums.blankLine', `${'a'.repeat(64)}  x.json\n\n${'b'.repeat(64)}  y.json\n`, 'blank'],
  ['sums.noFinalNewline', `${'a'.repeat(64)}  x.json`, 'newline'],
  ['sums.oneSpace', `${'a'.repeat(64)} x.json\n`, 'not "<sha256>  <name>"'],
  ['sums.path', `${'a'.repeat(64)}  dir/x.json\n`, 'path'],
  ['sums.binaryMarker', `${'a'.repeat(64)}  *x.json\n`, 'marker'],
  ['sums.duplicate', `${'a'.repeat(64)}  x.json\n${'b'.repeat(64)}  x.json\n`, 'second time'],
  ['sums.self', `${'a'.repeat(64)}  ${SUMS_NAME}\n`, 'itself'],
  ['sums.uppercaseHex', `${'A'.repeat(64)}  x.json\n`, 'not "<sha256>  <name>"'],
  ['sums.empty', '', 'empty'],
];
for (const [id, text, mentions] of sumsCases) {
  const parsed = parseSums(text);
  record(id, parsed.problems.length > 0 && parsed.problems.some((problem) => problem.includes(mentions)), `refused, naming "${mentions}"`, parsed.problems.join('; ') || 'ACCEPTED');
}
{
  const parsed = parseSums(`${'a'.repeat(64)}  x.json\n${'b'.repeat(64)}  y.tgz\n`);
  record('sums.wellFormed', parsed.problems.length === 0 && parsed.entries.size === 2, 'a well-formed file parses to its two entries', parsed.problems.join('; ') || `${String(parsed.entries.size)} entries`);
}
{
  const inventory = dossierInventory({ coreVersion: '2.0.1', sha: SHA });
  const names = inventory.map((entry) => entry.name);
  record('inventory.namesUnique', new Set(names).size === names.length && names.includes(SUMS_NAME) && names.includes(DOSSIER_MANIFEST_NAME), 'the inventory names are unique and include the sums and the delivery manifest', names.join(', '));
  let threw = false;
  try {
    dossierInventory({ coreVersion: '2.0.1', sha: 'abc' });
  } catch {
    threw = true;
  }
  record('inventory.refusesShortSha', threw, 'an inventory cannot be made for a commit that is not 40 hex characters', threw ? 'refused' : 'ACCEPTED');
}
{
  // dossierProblems is what both the verdict and --verify call; an empty asset list is every asset missing, never "nothing to check".
  const problems = dossierProblems({ inventory: dossierInventory({ coreVersion: '2.0.1', sha: SHA }), assets: [], expected: { ...FACTS, receiptSha256: null } });
  record('dossier.emptyIsNotClean', problems.length >= 13, 'an empty release is refused for every missing asset', `${String(problems.length)} problems`);
}

// ------------------------------------------------------------------ report

const failures = cases.filter((entry) => !entry.ok);
process.stdout.write(`RELEASE-DOSSIER-01: ${String(cases.length)} cases, inventory ${DOSSIER_INVENTORY_VERSION}\n\n`);
for (const entry of cases) process.stdout.write(`  ${entry.ok ? 'ok   ' : 'FALSE'} ${entry.id}\n`);
for (const entry of failures) process.stdout.write(`\n  ${entry.id}\n    expected: ${entry.expected}\n    observed: ${entry.observed}\n`);
process.stdout.write(`\nRELEASE-DOSSIER-01 = ${failures.length === 0 ? 'PASS' : 'FALSE'}\n\n`);
process.stdout.write(`${JSON.stringify({ gate: 'RELEASE-DOSSIER-01', checksRun: cases.length, failures: failures.length, passed: failures.length === 0 }, null, 2)}\n`);
process.exit(failures.length === 0 ? 0 : 1);
