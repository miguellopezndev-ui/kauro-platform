import { generateKeyPairSync, sign as signBytes } from 'node:crypto';
import { hashTargetContract } from '../src/target/contract.js';
import type { HashedTargetContract } from '../src/target/contract.js';
import {
  ATTESTATION_ALGORITHM,
  ATTESTATION_CONTRACT_VERSION,
  attestationSigningBytes,
} from '../src/target/attestation.js';
import type { AttestationAuthority, TargetAttestation } from '../src/target/attestation.js';
import type { TargetMode } from '../src/domain/config.js';

/**
 * A real attestation, for a run that has no real instance behind it.
 *
 * Attestation is REQUIRED by default for the CRM modes now, and the blast
 * radius of that is everything in this repository that runs a HubSpot or
 * Salesforce plan: the golden corpus, the acceptance builders, the determinism
 * replay, the property suite, the capacity profiles and the architecture gate.
 * Every one of them was relying on the permissive default, which is precisely
 * the evidence that the permissive default was wrong.
 *
 * There were two ways to absorb that. The tempting one is to let internal
 * callers past — a flag, a test-only policy, an environment variable. It is the
 * wrong one, and not marginally: a default that every internal caller bypasses
 * is not a default, it is a comment. The check would then be exercised only by
 * the handful of tests written to exercise it, and the first plan that reached
 * production without an attestation would be the first plan anybody had ever
 * actually run that way.
 *
 * So the fixtures attest. The key pair is generated here, the signature is a
 * genuine Ed25519 signature over the canonical bytes of everything the
 * attestation asserts, and the run verifies it through exactly the code path
 * that verifies an agency's. Nothing about the check is relaxed; what changes is
 * that the harnesses stop being the reason to relax it.
 *
 * What this is NOT, said plainly because the distinction is the whole subject of
 * the seam: these contracts describe no real instance. The instance id says so
 * in words. A vendor gate builds its contract from artifacts captured against a
 * real portal or org, and a fixture proving the engine refuses an unattested run
 * is a different claim from a capture proving which instance a property export
 * came from. Neither may ever be presented as the other, and an id reading
 * `fixture-not-a-real-portal` is hard to mistake for one that is.
 */

interface FixtureInstance {
  readonly instanceId: string;
  readonly instanceLabel: string;
}

const FIXTURE_INSTANCE: Readonly<Record<string, FixtureInstance>> = {
  HUBSPOT: { instanceId: 'fixture-not-a-real-portal', instanceLabel: 'fixture instance, no HubSpot portal' },
  SALESFORCE: { instanceId: 'fixture-not-a-real-org', instanceLabel: 'fixture instance, no Salesforce org' },
};

const ARTIFACT = { path: 'fixture/contract.json', sha256: '0'.repeat(64), byteLength: 0 } as const;

/**
 * Fixed instants, never the clock.
 *
 * Freshness is judged against an instant the caller passes in, which is the
 * design that lets a run be replayed years later and still mean the same thing.
 * A fixture that took `capturedAt` from the clock would produce different bytes
 * on every run, and the determinism replay would fail for a reason that has
 * nothing to do with the engine.
 */
const CAPTURED_AT = '2026-09-01T00:00:00Z';
const EXPIRES_AT = '2027-09-01T00:00:00Z';
const INSTANT = '2026-09-04T00:00:00Z';

export interface FixtureAttestation {
  readonly targetContract: HashedTargetContract;
  readonly targetAttestation: TargetAttestation;
  readonly attestationAuthorities: readonly AttestationAuthority[];
  readonly attestationInstant: string;
}

/**
 * Signs a contract somebody else built.
 *
 * Used where the caller's contract is part of what is being tested — the
 * architecture gate shapes one for the fixture it is about to run, and should go
 * on doing so. What it needs from here is only the signature, the key and the
 * instant, which is the part a host supplies rather than a plan.
 */
export function attestContract(contract: HashedTargetContract): Omit<FixtureAttestation, 'targetContract'> {
  const issuer = generateKeyPairSync('ed25519');
  const instance = contract.contract.instance;
  const body: Omit<TargetAttestation, 'signature'> = {
    attestationVersion: ATTESTATION_CONTRACT_VERSION,
    issuer: { id: 'kavo:fixture', name: 'Kavo fixture issuer', keyId: 'fixture-1' },
    subject: { mode: instance.mode, instanceId: instance.instanceId, instanceLabel: instance.instanceLabel },
    artifacts: contract.contract.artifacts.map((artifact) => ({
      path: artifact.path,
      sha256: artifact.sha256,
      byteLength: artifact.byteLength,
    })),
    contractHash: contract.contractHash,
    schemaVersion: '1.0.0',
    toolVersion: 'kavo-fixture/1.0.0',
    capturedAt: contract.contract.capturedAt,
    expiresAt: EXPIRES_AT,
    nonce: null,
  };
  const unsigned: TargetAttestation = { ...body, signature: { algorithm: ATTESTATION_ALGORITHM, value: '' } };
  const value = signBytes(null, Buffer.from(attestationSigningBytes(unsigned), 'utf8'), issuer.privateKey).toString(
    'base64',
  );
  return {
    targetAttestation: { ...body, signature: { algorithm: ATTESTATION_ALGORITHM, value } },
    attestationAuthorities: [
      {
        issuerId: body.issuer.id,
        keyId: body.issuer.keyId,
        algorithm: ATTESTATION_ALGORITHM,
        publicKeyPem: issuer.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
      },
    ],
    attestationInstant: INSTANT,
  };
}

/** A contract for a fixture instance of this mode, and a signature over it. */
export function fixtureAttestation(mode: TargetMode): FixtureAttestation {
  const instance = FIXTURE_INSTANCE[mode];
  if (instance === undefined) {
    throw new Error(`${mode} addresses no destination instance, so it takes no attestation`);
  }
  const contract = hashTargetContract({
    contractVersion: '1.0.0',
    parserVersion: '1.0.0',
    capturedAt: CAPTURED_AT,
    instance: { mode, instanceId: instance.instanceId, instanceLabel: instance.instanceLabel, evidence: 'ARTIFACT' },
    artifacts: [{ ...ARTIFACT, kind: 'DESCRIBE' }],
    objects: [],
    pipelines: [],
  });
  return { targetContract: contract, ...attestContract(contract) };
}

/**
 * What a run of this mode needs adding to its input, and nothing more.
 *
 * CLEAN_ONLY gets an empty object rather than an explicit policy. Its policy is
 * NOT_APPLICABLE and stating it would be refused as a contradiction, which is
 * the behaviour the seam is supposed to have: a clean-only run addresses no
 * instance, so there is nothing for an attestation to be required of and nothing
 * for it to be excused from either.
 */
export function attestationFor(mode: TargetMode): Partial<FixtureAttestation> {
  if (mode === 'CLEAN_ONLY') return {};
  return fixtureAttestation(mode);
}
