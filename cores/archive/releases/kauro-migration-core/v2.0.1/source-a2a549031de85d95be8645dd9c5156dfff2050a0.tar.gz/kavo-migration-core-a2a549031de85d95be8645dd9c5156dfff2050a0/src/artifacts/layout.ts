import { CoreInvariantError } from '../util/assert.js';

/**
 * Where each artifact lives inside a package.
 *
 * Package format 2.0.0 separates the four things a package is for, physically
 * rather than by convention:
 *
 * ```text
 * 01_IMPORT/          what the operator feeds to the destination
 * 02_EXCEPTIONS/      what did not go, and why, for someone to act on
 * 03_TRACEABILITY/    what Kavo did, for someone to prove
 * 04_DOCUMENTATION/   what a person reads
 * manifest.json
 * ```
 *
 * In 1.1.0 all of these sat in one flat directory, so the file an operator must
 * import and the file that exists only to prove what happened looked alike. An
 * operator who imported the wrong one would have loaded Kavo's bookkeeping into
 * their CRM. The directory is the safeguard: everything under `01_IMPORT` is
 * meant to be imported, and nothing outside it is.
 *
 * The rest of the engine goes on naming artifacts by what they are — the
 * verifier asks for `leftovers.csv`, not for its address — and this module is
 * the single place that knows where that lands. A name with no area here is a
 * mistake rather than a default, because a new artifact that silently landed at
 * the package root would be a new file the operator cannot classify.
 */
export const IMPORT_AREA = '01_IMPORT';
export const EXCEPTIONS_AREA = '02_EXCEPTIONS';
export const TRACEABILITY_AREA = '03_TRACEABILITY';
export const DOCUMENTATION_AREA = '04_DOCUMENTATION';

const AREAS = [EXCEPTIONS_AREA, TRACEABILITY_AREA, DOCUMENTATION_AREA] as const;

/**
 * Which area each artifact belongs to.
 *
 * An artifact is an exception when a person has to decide something about it: a
 * row that reached no destination, a field nothing mapped, a relationship whose
 * endpoint was never found, a pair that looked like one record and was not
 * merged. It is traceability when it is evidence of what the run did: lineage,
 * changes, flags, merges, matching decisions, the reconciliation and the exact
 * configuration the run was given.
 */
const AREA_BY_NAME = new Map<string, string>([
  // 02_EXCEPTIONS — someone has to look at these.
  ['isolated.csv', EXCEPTIONS_AREA],
  ['leftovers.csv', EXCEPTIONS_AREA],
  ['rejected-input.csv', EXCEPTIONS_AREA],
  ['unmapped-fields.csv', EXCEPTIONS_AREA],
  ['unresolved-associations.csv', EXCEPTIONS_AREA],
  ['destination-conflicts.csv', EXCEPTIONS_AREA],
  ['duplicate-candidates.csv', EXCEPTIONS_AREA],
  ['formula-risk.csv', EXCEPTIONS_AREA],

  // 03_TRACEABILITY — what happened, so it can be proved.
  ['source-lineage.csv', TRACEABILITY_AREA],
  ['import-crosswalk.csv', TRACEABILITY_AREA],
  ['changes.csv', TRACEABILITY_AREA],
  ['flags.csv', TRACEABILITY_AREA],
  ['associations.csv', TRACEABILITY_AREA],
  ['destination-matching.csv', TRACEABILITY_AREA],
  ['instance-verification.csv', TRACEABILITY_AREA],
  ['merges.json', TRACEABILITY_AREA],
  ['reconciliation.json', TRACEABILITY_AREA],
  ['config.normalized.json', TRACEABILITY_AREA],

  // 04_DOCUMENTATION — what a person reads.
  ['audit.md', DOCUMENTATION_AREA],
  ['import-instructions.md', DOCUMENTATION_AREA],
]);

/** The manifest names every other artifact, so it sits above all of them. */
export const MANIFEST_PATH = 'manifest.json';

/**
 * The path an artifact is written to and read from, given what it is called.
 *
 * A name that already carries a directory is already a path — import files are
 * addressed by the vendor layout the operator sees, not by a lookup here.
 */
export function packagePath(name: string): string {
  if (name.includes('/')) return name;
  if (name === MANIFEST_PATH) return name;
  const area = AREA_BY_NAME.get(name);
  if (area === undefined) {
    throw new CoreInvariantError(
      'PACKAGE_LAYOUT_COMPLETE',
      `${name} belongs to no area of the package layout`,
      { name },
    );
  }
  return `${area}/${name}`;
}

/**
 * The name an artifact is known by, given where it was found.
 *
 * The inverse of `packagePath` for everything the layout places, and the
 * identity for import files, which are addressed by their path everywhere.
 */
export function logicalName(path: string): string {
  for (const area of AREAS) {
    const prefix = `${area}/`;
    if (path.startsWith(prefix)) return path.slice(prefix.length);
  }
  return path;
}

/** Every artifact this layout knows how to place, by name. */
export function placedArtifactNames(): readonly string[] {
  return [...AREA_BY_NAME.keys()];
}
