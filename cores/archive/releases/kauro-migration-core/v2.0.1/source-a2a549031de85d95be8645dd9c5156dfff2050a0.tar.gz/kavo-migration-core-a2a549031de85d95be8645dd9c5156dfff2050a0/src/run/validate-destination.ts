import { MigrationError } from '../domain/errors.js';
import type { MigrationConfig } from '../domain/config.js';
import { isCanonicalField, isCustomField } from '../domain/canonical.js';
import type { CanonicalFieldName } from '../domain/canonical.js';
import type { DestinationAdapter } from '../adapters/adapter.js';
import { requireObjectSpec, vendorHeader } from '../adapters/adapter.js';
import type { ResolvedRecord } from '../identity/resolve-identity.js';
import type { DestinationConflictEntry, FormulaRiskEntry, InstanceVerificationEntry } from '../reconcile/truth.js';
import { by, onString, sorted } from '../util/sorting.js';
import { compareCodeUnits } from '../util/json.js';
import type { ScratchStore } from '../scratch/scratch-store.js';
import type { SpooledFamily } from './spool.js';
import { mapFamily, openFamily, orderKey, orderText } from './spool.js';
import { carriesValue, intendedValue, omit } from '../domain/value-intent.js';

export interface DestinationValidationResult {
  /**
   * The records this stage was given, in the migration-key order they arrived
   * in, seen through what it decided about them.
   *
   * A projection over the family identity wrote, not a family of its own: this
   * stage changes one field of some records and changes no record's key, so a
   * second copy in the same order would be the same bytes under a different
   * name. Reading it walks the records segment and applies the decisions on the
   * way past.
   */
  readonly records: SpooledFamily<ResolvedRecord>;
  readonly conflicts: readonly DestinationConflictEntry[];
  readonly instanceVerification: readonly InstanceVerificationEntry[];
  readonly formulaRisks: readonly FormulaRiskEntry[];
}

/**
 * Offline destination validation.
 *
 * Everything checked here is decidable from files alone. Anything that depends
 * on the customer's own account is reported as requiring verification rather
 * than asserted, because a guarantee the engine cannot see is not a guarantee.
 */
export function validateDestination(
  records: SpooledFamily<ResolvedRecord>,
  config: MigrationConfig,
  adapter: DestinationAdapter,
  scratch: ScratchStore,
): DestinationValidationResult {
  assertMappingsAreDeliverable(config, adapter);

  const mode = config.target.importMode;
  const creates = mode === 'CREATE_ONLY' || mode === 'UPSERT';

  // Applied as the records are read, and not written down again.
  //
  // This stage used to spill a 'records-validated' family: every record read
  // from the family identity had just sealed, validated, and written back out
  // under `record.migrationKey` -- the key it had already been written under.
  // The instrumentation caught it: 'records', 'records-validated' and
  // 'records-after-conflicts' were three families of exactly the same byte
  // length, 26.4% of everything the run spilled, holding the same records in
  // the same order.
  //
  // A re-spill earns its bytes when it changes the order. This one cannot:
  // validation never touches the migration key, so re-sorting by that key
  // reproduces the order it was given (the external sort's tie-break is input
  // position, and the input was already in key order). What it changes is one
  // field of some records, and a projection says that without a second copy of
  // the family.
  //
  // The cost, stated: the projection is lazy, so `validateOne` runs once per
  // record per pass over the result rather than once in total. It is a pure
  // function of the record, the config and the adapter, so every pass produces
  // the same answer; what it buys is that the records are read from the one
  // segment that holds them instead of from a third copy of it.
  const validateOne = (record: ResolvedRecord): ResolvedRecord => {
    if (record.isolation !== null) return record;
    const spec = requireObjectSpec(adapter, record.object, `record ${record.migrationKey}`);

    // Can this destination be told to empty a field it already holds?
    //
    // Only asked where the import may touch an existing record. Creating a
    // record has no previous value to remove, so an authorized clear is
    // satisfied by the field simply having no value — and the traceability
    // still records that the plan asked for it.
    const clearMayApply = mode !== 'CREATE_ONLY';
    if (clearMayApply && adapter.clearRepresentation.kind === 'NOT_REPRESENTABLE') {
      const cleared = sorted(
        [...record.values.entries()]
          .filter(([, resolved]) => resolved.intent.kind === 'CLEAR')
          .map(([fieldName]) => fieldName),
        compareCodeUnits,
      );
      if (cleared.length > 0) {
        return withIsolation(
          record,
          'TARGET_CLEAR_NOT_REPRESENTABLE',
          `the plan authorizes clearing ${cleared.map((name) => `"${name}"`).join(', ')} and ${adapter.mode} cannot express that through this import path: ${adapter.clearRepresentation.reason}`,
          cleared[0] ?? null,
        );
      }
    }

    // Where a clear is expressed by a token, no delivered value may be that
    // token, or the file would say "remove this" when the source said the
    // token. Refusing is exact; escaping would make the format depend on the
    // data it carries.
    if (adapter.clearRepresentation.kind === 'EXPLICIT_TOKEN') {
      const token = adapter.clearRepresentation.token;
      for (const [fieldName, resolved] of sorted([...record.values.entries()], by(onString(([name]) => name)))) {
        if (intendedValue(resolved.intent) === token) {
          return withIsolation(
            record,
            'TARGET_CLEAR_TOKEN_COLLISION',
            `"${fieldName}" holds exactly ${token}, which this format reserves for an authorized clear; delivering it would be indistinguishable from an instruction to empty the field`,
            fieldName,
          );
        }
      }
    }

    for (const [fieldName, resolved] of record.values) {
      if (!isCanonicalField(fieldName)) continue;
      const header = vendorHeader(spec, fieldName);
      if (header?.maxLength == null) continue;
      const value = intendedValue(resolved.intent);
      if (value !== null && value.length > header.maxLength) {
        return withIsolation(
          record,
          'DESTINATION_VALUE_TOO_LONG',
          `"${fieldName}" holds ${String(value.length)} characters; ${adapter.mode} accepts at most ${String(header.maxLength)} in ${header.header}`,
        );
      }
    }

    if (creates) {
      for (const required of spec.requiredForCreate) {
        if (!carriesValue(record.values.get(required)?.intent ?? omit('NO_VALUE_PRODUCED'))) {
          return withIsolation(
            record,
            'DESTINATION_REQUIRED_FIELD_MISSING',
            `${adapter.mode} requires ${required} to create a ${record.object}, and this record has no value for it`,
            required,
          );
        }
      }
      for (const group of spec.requiredAnyOf) {
        const satisfied = group.some((field) => carriesValue(record.values.get(field)?.intent ?? omit('NO_VALUE_PRODUCED')));
        if (!satisfied) {
          return withIsolation(
            record,
            'DESTINATION_REQUIRED_FIELD_MISSING',
            `${adapter.mode} requires at least one of ${group.join(' or ')} to create a ${record.object}`,
            group[0] ?? null,
          );
        }
      }
    }

    return record;
  };
  const validated = mapFamily(records, validateOne);

  const { records: afterConflicts, conflicts } = applyDestinationKeyConflicts(
    validated,
    config,
    adapter,
    scratch,
  );

  const formulaRisks: FormulaRiskEntry[] = [];
  for (const record of afterConflicts) {
    if (record.isolation !== null) continue;
    for (const [fieldName, resolved] of sorted([...record.values.entries()], by(onString(([name]) => name)))) {
      const value = intendedValue(resolved.intent);
      if (value === null || !startsLikeFormula(value)) continue;
      formulaRisks.push({
        target: adapter.mode,
        object: record.object,
        migrationKey: record.migrationKey,
        destinationField: fieldName,
        value,
        reasonCode: 'DESTINATION_FORMULA_RISK_VALUE',
      });
    }
  }

  return {
    records: afterConflicts,
    conflicts,
    instanceVerification: adapter.instanceVerification.map((item) => ({
      scope: item.scope,
      detail: item.detail,
      sourceUrl: item.sourceUrl,
      reasonCode: 'DESTINATION_INSTANCE_VERIFICATION_REQUIRED' as const,
    })),
    formulaRisks: sorted(
      formulaRisks,
      by(onString((entry) => entry.migrationKey), onString((entry) => entry.destinationField)),
    ),
  };
}

/**
 * Every mapped destination field must have somewhere to go. A canonical field
 * the destination does not define is a configuration error, not something to drop.
 */
function assertMappingsAreDeliverable(config: MigrationConfig, adapter: DestinationAdapter): void {
  for (const mapping of config.records) {
    const spec = requireObjectSpec(
      adapter,
      mapping.object,
      `record mapping "${mapping.id}"`,
    );

    if (!spec.supportedModes.includes(config.target.importMode)) {
      throw new MigrationError(
        'DESTINATION_MODE_UNSUPPORTED',
        `${adapter.mode} does not support ${config.target.importMode} for ${mapping.object}`,
        `Supported modes are: ${spec.supportedModes.join(', ')}. ${spec.notes.join(' ')}`,
        {
          mode: adapter.mode,
          recordMappingId: mapping.id,
          importMode: config.target.importMode,
          supportedModes: [...spec.supportedModes],
          reasonCode: 'DESTINATION_MODE_UNSUPPORTED',
        },
      );
    }

    const targets = [
      ...mapping.fields.map((field) => field.destinationField),
      ...mapping.fields
        .map((field) => field.options.extensionDestinationField)
        .filter((value): value is string => value !== null),
    ];

    for (const target of targets) {
      if (isCustomField(target)) continue;
      if (!isCanonicalField(target)) continue;
      if (vendorHeader(spec, target as CanonicalFieldName) === null) {
        throw new MigrationError(
          'DESTINATION_FIELD_UNKNOWN',
          `${adapter.mode} has no documented import column for "${target}"`,
          `Map this column to a "custom:" field whose header matches a property you have created in the destination, or remove the mapping. Fields this adapter can deliver: ${spec.fields
            .map((entry) => entry.canonicalField)
            .join(', ')}.`,
          { mode: adapter.mode, recordMappingId: mapping.id, destinationField: target },
        );
      }
    }
  }
}

/**
 * Records that would land on the same destination record, found without an
 * index of every record.
 *
 * For each key the destination matches on, every record that carries a value
 * for it is written down under that value and read back in value order, so the
 * records that collide arrive together and only a colliding group is held.
 */
function applyDestinationKeyConflicts(
  records: SpooledFamily<ResolvedRecord>,
  config: MigrationConfig,
  adapter: DestinationAdapter,
  scratch: ScratchStore,
): { records: SpooledFamily<ResolvedRecord>; conflicts: readonly DestinationConflictEntry[] } {
  const conflicts: DestinationConflictEntry[] = [];
  const isolateKeys = new Map<string, DestinationConflictEntry>();

  for (const spec of adapter.objects) {
    for (const keyField of spec.destinationMatchingKeys) {
      const shared = openFamily<{ folded: string; migrationKey: string; rowLocatorIds: string[] }>(scratch, {
        schema: `conflict-${spec.object.toLowerCase()}-${keyField.replace(/[^A-Za-z0-9]+/gu, "-")}`,
        key: (entry) => orderKey(orderText(entry.folded), entry.migrationKey),
      });
      for (const record of records) {
        if (record.isolation !== null) continue;
        if (record.object !== spec.object) continue;
        const value = intendedValue(record.values.get(keyField)?.intent ?? omit('NO_VALUE_PRODUCED'));
        if (isBlank(value)) continue;
        // Destination matching on these keys is case-insensitive at both CRM destinations.
        shared.add({
          folded: (value as string).toLowerCase(),
          migrationKey: record.migrationKey,
          rowLocatorIds: record.members.map((member) => member.address.rowLocatorId),
        });
      }

      for (const [value, bucket] of collisionsOf(shared.seal())) {
        if (bucket.length < 2) continue;
        const entry: DestinationConflictEntry = {
          object: spec.object,
          keyField,
          keyValue: value,
          migrationKeys: sorted(bucket.map((entry) => entry.migrationKey), compareCodeUnits),
          rowLocatorIds: sorted(
            bucket.flatMap((entry) => entry.rowLocatorIds),
            compareCodeUnits,
          ),
          reasonCode: 'DESTINATION_KEY_CONFLICT',
          detail: `${adapter.mode} matches ${spec.object} records on ${keyField}; ${String(bucket.length)} records the source proves to be different share the value "${value}", so importing them would merge them`,
        };
        conflicts.push(entry);
        if (config.policies.destinationKeyConflict === 'ISOLATE') {
          for (const entryOf of bucket) isolateKeys.set(entryOf.migrationKey, entry);
        }
      }
    }
  }

  // Applied as the records are read, for the same reason the validation is.
  //
  // This wrote a 'records-after-conflicts' family: one entry per record, keyed
  // by the migration key the record was already sorted under, differing from
  // its input only in the isolation carried by whichever records collided.
  // `isolateKeys` is bounded by the collisions it found rather than by the run,
  // and it is complete before the first record is read back, so the same answer
  // is a lookup on the way past.
  const applyConflict = (record: ResolvedRecord): ResolvedRecord => {
    const conflict = isolateKeys.get(record.migrationKey);
    return conflict === undefined || record.isolation !== null
      ? record
      : withIsolation(record, 'DESTINATION_KEY_CONFLICT', conflict.detail);
  };

  return {
    records: mapFamily(records, applyConflict),
    conflicts: sorted(
      conflicts,
      by(onString((entry) => entry.object), onString((entry) => entry.keyField), onString((entry) => entry.keyValue)),
    ),
  };
}

function withIsolation(
  record: ResolvedRecord,
  reasonCode:
    | DestinationConflictEntry['reasonCode']
    | 'DESTINATION_REQUIRED_FIELD_MISSING'
    | 'DESTINATION_VALUE_TOO_LONG'
    | 'TARGET_CLEAR_NOT_REPRESENTABLE'
    | 'TARGET_CLEAR_TOKEN_COLLISION',
  detail: string,
  field: string | null = null,
): ResolvedRecord {
  return { ...record, isolation: { reasonCode, detail, field } };
}

function isBlank(value: string | null): boolean {
  return value === null || value.length === 0;
}

/**
 * Values a spreadsheet application would treat as a formula when the file is
 * double-clicked. The import file keeps the exact value; this only feeds a
 * warning artifact so the operator knows not to open it in Excel first.
 */
export function startsLikeFormula(value: string): boolean {
  const first = value[0];
  if (first === undefined) return false;
  if (first === '=' || first === '+' || first === '@' || first === '\t' || first === '\r') return true;
  if (first === '-') {
    const second = value[1];
    return second !== undefined && !/[0-9.]/u.test(second);
  }
  return false;
}

/**
 * The records sharing each destination key value, one group at a time.
 *
 * The family arrives in value order, so a group is the run of entries with the
 * same value and only that run is held.
 */
function* collisionsOf(
  shared: SpooledFamily<{ folded: string; migrationKey: string; rowLocatorIds: string[] }>,
): IterableIterator<[string, { migrationKey: string; rowLocatorIds: string[] }[]]> {
  let folded: string | null = null;
  let held: { migrationKey: string; rowLocatorIds: string[] }[] = [];
  for (const entry of shared) {
    if (entry.folded !== folded) {
      if (folded !== null && held.length > 0) yield [folded, held];
      folded = entry.folded;
      held = [];
    }
    held.push({ migrationKey: entry.migrationKey, rowLocatorIds: entry.rowLocatorIds });
  }
  if (folded !== null && held.length > 0) yield [folded, held];
}
