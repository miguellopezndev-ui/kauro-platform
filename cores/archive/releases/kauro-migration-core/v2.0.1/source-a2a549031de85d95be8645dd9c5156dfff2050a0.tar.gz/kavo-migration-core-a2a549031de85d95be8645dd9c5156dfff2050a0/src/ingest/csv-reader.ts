import { MigrationError } from '../domain/errors.js';

/**
 * RFC 4180 reader with no type inference whatsoever.
 *
 * Every field comes out as the exact characters the file contained. Leading
 * zeros, long numeric identifiers and values that look like dates are all just
 * text here; deciding what they mean is the mapping layer's job, driven by
 * configuration rather than by guessing.
 */

export interface CsvRecord {
  /** 1-based record number, counting the header as record 1. Newlines inside quoted fields do not advance it. */
  readonly recordNumber: number;
  readonly fields: readonly string[];
}

export interface CsvReadOptions {
  readonly delimiter: string;
  readonly filePath: string;
  readonly maxCellLength: number;
  readonly maxColumns: number;
  readonly maxRows: number;
}

export interface CsvReadResult {
  readonly records: readonly CsvRecord[];
  /** The line terminator the file predominantly used, kept as source evidence. */
  readonly lineTerminator: 'CRLF' | 'LF' | 'CR' | 'NONE';
}

export interface CsvScanResult {
  readonly recordCount: number;
  readonly lineTerminator: 'CRLF' | 'LF' | 'CR' | 'NONE';
}

/**
 * Called once per record while scanning.
 *
 * `fields` is reused between records. A consumer that needs a record after its
 * call returns has to copy it — which is the point: a consumer that does not
 * need to keep one never allocates an array of every record in the file.
 */
export type CsvRecordSink = (recordNumber: number, fields: readonly string[]) => void;

const QUOTE = '"';

/**
 * Read every record into an array.
 *
 * Use this when something genuinely needs the whole file at once. When it does
 * not — a row count, an order comparison, a couple of columns — use `scanCsv`,
 * which runs the identical state machine and keeps no record after the consumer
 * has looked at it. At a million rows an artifact is several hundred megabytes,
 * and the array of parsed records is the largest thing the verification builds.
 */
export function readCsv(text: string, options: CsvReadOptions): CsvReadResult {
  const records: CsvRecord[] = [];
  const { lineTerminator } = scanCsv(text, options, (recordNumber, fields) => {
    // Copied because the scanner reuses its field array.
    records.push({ recordNumber, fields: [...fields] });
  });
  return { records, lineTerminator };
}

/**
 * Read every record, handing each to `sink` and keeping none.
 *
 * This is the same reader as `readCsv` — the same state machine, the same
 * quoting rules, the same refusals, the same limits — differing only in what
 * becomes of a record once it has been read. There is deliberately not a second
 * parser: two parsers would be two definitions of what a CSV is, and the one
 * used by the verifier would eventually disagree with the one used by ingest.
 */
export function scanCsv(text: string, options: CsvReadOptions, sink: CsvRecordSink): CsvScanResult {
  const carried = newCarry();
  scanChunk(text, options, sink, carried, true);
  return { recordCount: carried.recordCount, lineTerminator: dominantTerminator(carried.crlf, carried.lf, carried.cr) };
}

/** A reader being fed a file a piece at a time. */
export interface CsvScanner {
  /** Hand it the next piece of the file, in order. */
  push(text: string): void;
  /** Say that the file has ended, and get what the whole of it said. */
  end(): CsvScanResult;
}

/**
 * Read a file that never exists in memory as one string.
 *
 * This is the same reader again — the same state machine, reached the same way —
 * fed in pieces instead of all at once. It exists because peak memory in
 * verification turned out to be governed by how much is *allocated*, not by how
 * much is kept: decoding a 450 MB artifact into one string costs 450 MB whether
 * or not a single row survives the read, and resident memory never returns to
 * the operating system once it has grown.
 *
 * The caller owns the reading and the decoding, because it owns the encoding
 * rules; this owns only what a CSV means. Pieces must arrive in order, and a
 * piece may split anything — a field, a quoted newline, a record — because the
 * unfinished record is carried as text and read again with what follows it.
 */
export function createCsvScanner(options: CsvReadOptions, sink: CsvRecordSink): CsvScanner {
  const state = newCarry();
  let ended = false;
  return {
    push(text: string): void {
      if (ended) {
        throw new MigrationError(
          'CONFIG_INVALID',
          `${options.filePath} was given more text after it had ended`,
          'Feed every piece of the file before calling end().',
          { filePath: options.filePath },
        );
      }
      if (text.length === 0) return;
      // Concatenating only when there is something to concatenate. The carry is
      // empty for all but the first piece of most records, and a needless join
      // of a whole piece is a whole piece allocated again.
      scanChunk(state.carry === '' ? text : state.carry + text, options, sink, state, false);
    },
    end(): CsvScanResult {
      ended = true;
      scanChunk(state.carry, options, sink, state, true);
      return { recordCount: state.recordCount, lineTerminator: dominantTerminator(state.crlf, state.lf, state.cr) };
    },
  };
}

/**
 * What survives from one chunk of a file to the next.
 *
 * Only the tallies and the text of the record currently being read. Everything
 * else — the fields so far, whether a quote is open, whether the field was
 * quoted — is deliberately **not** carried, because the unfinished record is
 * re-read from its first character when the next chunk arrives. Re-reading a
 * single record costs nothing and removes the entire class of bug this would
 * otherwise have: a parser whose state is threaded across a boundary is a
 * parser with two ways to be in the middle of a quoted field.
 */
interface CsvCarry {
  /** The text of the record in progress, to be re-read with what follows it. */
  carry: string;
  /** Where that text began in the file, so an offset in a message is a file offset. */
  carryOffset: number;
  recordCount: number;
  recordNumber: number;
  crlf: number;
  lf: number;
  cr: number;
}

function newCarry(): CsvCarry {
  return { carry: '', carryOffset: 0, recordCount: 0, recordNumber: 1, crlf: 0, lf: 0, cr: 0 };
}

/**
 * Read one chunk, emit the records that finished inside it, and carry the rest.
 *
 * `final` says whether anything follows. While it is false the last two
 * characters are left unread, because the reader looks one character ahead —
 * at what follows a closing quote, and at whether a carriage return is half of
 * a CRLF — and a lookahead that runs off the end of a chunk would answer "end
 * of file" when the truth is "not yet". Holding two back means every character
 * this reads has the character after it available, so a record it completes was
 * completed for the same reason it would have been in the whole file.
 */
/**
 * A copy of a piece of text that shares nothing with the text it came from.
 *
 * V8 represents  as a view onto its source, so a short string taken out
 * of a chunk keeps the whole chunk alive -- and because each chunk is built
 * from the one before it, keeping one cell of a scanned file kept the whole
 * file. A million-row artifact scanned this way cost 60 MB for as long as any
 * caller held one identifier out of it.
 *
 * The carry is the one place the chain is joined, so detaching it there is
 * enough: one copy per block read, rather than one per cell.
 */
function detached(value: string): string {
  // UTF-16, not UTF-8: a chunk boundary can fall between the halves of a
  // surrogate pair, and the carry then ends on a lone surrogate. Round-tripping
  // that through UTF-8 replaces it, which would turn a character split across
  // two blocks into a replacement character -- the one corruption a block-based
  // reader must not introduce. Copying code unit for code unit preserves it.
  return Buffer.from(value, 'utf16le').toString('utf16le');
}

function scanChunk(
  text: string,
  options: CsvReadOptions,
  sink: CsvRecordSink,
  state: CsvCarry,
  final: boolean,
): void {
  const { delimiter } = options;
  if (delimiter.length !== 1) {
    throw new MigrationError(
      'CONFIG_INVALID',
      `delimiter for ${options.filePath} must be a single character`,
      'Use one of the supported delimiters.',
      { filePath: options.filePath, delimiter },
    );
  }

  let fields: string[] = [];
  let inQuotes = false;
  let fieldWasQuoted = false;
  let recordCount = state.recordCount;
  let recordNumber = state.recordNumber;
  let crlf = state.crlf;
  let lf = state.lf;
  let cr = state.cr;
  const fileOffset = state.carryOffset;
  const limit = final ? text.length : Math.max(0, text.length - 2);
  let recordStart = 0;

  /**
   * The current field, taken as offsets into the text rather than built up a
   * character at a time.
   *
   * The obvious loop appends each character to a string, which allocates once
   * per character consumed: a 45 MB artifact produced roughly 45 million
   * intermediate strings, and the garbage that made was a quarter of the whole
   * verification. A field is almost always a contiguous run of text, so the
   * common case is one slice and no intermediate at all. `pending` is only
   * used when a quoted field carries an escaped quote, which is the one case
   * where the value is not contiguous in the source.
   */
  let segmentStart = 0;
  let pending: string | null = null;

  const takeField = (end: number): string => {
    const tail = text.slice(segmentStart, end);
    const value = pending === null ? tail : pending + tail;
    pending = null;
    return value;
  };

  /** Whether anything has been read into the current field yet, without building it. */
  const fieldIsEmpty = (end: number): boolean => (pending === null || pending.length === 0) && end <= segmentStart;

  const finishField = (end: number): void => {
    const field = takeField(end);
    if (field.length > options.maxCellLength) {
      throw new MigrationError(
        'INPUT_LIMIT_EXCEEDED',
        `${options.filePath} record ${String(recordNumber)} has a field of ${String(field.length)} characters, above the limit of ${String(options.maxCellLength)}`,
        'Raise limits.maxCellLength if this data is expected, or repair the source file.',
        {
          filePath: options.filePath,
          limit: 'maxCellLength',
          allowed: options.maxCellLength,
          actual: field.length,
          recordNumber,
        },
      );
    }
    fields.push(field);
    fieldWasQuoted = false;
    if (fields.length > options.maxColumns) {
      throw new MigrationError(
        'INPUT_LIMIT_EXCEEDED',
        `${options.filePath} record ${String(recordNumber)} has more than ${String(options.maxColumns)} columns`,
        'Raise limits.maxColumnsPerSheet if this data is expected, or repair the source file.',
        { filePath: options.filePath, limit: 'maxColumnsPerSheet', allowed: options.maxColumns, recordNumber },
      );
    }
  };

  const finishRecord = (end: number, afterTerminator: number): void => {
    finishField(end);
    sink(recordNumber, fields);
    recordCount += 1;
    fields = [];
    recordNumber += 1;
    // Where the next record begins, and the point everything before which can
    // be forgotten. Resetting the field state here is what lets an unfinished
    // record be re-read from its own first character rather than resumed.
    recordStart = afterTerminator;
    inQuotes = false;
    fieldWasQuoted = false;
    pending = null;
    if (recordCount > options.maxRows) {
      throw new MigrationError(
        'INPUT_LIMIT_EXCEEDED',
        `${options.filePath} has more than ${String(options.maxRows)} rows`,
        'Raise limits.maxRowsPerSheet if this data is expected, or split the file.',
        { filePath: options.filePath, limit: 'maxRowsPerSheet', allowed: options.maxRows },
      );
    }
  };

  for (let index = 0; index < limit; index += 1) {
    const character = text[index] as string;


  if (inQuotes) {
      if (character === QUOTE) {
        if (text[index + 1] === QUOTE) {
          // The one place a field is not contiguous: keep what has been read,
          // add the single quote the pair stands for, and start a new run after
          // it.
          pending = (pending ?? '') + text.slice(segmentStart, index) + QUOTE;
          index += 1;
          segmentStart = index + 1;
          continue;
        }
        // A closing quote must be followed by a delimiter, a line terminator or
        // the end of the file. Anything else means the file does not say where
        // the field ends, and appending the remainder would invent a value.
        const next = text[index + 1];
        if (next !== undefined && next !== delimiter && next !== '\r' && next !== '\n') {
          throw new MigrationError(
            'INPUT_CORRUPT',
            `${options.filePath} record ${String(recordNumber)} has text after a closing quote (character offset ${String(fileOffset + index + 1)})`,
            'Quote the whole field and double any quote characters inside it, as RFC 4180 requires.',
            { filePath: options.filePath, recordNumber, characterOffset: fileOffset + index + 1 },
          );
        }
        // The quoted run ends here. Close it now so the closing quote itself
        // never reaches the value, and start an empty run: the check above has
        // already established that only a delimiter, a terminator or the end of
        // the file can follow.
        pending = (pending ?? '') + text.slice(segmentStart, index);
        segmentStart = index + 1;
        inQuotes = false;
        continue;
      }
      continue;
    }

    if (character === QUOTE) {
      if (!fieldIsEmpty(index) || fieldWasQuoted) {
        throw new MigrationError(
          'INPUT_CORRUPT',
          `${options.filePath} record ${String(recordNumber)} has a quote character in the middle of a field (character offset ${String(fileOffset + index)})`,
          'Quote the whole field and double any quote characters inside it, as RFC 4180 requires.',
          { filePath: options.filePath, recordNumber, characterOffset: fileOffset + index },
        );
      }
      inQuotes = true;
      fieldWasQuoted = true;
      // The opening quote is not part of the value.
      pending = pending ?? '';
      segmentStart = index + 1;
      continue;
    }

    if (character === delimiter) {
      finishField(index);
      segmentStart = index + 1;
      continue;
    }

    if (character === '\r') {
      const end = index;
      if (text[index + 1] === '\n') {
        crlf += 1;
        index += 1;
      } else {
        cr += 1;
      }
      finishRecord(end, index + 1);
      segmentStart = index + 1;
      continue;
    }

    if (character === '\n') {
      lf += 1;
      finishRecord(index, index + 1);
      segmentStart = index + 1;
      continue;
    }
  }

  if (!final) {
    // Whatever is left is a record that has not finished. It is carried as text
    // and read again from its own first character when more of the file arrives.
    state.carry = detached(text.slice(recordStart));
    state.carryOffset = fileOffset + recordStart;
    state.recordCount = recordCount;
    state.recordNumber = recordNumber;
    state.crlf = crlf;
    state.lf = lf;
    state.cr = cr;
    return;
  }

  if (inQuotes) {
    throw new MigrationError(
      'INPUT_CORRUPT',
      `${options.filePath} ends inside a quoted field that was never closed (record ${String(recordNumber)})`,
      'Close the quoted field, or re-export the file from the source system.',
      { filePath: options.filePath, recordNumber },
    );
  }

  // A trailing line terminator ends the last record; anything else still pending
  // is a final record. `fieldWasQuoted` matters here: a last line of `""` is a
  // record holding one empty field, and dropping it would lose a source row.
  if (!fieldIsEmpty(text.length) || fields.length > 0 || fieldWasQuoted) {
    finishRecord(text.length, text.length);
  }

  state.carry = '';
  state.carryOffset = fileOffset + text.length;
  state.recordCount = recordCount;
  state.recordNumber = recordNumber;
  state.crlf = crlf;
  state.lf = lf;
  state.cr = cr;
}

function dominantTerminator(crlf: number, lf: number, cr: number): CsvReadResult['lineTerminator'] {
  if (crlf === 0 && lf === 0 && cr === 0) return 'NONE';
  if (crlf >= lf && crlf >= cr) return 'CRLF';
  if (lf >= cr) return 'LF';
  return 'CR';
}
