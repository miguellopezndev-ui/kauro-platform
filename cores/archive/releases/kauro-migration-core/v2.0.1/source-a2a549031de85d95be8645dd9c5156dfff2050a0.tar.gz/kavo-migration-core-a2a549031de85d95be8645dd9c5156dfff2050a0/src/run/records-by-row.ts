import type { CanonicalObject } from '../domain/canonical.js';
import type { ResolvedRecord } from '../identity/resolve-identity.js';
import type { ReasonCode } from '../domain/reason-codes.js';
import type { ScratchStore } from '../scratch/scratch-store.js';
import type { RowOrderAddress, SpooledFamily } from './spool.js';
import { openFamily, rowOrderKey } from './spool.js';
import { compareCodeUnits } from '../util/json.js';

/**
 * What a row's record is, for the two stages that ask a row that question.
 *
 * This used to be the whole `ResolvedRecord`, spilled once per member row, and
 * it made 'records-by-row' the largest family the run wrote -- larger than the
 * records family it was copying, because each entry carried the record *and* a
 * full row address to key it by.
 *
 * Neither reader needs a record. The lineage pass reads the survivor's row, the
 * member rows and what each of them called itself, the object, the mapping, the
 * identity keys, the merge and the isolation. Relationship building reads the
 * migration key, the isolation detail, and the source record ids of the
 * survivor and the members. Between them that is this type; the values the
 * record delivers, the signal maps its members carried, and the file digests
 * and row hashes on their addresses are read by neither, and a fact nothing
 * reads is a fact that does not need writing down.
 */
export interface RowRecordMember {
  readonly rowLocatorId: string;
  readonly recordMappingId: string;
  readonly sourceSystem: string;
  readonly sourceNamespace: string;
  readonly sourceRecordId: string | null;
  /** The first proving key this row held, or null if it held none. */
  readonly identityKey: string | null;
}

export interface RowRecord {
  readonly migrationKey: string;
  readonly canonicalIdentityKey: string | null;
  readonly object: CanonicalObject;
  readonly recordMappingId: string;
  /** The first member. Reconstructed on read rather than written twice. */
  readonly survivor: RowRecordMember;
  readonly members: readonly RowRecordMember[];
  readonly mergeId: string | null;
  readonly isolation: {
    readonly reasonCode: ReasonCode;
    readonly detail: string;
    readonly field?: string | null;
  } | null;
}

/**
 * Which record a source row went into, without an index of every record.
 *
 * Two stages ask this question -- the pass that writes the lineage, and the one
 * that resolves relationships -- and both ask it while walking a sheet in the
 * order its rows are written. So the answer is a family keyed by the row each
 * record was built from, walked alongside the sheet rather than looked up.
 *
 * A record built from several rows appears once per row: that is exactly what
 * the old map held, and the merge that produced it is why the question has an
 * answer for every member and not only for the survivor.
 */
export interface RecordsByRow {
  /** A cursor over the whole family, from the first row. */
  open(): RecordCursor;
  /**
   * Discards the family. Every cursor already handed out is finished with it,
   * and a new one would fail on the missing segment rather than read nothing.
   */
  release(): void;
}

export interface RecordCursor {
  /**
   * The record this row went into, or null if it went into none.
   *
   * Addresses must be asked for in the order the family is written in, which is
   * the order every sheet is walked in. A cursor that is asked to go backwards
   * says so rather than answering wrongly.
   */
  at(address: RowOrderAddress): RowRecord | null;
}

/**
 * The address the entry is keyed by, and nothing more.
 *
 * The entry used to carry a whole `RowAddress` -- bundle id, file id, file
 * digest, sheet name, row locator, row hash -- and the only thing read from it
 * was `rowOrderKey`, which is three of those fields. The digests alone were 128
 * hex characters per entry, written once per source row that produced a record.
 */
interface RowEntry {
  readonly address: RowOrderAddress;
  readonly record: RowRecord;
}

function memberOf(member: ResolvedRecord['members'][number]): RowRecordMember {
  return {
    rowLocatorId: member.address.rowLocatorId,
    recordMappingId: member.recordMappingId,
    sourceSystem: member.sourceSystem,
    sourceNamespace: member.sourceNamespace,
    sourceRecordId: member.sourceRecordId,
    identityKey: member.identityKey,
  };
}

export function spillRecordsByRow(
  scratch: ScratchStore,
  records: SpooledFamily<ResolvedRecord>,
): RecordsByRow {
  const family = (() => {
    const writer = openFamily<RowEntry>(scratch, {
      schema: 'records-by-row',
      key: (entry) => rowOrderKey(entry.address),
      // The survivor is the first member, as it is in the record this was
      // projected from, so it is written once and rebuilt on the way back.
      encode: (entry) =>
        JSON.stringify({
          address: entry.address,
          record: {
            migrationKey: entry.record.migrationKey,
            canonicalIdentityKey: entry.record.canonicalIdentityKey,
            object: entry.record.object,
            recordMappingId: entry.record.recordMappingId,
            members: entry.record.members,
            mergeId: entry.record.mergeId,
            isolation: entry.record.isolation,
          },
        }),
      decode: (line) => {
        const raw = JSON.parse(line) as {
          address: RowOrderAddress;
          record: Omit<RowRecord, 'survivor'>;
        };
        const survivor = raw.record.members[0];
        if (survivor === undefined) {
          throw new Error(`records-by-row read back a record with no member rows: ${raw.record.migrationKey}`);
        }
        return { address: raw.address, record: { ...raw.record, survivor } };
      },
    });
    for (const record of records) {
      const members = record.members.map(memberOf);
      const survivor = members[0];
      if (survivor === undefined) {
        throw new Error(`records-by-row was given a record with no member rows: ${record.migrationKey}`);
      }
      const projected: RowRecord = {
        migrationKey: record.migrationKey,
        canonicalIdentityKey: record.canonicalIdentityKey,
        object: record.object,
        recordMappingId: record.recordMappingId,
        survivor,
        members,
        mergeId: record.mergeId,
        isolation: record.isolation,
      };
      for (const member of record.members) {
        writer.add({
          address: {
            filePath: member.address.filePath,
            sheetId: member.address.sheetId,
            rowNumberSource: member.address.rowNumberSource,
          },
          record: projected,
        });
      }
    }
    return writer.seal();
  })();

  return {
    release(): void {
      family.release();
    },
    open(): RecordCursor {
      const rows = family[Symbol.iterator]();
      let held: RowEntry | null = null;
      let exhausted = false;
      let lastAsked: string | null = null;

      const pull = (): void => {
        if (held !== null || exhausted) return;
        const step = rows.next();
        if (step.done === true) {
          exhausted = true;
          return;
        }
        held = step.value;
      };

      return {
        at(address): RowRecord | null {
          const wanted = rowOrderKey(address);
          if (lastAsked !== null && compareCodeUnits(lastAsked, wanted) > 0) {
            // Every caller walks a sheet in its own order, and every sheet is
            // written in this one. Going backwards would mean the two had come
            // apart, which is worth failing on rather than answering null.
            throw new Error(`records-by-row was asked for ${wanted} after ${lastAsked}`);
          }
          lastAsked = wanted;

          for (;;) {
            pull();
            if (held === null) return null;
            const here = rowOrderKey(held.address);
            const order = compareCodeUnits(here, wanted);
            if (order > 0) return null;
            const found = held;
            held = null;
            if (order === 0) return found.record;
          }
        },
      };
    },
  };
}
